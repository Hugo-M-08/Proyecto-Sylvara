package com.hugo.sylvarapro;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Environment;
import androidx.core.content.FileProvider;
import org.json.JSONArray;
import java.io.File;
import java.io.FileOutputStream;
import android.widget.LinearLayout;
import com.github.mikephil.charting.charts.CombinedChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.CombinedData;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;
import java.util.HashMap;
import java.util.Map;
import android.widget.Button;
import java.util.stream.Collectors;
public class Home extends Fragment {

    private TextView tvTotalInvernaderos, tvSensoresActivos;
    private ImageButton btnAgregarSensorAtajo, btnIrGraficas, btnGraficasImprimir, btnAgregarBolitaAtajo;
    private RecyclerView rvEstadoInvernadero;
    private AdaptadorInvernaderoHome adapter;
    private ConectaWebServiceInvernadero webServiceInvernadero;
    private ConectaWebServiceSensores webServiceSensor;
    private List<Item_Invernadero> listaInvernaderosGlobal = new ArrayList<>();

    public Home() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Inicialización de vistas
        tvTotalInvernaderos = view.findViewById(R.id.TV_Totalinvernaderos);
        tvSensoresActivos = view.findViewById(R.id.TV_SensoresActivos);
        btnAgregarSensorAtajo = view.findViewById(R.id.BTN_AgregarSensorAtajo);
        btnIrGraficas = view.findViewById(R.id.BTN_IrGraficas);
        btnGraficasImprimir = view.findViewById(R.id.BTN_GraficasImprimir);
        btnAgregarBolitaAtajo = view.findViewById(R.id.BTN_AgregarBolitaAtajo);
        rvEstadoInvernadero = view.findViewById(R.id.RV_EstadoInvernadero);

        webServiceInvernadero = new ConectaWebServiceInvernadero();
        webServiceSensor = new ConectaWebServiceSensores();

        // Configuración RecyclerView
        rvEstadoInvernadero.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new AdaptadorInvernaderoHome(new ArrayList<>(), getContext());
        rvEstadoInvernadero.setAdapter(adapter);

        cargarDatos();

        // Listeners de botones
        btnAgregarBolitaAtajo.setOnClickListener(v -> mostrarDialogoAtajoBolita());
        btnAgregarSensorAtajo.setOnClickListener(v -> mostrarDialogoVincularSensor());
        btnIrGraficas.setOnClickListener(v -> {
            getParentFragmentManager().beginTransaction()
                    .replace(R.id.frame_layout, new Graficas())
                    .addToBackStack(null)
                    .commit();
        });
        btnGraficasImprimir.setOnClickListener(v -> mostrarDialogoSeleccionReporte());

        return view;
    }

    private void cargarDatos() {
        if (!isAdded() || getActivity() == null) return;

        SharedPreferences preferences = getActivity().getSharedPreferences("user_session", Context.MODE_PRIVATE);
        String id_usuario = preferences.getString("id_usuario", "");
        if (id_usuario.isEmpty()) {
            startActivity(new Intent(getActivity(), Login.class));
            getActivity().finish();
            return;
        }

        webServiceInvernadero.obtenerInvernaderos(id_usuario, new ConectaWebServiceInvernadero.Callback<List<Item_Invernadero>>() {
            @Override
            public void onSuccess(List<Item_Invernadero> result) {
                if (!isAdded() || getActivity() == null) return;
                getActivity().runOnUiThread(() -> {
                    listaInvernaderosGlobal = result;
                    tvTotalInvernaderos.setText("Total de invernaderos: " + result.size());
                    adapter.updateInvernaderos(result);
                    cargarSensores(result);
                });
            }

            @Override
            public void onError(String error) {
                if (!isAdded() || getActivity() == null) return;
                getActivity().runOnUiThread(() ->
                        Toast.makeText(getActivity(), "Error: " + error, Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void cargarSensores(List<Item_Invernadero> invernaderos) {
        if (invernaderos == null || invernaderos.isEmpty()) return;
        final int[] totalSensores = {0};
        final int[] respuestasPendientes = {invernaderos.size()};

        for (Item_Invernadero inv : invernaderos) {
            webServiceSensor.obtenerSensores(inv.getIdInvernadero(), new ConectaWebServiceSensores.Callback<List<Item_Sensor>>() {
                @Override
                public void onSuccess(List<Item_Sensor> result) {
                    if (!isAdded() || getActivity() == null) return;
                    getActivity().runOnUiThread(() -> {
                        totalSensores[0] += result.size();
                        respuestasPendientes[0]--;
                        if (respuestasPendientes[0] == 0) {
                            tvSensoresActivos.setText("Sensores activos: " + totalSensores[0]);
                        }
                    });
                }
                @Override
                public void onError(String error) {
                    if (!isAdded() || getActivity() == null) return;
                    getActivity().runOnUiThread(() -> {
                        respuestasPendientes[0]--;
                        if (respuestasPendientes[0] == 0) {
                            tvSensoresActivos.setText("Sensores activos: " + totalSensores[0]);
                        }
                    });
                }
            });
        }
    }

    // --- LÓGICA ATAJO BOLITAS ---

    private void mostrarDialogoAtajoBolita() {
        if (!isAdded() || getActivity() == null) return;

        SharedPreferences preferences = getActivity().getSharedPreferences("user_session", Context.MODE_PRIVATE);
        String id_usuario = preferences.getString("id_usuario", "");

        // Consultamos bolitas compradas en segundo plano
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Bolitas/obtener_bolitas_compradas.php?id_usuario=" + id_usuario);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) response.append(line);
                reader.close();

                JSONObject json = new JSONObject(response.toString());
                if (json.optString("code").equals("002")) {
                    JSONArray data = json.getJSONArray("data");
                    List<Item_Productos> bolitasCompradas = new ArrayList<>();
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject obj = data.getJSONObject(i);
                        Item_Productos item = new Item_Productos();
                        item.setId_producto(obj.getString("id_producto"));
                        item.setNombre(obj.getString("nombre"));
                        bolitasCompradas.add(item);
                    }

                    if (isAdded() && getActivity() != null) {
                        getActivity().runOnUiThread(() -> {
                            if (bolitasCompradas.isEmpty()) {
                                Toast.makeText(getContext(), "Primero debes comprar bolitas", Toast.LENGTH_SHORT).show();
                            } else {
                                crearDialogoCompactoBolita(bolitasCompradas);
                            }
                        });
                    }
                }
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    private void crearDialogoCompactoBolita(List<Item_Productos> bolitas) {
        if (listaInvernaderosGlobal == null || listaInvernaderosGlobal.isEmpty()) {
            Toast.makeText(getContext(), "No hay invernaderos disponibles", Toast.LENGTH_LONG).show();
            return;
        }

        if (bolitas == null || bolitas.isEmpty()) {
            Toast.makeText(getContext(), "No se encontraron bolitas compradas", Toast.LENGTH_LONG).show();
            return;
        }

        View dialogView = LayoutInflater.from(requireContext())
                .inflate(R.layout.dialog_instalar_bolita, null);

        Spinner spInvernadero = dialogView.findViewById(R.id.spinner_invernadero);
        Spinner spBolita = dialogView.findViewById(R.id.spinner_bolita);

        ArrayAdapter<Item_Invernadero> adapterInv = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_spinner_item,
                listaInvernaderosGlobal);
        adapterInv.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spInvernadero.setAdapter(adapterInv);

        List<String> nombresBolitas = new ArrayList<>();
        for (Item_Productos bolita : bolitas) {
            String nombre = bolita.getNombre();
            nombresBolitas.add(nombre != null && !nombre.trim().isEmpty()
                    ? nombre
                    : "Bolita #" + bolita.getId_producto());
        }

        ArrayAdapter<String> adapterBol = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_spinner_item,
                nombresBolitas);
        adapterBol.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spBolita.setAdapter(adapterBol);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setTitle("Instalar Bolita")
                .setView(dialogView)
                .setPositiveButton("Instalar", (dialogInterface, which) -> {
                    // Obtenemos las selecciones
                    Item_Invernadero invernaderoSeleccionado = (Item_Invernadero) spInvernadero.getSelectedItem();
                    int posicionBolita = spBolita.getSelectedItemPosition();

                    if (posicionBolita >= 0 && posicionBolita < bolitas.size()) {
                        String idProducto = bolitas.get(posicionBolita).getId_producto();
                        int idInvernadero = invernaderoSeleccionado.getIdInvernadero();

                        activarBolitaEnServidor(idInvernadero, idProducto);
                    } else {
                        Toast.makeText(getContext(), "Selección inválida", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", (dialogInterface, which) -> dialogInterface.dismiss())
                .create();

        Window window = dialog.getWindow();
        if (window != null) {
            window.setLayout(
                    (int) (getResources().getDisplayMetrics().widthPixels * 0.88),
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            window.setGravity(Gravity.CENTER);
        }

        dialog.show();
    }
    private void activarBolitaEnServidor(int idInvernadero, String idProducto) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Bolitas/gestionar_automatizacion.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);

                String params = "accion=activar&id_invernadero=" + idInvernadero + "&id_producto=" + idProducto;
                OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
                wr.write(params);
                wr.flush();

                BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                JSONObject res = new JSONObject(rd.readLine());

                if (isAdded() && getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        try {
                            if (res.getString("code").equals("002")) {
                                Toast.makeText(getContext(), "¡Bolita instalada con éxito!", Toast.LENGTH_LONG).show();
                                cargarDatos();
                            } else {
                                Toast.makeText(getContext(), "Error: " + res.optString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (Exception ignored) {}
                    });
                }
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    // --- VINCULAR SENSOR ---

    private void mostrarDialogoVincularSensor() {
        if (!isAdded() || getActivity() == null) return;

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_vincular_sensor, null);
        AlertDialog dialog = new AlertDialog.Builder(requireContext()).setView(dialogView).create();

        EditText etC = dialogView.findViewById(R.id.etCodigoDispositivo);
        EditText etN = dialogView.findViewById(R.id.etNombreSensor);
        Spinner sp = dialogView.findViewById(R.id.spinnerInvernadero);
        Button btnVincular = dialogView.findViewById(R.id.btnVincular);
        Button btnCancelar = dialogView.findViewById(R.id.btnCancelar);

        List<String> nombresInvernaderos = new ArrayList<>();
        for (Item_Invernadero inv : listaInvernaderosGlobal) nombresInvernaderos.add(inv.getNombre());
        sp.setAdapter(new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_dropdown_item, nombresInvernaderos));

        btnVincular.setOnClickListener(v -> {
            String codigo = etC.getText().toString().trim();
            String nombreSensor = etN.getText().toString().trim();
            if (codigo.isEmpty()) { Toast.makeText(getContext(), "Ingresa el código", Toast.LENGTH_SHORT).show(); return; }
            int pos = sp.getSelectedItemPosition();
            if (pos < 0) return;
            vincularSensorPorCodigo(codigo, nombreSensor, listaInvernaderosGlobal.get(pos).getIdInvernadero(), dialog);
        });

        if (btnCancelar != null) btnCancelar.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    private void vincularSensorPorCodigo(String codigo, String nombre, int idInvernadero, AlertDialog dialog) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Sensores/vincular_por_codigo.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                String params = "device_id=" + URLEncoder.encode(codigo, "UTF-8") + "&nombre=" + URLEncoder.encode(nombre, "UTF-8") + "&id_invernadero=" + idInvernadero;
                OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
                writer.write(params); writer.flush(); writer.close();

                if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    if (isAdded() && getActivity() != null) {
                        getActivity().runOnUiThread(() -> {
                            Toast.makeText(getActivity(), "Sensor vinculado", Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                            cargarDatos();
                        });
                    }
                }
                conn.disconnect();
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    // --- REPORTE PDF ---

    private void mostrarDialogoSeleccionReporte() {
        if (listaInvernaderosGlobal.isEmpty()) {
            Toast.makeText(getContext(), "No hay invernaderos disponibles", Toast.LENGTH_SHORT).show();
            return;
        }

        LinearLayout layout = new LinearLayout(requireContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 40);

        TextView tvInv = new TextView(requireContext());
        tvInv.setText("Seleccionar Invernadero:");
        layout.addView(tvInv);

        Spinner spInv = new Spinner(requireContext());
        List<String> opcionesInv = new ArrayList<>();
        opcionesInv.add("Todos");
        for (Item_Invernadero inv : listaInvernaderosGlobal) opcionesInv.add(inv.getNombre());
        spInv.setAdapter(new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_dropdown_item, opcionesInv));
        layout.addView(spInv);

        TextView tvPeriodo = new TextView(requireContext());
        tvPeriodo.setText("Seleccionar Período:");
        layout.addView(tvPeriodo);

        Spinner spPeriodo = new Spinner(requireContext());
        String[] periodos = {"Hoy", "Semana", "Mes", "Año"};
        spPeriodo.setAdapter(new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_dropdown_item, periodos));
        layout.addView(spPeriodo);

        new AlertDialog.Builder(requireContext())
                .setTitle("Generar Reporte PDF")
                .setView(layout)
                .setPositiveButton("Generar", (dialog, which) -> {
                    String selectedInv = spInv.getSelectedItem().toString();
                    String rango = spPeriodo.getSelectedItem().toString().toLowerCase().replace("año", "anio");
                    List<Item_Invernadero> seleccion = new ArrayList<>();
                    if (selectedInv.equals("Todos")) seleccion.addAll(listaInvernaderosGlobal);
                    else {
                        for (Item_Invernadero inv : listaInvernaderosGlobal) {
                            if (inv.getNombre().equals(selectedInv)) { seleccion.add(inv); break; }
                        }
                    }
                    if (!seleccion.isEmpty()) generarPDF(seleccion, rango);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void generarPDF(List<Item_Invernadero> invernaderos, String rango) {
        Executors.newSingleThreadExecutor().execute(() -> {
            Map<Item_Invernadero, Map<String, JSONObject>> allData = new HashMap<>();
            try {
                for (Item_Invernadero inv : invernaderos) {
                    Map<String, JSONObject> dataMap = new HashMap<>();
                    dataMap.put("cosechas", realizarPeticionSync(inv.getIdInvernadero(), "cosechas", rango));
                    dataMap.put("agua", realizarPeticionSync(inv.getIdInvernadero(), "agua", rango));
                    dataMap.put("ambiental", realizarPeticionSync(inv.getIdInvernadero(), "ambiental", rango));
                    allData.put(inv, dataMap);
                }

                if (!isAdded() || getActivity() == null) return;
                getActivity().runOnUiThread(() -> {
                    Map<Item_Invernadero, Map<String, Bitmap>> allBitmaps = new HashMap<>();
                    for (Map.Entry<Item_Invernadero, Map<String, JSONObject>> entry : allData.entrySet()) {
                        Map<String, Bitmap> bmpMap = new HashMap<>();
                        try {
                            bmpMap.put("cosechas", generateChartBitmap(entry.getValue().get("cosechas").getJSONArray("data"), "cosechas"));
                            bmpMap.put("agua", generateChartBitmap(entry.getValue().get("agua").getJSONArray("data"), "agua"));
                            bmpMap.put("temperatura", generateChartBitmap(entry.getValue().get("ambiental").getJSONArray("data"), "temperatura"));
                        } catch (Exception ignored) {}
                        allBitmaps.put(entry.getKey(), bmpMap);
                    }

                    Executors.newSingleThreadExecutor().execute(() -> {
                        try {
                            PdfDocument document = new PdfDocument();
                            PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(595, 842, 1).create();
                            PdfDocument.Page page = document.startPage(pageInfo);
                            Canvas canvas = page.getCanvas();
                            Paint paint = new Paint();

                            paint.setColor(Color.parseColor("#C6ECFD"));
                            canvas.drawRect(0, 0, 595, 110, paint);
                            paint.setColor(Color.BLACK);
                            paint.setTextSize(20f);
                            canvas.drawText("REPORTE OPERATIVO SYLVARA PRO", 130, 60, paint);

                            int yPos = 130;
                            for (Item_Invernadero inv : invernaderos) {
                                if (yPos > 700) { document.finishPage(page); page = document.startPage(pageInfo); canvas = page.getCanvas(); yPos = 60; }
                                paint.setTextSize(16f);
                                canvas.drawText("INVERNADERO: " + inv.getNombre().toUpperCase(), 50, yPos, paint);
                                yPos += 30;
                                Map<String, Bitmap> bmpMap = allBitmaps.get(inv);
                                yPos = dibujarGraficoPDF(canvas, paint, yPos, "ÉXITO/FALLIDO", bmpMap != null ? bmpMap.get("cosechas") : null);
                                yPos = dibujarGraficoPDF(canvas, paint, yPos, "CONSUMO DE AGUA", bmpMap != null ? bmpMap.get("agua") : null);
                                yPos = dibujarGraficoPDF(canvas, paint, yPos, "TEMPERATURA", bmpMap != null ? bmpMap.get("temperatura") : null);
                                yPos += 50;
                            }
                            document.finishPage(page);
                            File file = new File(requireActivity().getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Reporte_Sylvara_" + System.currentTimeMillis() + ".pdf");
                            document.writeTo(new FileOutputStream(file));
                            document.close();
                            if (isAdded() && getActivity() != null) getActivity().runOnUiThread(() -> abrirPDF(file));
                        } catch (Exception e) { e.printStackTrace(); }
                    });
                });
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    private int dibujarGraficoPDF(Canvas canvas, Paint paint, int yPos, String titulo, Bitmap bitmap) {
        paint.setTextSize(14f);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        canvas.drawText(titulo, 50, yPos, paint);
        yPos += 25;
        if (bitmap != null) { canvas.drawBitmap(bitmap, 50, yPos, null); yPos += bitmap.getHeight() + 30; }
        else { paint.setTextSize(12f); canvas.drawText("Sin datos", 50, yPos + 20, paint); yPos += 60; }
        return yPos;
    }

    private Bitmap generateChartBitmap(JSONArray data, String tipo) {
        if (data == null || data.length() == 0) return null;
        CombinedChart chart = new CombinedChart(requireContext());
        chart.setLayoutParams(new ViewGroup.LayoutParams(500, 300));
        chart.setBackgroundColor(Color.WHITE);
        CombinedData combinedData = new CombinedData();
        if (tipo.equals("cosechas")) {
            ArrayList<BarEntry> barEntries = new ArrayList<>();
            for (int i = 0; i < data.length(); i++) {
                try { barEntries.add(new BarEntry(i, (float) data.getJSONObject(i).getDouble("promedio"))); } catch (Exception ignored) {}
            }
            if (!barEntries.isEmpty()) {
                BarDataSet set = new BarDataSet(barEntries, "Cosechas");
                set.setColors(ColorTemplate.MATERIAL_COLORS);
                combinedData.setData(new BarData(set));
            }
        } else {
            ArrayList<Entry> lineEntries = new ArrayList<>();
            for (int i = 0; i < data.length(); i++) {
                try { lineEntries.add(new Entry(i, (float) data.getJSONObject(i).getDouble("promedio"))); } catch (Exception ignored) {}
            }
            if (!lineEntries.isEmpty()) {
                LineDataSet set = new LineDataSet(lineEntries, tipo);
                set.setColor(Color.GREEN);
                combinedData.setData(new LineData(set));
            }
        }
        chart.setData(combinedData);
        chart.measure(View.MeasureSpec.makeMeasureSpec(500, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(300, View.MeasureSpec.EXACTLY));
        chart.layout(0, 0, 500, 300);
        return chart.getChartBitmap();
    }

    private JSONObject realizarPeticionSync(int idInv, String tipo, String rango) throws Exception {
        URL url = new URL(Configuracion.getUrlBase() + "Graficas/obtener_graficas_sylvara.php?tipo=" + tipo + "&id_invernadero=" + idInv + "&rango=" + rango);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        return new JSONObject(rd.readLine());
    }

    private void abrirPDF(File file) {
        if (!isAdded() || getContext() == null) return;
        Uri uri = FileProvider.getUriForFile(requireContext(), requireContext().getPackageName() + ".provider", file);
        Intent intent = new Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/pdf").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(intent, "Ver Reporte"));
    }
}