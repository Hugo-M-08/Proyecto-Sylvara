package com.hugo.sylvarapro;



import android.os.Parcel;
import android.os.Parcelable;

public class Item_Productos implements Parcelable {

    private String id_producto;
    private String nombre;
    private String descripcion;
    private String precio;
    private String unidades;
    private String imagen;
    private int cantidad;
    private float calificacion;

    // Constructor vacío
    public Item_Productos() {
        this.cantidad = 1;
    }

    // Constructor completo
    public Item_Productos(String id_producto, String nombre, String descripcion,
                          String precio, String unidades, String imagen,
                          float calificacion) {

        this.id_producto = id_producto;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.unidades = unidades;
        this.imagen = imagen;
        this.calificacion = calificacion;
        this.cantidad = 1;
    }

    // Parcelable
    protected Item_Productos(Parcel in) {
        id_producto = in.readString();
        nombre = in.readString();
        descripcion = in.readString();
        precio = in.readString();
        unidades = in.readString();
        imagen = in.readString();
        cantidad = in.readInt();
        calificacion = in.readFloat();
    }

    public static final Creator<Item_Productos> CREATOR =
            new Creator<Item_Productos>() {
                @Override
                public Item_Productos createFromParcel(Parcel in) {
                    return new Item_Productos(in);
                }

                @Override
                public Item_Productos[] newArray(int size) {
                    return new Item_Productos[size];
                }
            };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id_producto);
        dest.writeString(nombre);
        dest.writeString(descripcion);
        dest.writeString(precio);
        dest.writeString(unidades);
        dest.writeString(imagen);
        dest.writeInt(cantidad);
        dest.writeFloat(calificacion);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    // GETTERS Y SETTERS
    public String getId_producto() {
        return id_producto;
    }

    public void setId_producto(String id_producto) {
        this.id_producto = id_producto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getUnidades() {
        return unidades;
    }

    public void setUnidades(String unidades) {
        this.unidades = unidades;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public float getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(float calificacion) {
        this.calificacion = calificacion;
    }
}

