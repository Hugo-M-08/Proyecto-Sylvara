package com.hugo.sylvarapro;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.hugo.sylvarapro.databinding.ActivityMainAdminBinding;

//no hay ip

public class MainActivityAdmin extends AppCompatActivity {
    private ActivityMainAdminBinding binding;
    private ImageView IMG_Perfil1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        // Inicializar View Binding
        binding = ActivityMainAdminBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Configurar Edge-to-Edge
        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        // Inicializar ImageView
        IMG_Perfil1 = binding.IMGPerfil1;
        if (IMG_Perfil1 == null) {
            Log.e("MainActivityAdmin", "IMG_Perfil1 es null");
        } else {
            IMG_Perfil1.setOnClickListener(v -> {
                Log.d("MainActivityAdmin", "Clic en IMG_Perfil1");
                Intent intent = new Intent(MainActivityAdmin.this, Perfil.class);
                intent.putExtra("isAdmin", true); // Indicar que se accede desde MainActivityAdmin
                startActivity(intent);
            });
        }

        // Configurar BottomNavigationView
        binding.bottomNavigationView1.setBackground(null);
        binding.bottomNavigationView1.setSelectedItemId(R.id.homeAdmin); // Establecer ítem inicial
        replaceFragment(new HomeAdmin()); // Fragmento inicial

        binding.bottomNavigationView1.setOnItemSelectedListener(item -> {
            Log.d("MainActivityAdmin", "Item seleccionado: " + item.getItemId());
            if (item.getItemId() == R.id.homeAdmin) {
                replaceFragment(new HomeAdmin());
            } else if (item.getItemId() == R.id.tiendaAdmin) {
                replaceFragment(new TiendaAdmin());
            } else if (item.getItemId() == R.id.bolitasAdmin) {
                replaceFragment(new BolitasAdmin());
            }else if (item.getItemId() == R.id.enviosAdmin) {
                replaceFragment(new EnviosAdmin());
            }
            return true;
        });
    }

    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout1, fragment);
        fragmentTransaction.commit();
    }
}