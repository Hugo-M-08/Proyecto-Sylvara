package com.hugo.sylvarapro;

public class Item_Tarjeta {
    private int id_tarjeta;
    private String titular;
    private String numero_tarjeta;
    private String cvv;
    private String fecha_vencimiento;
    private String alias;
    private int id_usuario;
    private boolean es_predeterminada;

    // Constructor
    public Item_Tarjeta(int id_tarjeta, String titular, String numero_tarjeta, String cvv,
                        String fecha_vencimiento, String alias, int id_usuario, boolean es_predeterminada) {
        this.id_tarjeta = id_tarjeta;
        this.titular = titular;
        this.numero_tarjeta = numero_tarjeta;
        this.cvv = cvv;
        this.fecha_vencimiento = fecha_vencimiento;
        this.alias = alias;
        this.id_usuario = id_usuario;
        this.es_predeterminada = es_predeterminada;
    }

    // Getters
    public int getId_tarjeta() {
        return id_tarjeta;
    }

    public String getTitular() {
        return titular;
    }

    public String getNumero_tarjeta() {
        return numero_tarjeta;
    }

    public String getCvv() {
        return cvv;
    }

    public String getFecha_vencimiento() {
        return fecha_vencimiento;
    }

    public String getAlias() {
        return alias;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public boolean isEs_predeterminada() {
        return es_predeterminada;
    }
}