package com.hugo.sylvarapro;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

//no hay ip

public class AdaptadorSensores extends RecyclerView.Adapter<AdaptadorSensores.ViewHolder> {
    private Context context;
    private List<Item_Sensor> lista;
    private OnSensorActionListener listener;

    public interface OnSensorActionListener {
        void onToggleSensor(int id, boolean estado);
        void onEliminarSensor(int id);
        void onClickSensor(Item_Sensor sensor);
    }

    public AdaptadorSensores(Context context, List<Item_Sensor> lista, OnSensorActionListener listener) {
        this.context = context;
        this.lista = lista;
        this.listener = listener;
    }

    public List<Item_Sensor> getLista() {
        return lista;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_sensor, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item_Sensor s = lista.get(position);
        holder.tvNombre.setText(s.getNombre());
        holder.tvTipo.setText("Tipo: " + s.getTipoSensor());

        holder.btnEliminar.setOnClickListener(v -> {
            if(listener != null) listener.onEliminarSensor(s.getIdSensor());
        });

        holder.btnToggle.setOnClickListener(v -> {
            if(listener != null) {
                boolean nuevoEstado = s.getEstado() != 1;
                listener.onToggleSensor(s.getIdSensor(), nuevoEstado);
            }
        });

        holder.itemView.setOnClickListener(v -> {
            if(listener != null) listener.onClickSensor(s);
        });

        if (s.getEstado() == 1) {
            holder.btnToggle.setText("Apagar");
            holder.btnToggle.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF5252")));
        } else {
            holder.btnToggle.setText("Encender");
            holder.btnToggle.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#4CAF50")));
        }
    }

    @Override
    public int getItemCount() { return lista.size(); }

    public void updateSensores(List<Item_Sensor> nueva) {
        this.lista.clear();
        this.lista.addAll(nueva);
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvNombre, tvTipo;
        Button btnEliminar, btnToggle;
        public ViewHolder(@NonNull View v) {
            super(v);
            tvNombre = v.findViewById(R.id.TV_ApodoSensor);
            tvTipo = v.findViewById(R.id.TV_Tipo);
            btnEliminar = v.findViewById(R.id.BTN_Borrar);
            btnToggle = v.findViewById(R.id.BTN_ApagarEncender);
        }
    }
}