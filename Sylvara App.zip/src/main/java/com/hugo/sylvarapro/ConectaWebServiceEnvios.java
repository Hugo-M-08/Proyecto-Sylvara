package com.hugo.sylvarapro;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;
//hay ip
public class ConectaWebServiceEnvios {
    public interface Callback<T> {
        void onSuccess(T result);
        void onError(String error);
    }

    private static final String CARPETA_COMPRA = "Compra/";

    private static final String BASE_URL = Configuracion.getUrlBase() + CARPETA_COMPRA + "obtener_compras.php";
    private static final String CANCELAR_URL = Configuracion.getUrlBase() + CARPETA_COMPRA + "cancelar_compra.php";

    public void obtenerEnvios(String id_usuario, Callback<List<Item_Envio>> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(BASE_URL + "?id_usuario=" + URLEncoder.encode(id_usuario, "UTF-8"));
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("GET");

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        response.append(linea);
                    }
                    reader.close();

                    String respuestaStr = response.toString();

                    if (respuestaStr.equals("001")) {
                        callback.onError("ID de usuario faltante");
                    } else if (respuestaStr.equals("010")) {
                        callback.onSuccess(new ArrayList<>());
                    } else {
                        List<Item_Envio> envios = new ArrayList<>();
                        JSONArray jsonArray = new JSONArray(respuestaStr);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject json = jsonArray.getJSONObject(i);
                            // Leemos los nuevos campos desde el JSON del servidor
                            envios.add(new Item_Envio(
                                    json.getInt("id_compras"),
                                    json.getString("imagen"),
                                    json.getString("status"),
                                    json.getString("fecha_entrega"),
                                    json.getInt("id_usuario"),
                                    json.optDouble("total", 0.0),
                                    json.optDouble("envio", 0.0) ,
                                    json.getInt("id_producto")
                            ));
                        }
                        callback.onSuccess(envios);
                    }
                } else {
                    callback.onError("Error de conexión: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception e) {
                callback.onError("Error de servidor: " + e.getMessage());
            }
        });
    }

    public void cancelarCompra(int id_compras, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(CANCELAR_URL);
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String data = "id_compras=" + id_compras;
                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(data);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    String response = reader.readLine();
                    reader.close();

                    if (response == null) {
                        callback.onError("Respuesta vacía del servidor");
                        return;
                    }

                    switch (response) {
                        case "001": callback.onError("ID de compra faltante"); break;
                        case "002": callback.onSuccess("Compra cancelada correctamente"); break;
                        case "000": callback.onError("No se pudo cancelar la compra"); break;
                        case "010": callback.onError("Compra no encontrada"); break;
                        default: callback.onError("Error inesperado: " + response); break;
                    }
                } else {
                    callback.onError("Error al conectar: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception e) {
                callback.onError("Error de red: " + e.getMessage());
            }
        });
    }
    public void solicitarDevolucion(int id_compras, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Compra/actualizar_status.php");
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                // Enviamos el ID y el nuevo estatus
                String data = "id_compras=" + id_compras + "&nuevo_status=" + URLEncoder.encode("Proceso de devolución", "UTF-8");

                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(data);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    String response = reader.readLine();
                    reader.close();
                    if ("002".equals(response)) callback.onSuccess("Estatus actualizado");
                    else callback.onError("No se pudo actualizar el estatus");
                }
                conexion.disconnect();
            } catch (Exception e) {
                callback.onError("Error: " + e.getMessage());
            }
        });
    }
    public void agregarResena(int idProducto, int idUsuario, int estrellas, String comentario, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Compra/agregar_resena.php");
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String data = "id_producto=" + idProducto +
                        "&id_usuario=" + idUsuario +
                        "&estrellas=" + estrellas +
                        "&comentario=" + URLEncoder.encode(comentario, "UTF-8");

                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(data);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    String response = reader.readLine();
                    reader.close();
                    if ("002".equals(response)) callback.onSuccess("Reseña guardada");
                    else callback.onError("Error al guardar reseña");
                }
                conexion.disconnect();
            } catch (Exception e) {
                callback.onError("Error de red: " + e.getMessage());
            }
        });
    }
}