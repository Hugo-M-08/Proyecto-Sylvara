package com.hugo.sylvarapro;

import android.os.Parcel;
import android.os.Parcelable;

public class Item_Sensor implements Parcelable {
    private int idSensor;
    private String nombre;
    private int idInvernadero;
    private String tipoSensor;
    private boolean encendido; // Para el estado encendido/apagado

    public Item_Sensor(int idSensor, String nombre, int idInvernadero, String tipoSensor, boolean encendido) {
        this.idSensor = idSensor;
        this.nombre = nombre;
        this.idInvernadero = idInvernadero;
        this.tipoSensor = tipoSensor;
        this.encendido = encendido;
    }

    protected Item_Sensor(Parcel in) {
        idSensor = in.readInt();
        nombre = in.readString();
        idInvernadero = in.readInt();
        tipoSensor = in.readString();
        encendido = in.readByte() != 0;
    }

    public static final Creator<Item_Sensor> CREATOR = new Creator<Item_Sensor>() {
        @Override
        public Item_Sensor createFromParcel(Parcel in) {
            return new Item_Sensor(in);
        }

        @Override
        public Item_Sensor[] newArray(int size) {
            return new Item_Sensor[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(idSensor);
        dest.writeString(nombre);
        dest.writeInt(idInvernadero);
        dest.writeString(tipoSensor);
        dest.writeByte((byte) (encendido ? 1 : 0));
    }

    public int getIdSensor() {
        return idSensor;
    }

    public String getNombre() {
        return nombre;
    }

    public int getIdInvernadero() {
        return idInvernadero;
    }

    public String getTipoSensor() {
        return tipoSensor;
    }

    public boolean isEncendido() {
        return encendido;
    }

    public void setEncendido(boolean encendido) {
        this.encendido = encendido;
    }
    // Este es el que pedía el adaptador
    public int getEstado() {
        return encendido ? 1 : 0;
    }

    // Opcional: Si recibes un entero del WebService, este método te ayuda a guardarlo
    public void setEstado(int estado) {
        this.encendido = (estado == 1);
    }
}