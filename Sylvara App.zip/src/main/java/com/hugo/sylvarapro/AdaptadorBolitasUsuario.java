package com.hugo.sylvarapro;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;



public class AdaptadorBolitasUsuario extends RecyclerView.Adapter<AdaptadorBolitasUsuario.ViewHolder> {
    private List<Item_Productos> datos;
    private Context context;
    private int layoutResourceId; // Para manejar diferentes diseños
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Item_Productos producto);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    // Constructor actualizado para recibir el diseño deseado
    public AdaptadorBolitasUsuario(List<Item_Productos> datos, Context context, int layoutResourceId) {
        this.datos = datos;
        this.context = context;
        this.layoutResourceId = layoutResourceId;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(layoutResourceId, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item_Productos item = datos.get(position);

        // Lógica de Imagen (Soporte Base64 y Servidor)
        if (item.getImagen() != null && !item.getImagen().equals("null")) {
            if (item.getImagen().startsWith("uploads/")) {
                String imageUrl = Configuracion.getUrlBase() + "Tienda/" + item.getImagen();
                Glide.with(context).load(imageUrl).placeholder(R.drawable.carga).error(R.drawable.error).into(holder.imgBolita);
            } else {
                try {
                    byte[] decoded = Base64.decode(item.getImagen(), Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(decoded, 0, decoded.length);
                    holder.imgBolita.setImageBitmap(bitmap);
                } catch (Exception e) {
                    holder.imgBolita.setImageResource(R.drawable.error);
                }
            }
        }

        holder.txtNombre.setText(item.getNombre());

        // Lógica de Precio con validación de existencia del objeto (Null-Safe)
        if (holder.txtPrecio != null) {
            double precio = 0;
            try {
                precio = Double.parseDouble(item.getPrecio());
            } catch (Exception e) { precio = 0; }

            if (precio > 0) {
                holder.txtPrecio.setText("$" + item.getPrecio());
                holder.txtPrecio.setVisibility(View.VISIBLE);
            } else {
                holder.txtPrecio.setVisibility(View.GONE);
            }
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onItemClick(item);
        });
    }

    @Override
    public int getItemCount() { return datos.size(); }

    public void updateBolitas(List<Item_Productos> nuevosDatos) {
        datos.clear();
        datos.addAll(nuevosDatos);
        notifyDataSetChanged();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgBolita;
        TextView txtNombre, txtPrecio;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgBolita = itemView.findViewById(R.id.IV_ImagenBolita);
            txtNombre = itemView.findViewById(R.id.TV_NombreBolita);
            // Si el layout no tiene el precio, findViewById devolverá null
            txtPrecio = itemView.findViewById(R.id.TV_PrecioBolita);
        }
    }
}