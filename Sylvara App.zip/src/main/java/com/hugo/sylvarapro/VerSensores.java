package com.hugo.sylvarapro;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

//no hay ip

public class VerSensores extends AppCompatActivity {
    private TextView tvNombreInvernadero;
    private RecyclerView rvSensores;
    private AdaptadorSensores adaptador;
    private ConectaWebServiceSensores webService;
    private Item_Invernadero invernadero;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ver_sensores);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tvNombreInvernadero = findViewById(R.id.TV_NombreInvernaderoSensor);
        rvSensores = findViewById(R.id.RV_Sensores);
        webService = new ConectaWebServiceSensores();

        invernadero = getIntent().getParcelableExtra("invernadero");
        if (invernadero == null) {
            Toast.makeText(this, "Error: Invernadero no encontrado", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        tvNombreInvernadero.setText(invernadero.getNombre());

        rvSensores.setLayoutManager(new LinearLayoutManager(this));

        // CORRECCIÓN AQUÍ: Implementar el método faltante
        adaptador = new AdaptadorSensores(this, new ArrayList<>(), new AdaptadorSensores.OnSensorActionListener() {
            @Override
            public void onToggleSensor(int idSensor, boolean encender) {
                Toast.makeText(VerSensores.this, encender ? "Sensor encendido" : "Sensor apagado", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onEliminarSensor(int idSensor) {
                webService.eliminarSensor(idSensor, new ConectaWebServiceSensores.Callback<String>() {
                    @Override
                    public void onSuccess(String result) {
                        runOnUiThread(() -> {
                            Toast.makeText(VerSensores.this, result, Toast.LENGTH_SHORT).show();
                            cargarSensores();
                        });
                    }
                    @Override
                    public void onError(String error) {
                        runOnUiThread(() -> Toast.makeText(VerSensores.this, "Error: " + error, Toast.LENGTH_LONG).show());
                    }
                });
            }

            // MÉTODO AÑADIDO PARA SOLUCIONAR EL ERROR
            @Override
            public void onClickSensor(Item_Sensor sensor) {
                // Si quieres que desde aquí también se abra el detalle:
                Intent intent = new Intent(VerSensores.this, SensorCompleto.class);
                intent.putExtra("sensor", sensor);
                startActivity(intent);
            }
        });

        rvSensores.setAdapter(adaptador);
        cargarSensores();
    }

    private void cargarSensores() {
        webService.obtenerSensores(invernadero.getIdInvernadero(), new ConectaWebServiceSensores.Callback<List<Item_Sensor>>() {
            @Override
            public void onSuccess(List<Item_Sensor> result) {
                runOnUiThread(() -> {
                    adaptador.updateSensores(result);
                    if (result.isEmpty()) {
                        Toast.makeText(VerSensores.this, "No hay sensores registrados", Toast.LENGTH_SHORT).show();
                    }
                });
            }
            @Override
            public void onError(String error) {
                runOnUiThread(() -> Toast.makeText(VerSensores.this, "Error: " + error, Toast.LENGTH_LONG).show());
            }
        });
    }
}