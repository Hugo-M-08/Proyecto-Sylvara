package com.hugo.sylvarapro;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.*;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.google.android.material.chip.ChipGroup;

public class VentasGraficas extends AppCompatActivity {

    private LineChart chartVentas;
    private PieChart chartProductos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ventas_graficas);

        chartVentas = findViewById(R.id.chartLineVentas);
        chartProductos = findViewById(R.id.chartPieProductos);
        ChipGroup chipGroup = findViewById(R.id.chipGroupFiltro);

        // Listeners para los filtros de tiempo
        chipGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.chipDia) cargarTendencia("dia");
            else if (checkedId == R.id.chipSemana) cargarTendencia("semana");
            else if (checkedId == R.id.chipMes) cargarTendencia("mes");
        });

        // Carga inicial
        cargarTendencia("dia");
        cargarProductosTop();
    }

    private void cargarTendencia(String temporalidad) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                String json = realizarPeticion(Configuracion.getUrlBase() + "Ventas/obtener_ventas_tendencia.php?filtro=" + temporalidad);
                runOnUiThread(() -> dibujarGraficaVentas(json));
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Error al cargar tendencia", Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void cargarProductosTop() {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                String json = realizarPeticion(Configuracion.getUrlBase() + "Ventas/obtener_productos_top.php");
                runOnUiThread(() -> dibujarGraficaProductos(json));
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Error al cargar productos", Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void dibujarGraficaVentas(String json) {
        try {
            JSONObject res = new JSONObject(json);
            JSONArray data = res.getJSONArray("data");
            List<Entry> entries = new ArrayList<>();
            final ArrayList<String> etiquetas = new ArrayList<>();

            for (int i = 0; i < data.length(); i++) {
                JSONObject obj = data.getJSONObject(i);
                entries.add(new Entry(i, (float) obj.getDouble("monto")));
                etiquetas.add(obj.getString("etiqueta"));
            }

            LineDataSet dataSet = new LineDataSet(entries, "Ventas");
            dataSet.setColor(Color.parseColor("#B11010"));
            dataSet.setCircleColor(Color.parseColor("#B11010"));
            dataSet.setLineWidth(2.5f);
            dataSet.setDrawFilled(true);
            dataSet.setFillColor(Color.parseColor("#FFCDD2"));
            dataSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);

            XAxis xAxis = chartVentas.getXAxis();
            xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
            xAxis.setGranularity(1f);
            xAxis.setValueFormatter(new ValueFormatter() {
                @Override
                public String getFormattedValue(float value) {
                    if (value >= 0 && value < etiquetas.size()) return etiquetas.get((int) value);
                    return "";
                }
            });

            chartVentas.setData(new LineData(dataSet));
            chartVentas.getDescription().setEnabled(false);
            chartVentas.animateX(800);
            chartVentas.invalidate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void dibujarGraficaProductos(String json) {
        try {
            JSONObject res = new JSONObject(json);
            JSONArray data = res.getJSONArray("data");
            List<PieEntry> entries = new ArrayList<>();

            for (int i = 0; i < data.length(); i++) {
                JSONObject obj = data.getJSONObject(i);
                entries.add(new PieEntry((float) obj.getInt("cantidad"), obj.getString("nombre")));
            }

            PieDataSet dataSet = new PieDataSet(entries, "");
            dataSet.setColors(new int[]{Color.rgb(177, 16, 16), Color.rgb(33, 150, 243), Color.rgb(76, 175, 80), Color.rgb(255, 152, 0), Color.GRAY});
            dataSet.setValueTextColor(Color.WHITE);
            dataSet.setValueTextSize(12f);

            PieData pieData = new PieData(dataSet);
            chartProductos.setData(pieData);
            chartProductos.setCenterText("Top Productos");
            chartProductos.setHoleRadius(45f);
            chartProductos.animateY(1000);
            chartProductos.invalidate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    private String realizarPeticion(String urlStr) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = in.readLine()) != null) response.append(line);
        return response.toString();
    }
}