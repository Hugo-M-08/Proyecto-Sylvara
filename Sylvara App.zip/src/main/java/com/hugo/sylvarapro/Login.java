package com.hugo.sylvarapro;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import android.os.Build;
import androidx.annotation.NonNull;

public class Login extends AppCompatActivity {

    EditText ET_Correo, ET_Contraseña;
    Button BTN_IniciarSe;
    TextView TV_Registrarse;
    Switch SW_Recordar;

    private Executor executor;
    private Handler handler;
    private ConectaWebServiceLogin webService;

    private static final int CODIGO_PERMISOS = 100;
    private final String[] PERMISOS = {
            Manifest.permission.CAMERA,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.POST_NOTIFICATIONS
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences preferences = getSharedPreferences("user_session", MODE_PRIVATE);

        boolean permisosSolicitados = preferences.getBoolean("permisos_solicitados", false);
        if (!permisosSolicitados) {
            solicitarPermisos();
        }

        boolean sesionActiva = preferences.getBoolean("sesion_activa", false);
        if (sesionActiva) {
            String correoGuardado = preferences.getString("gmail", "");
            String passGuardada = preferences.getString("pass_temp", "");
            redirigirUsuario(correoGuardado, passGuardada);
            return;
        }

        setContentView(R.layout.activity_login);

        ET_Correo = findViewById(R.id.ET_Correo);
        ET_Contraseña = findViewById(R.id.ET_Contraseña);
        BTN_IniciarSe = findViewById(R.id.BTN_IniciarSe);
        TV_Registrarse = findViewById(R.id.TV_Registrarse);
        SW_Recordar = findViewById(R.id.SW_Recordar);

        handler = new Handler(Looper.getMainLooper());
        executor = Executors.newSingleThreadExecutor();
        webService = new ConectaWebServiceLogin();

        BTN_IniciarSe.setOnClickListener(v -> {
            String correo = ET_Correo.getText().toString().trim();
            String contrasena = ET_Contraseña.getText().toString().trim();

            if (correo.isEmpty() || contrasena.isEmpty()) {
                Toast.makeText(this, "Por favor llena todos los campos", Toast.LENGTH_SHORT).show();
                return;
            }

            executor.execute(() -> {
                webService.login(correo, contrasena, new ConectaWebServiceLogin.Callback<JSONObject>() {
                    @Override
                    public void onSuccess(JSONObject result) {
                        handler.post(() -> {
                            try {
                                // Verificamos si el usuario está baneado
                                int estado = result.getInt("estado");

                                if (estado == 0) { // 0 = baneado
                                    Toast.makeText(Login.this,
                                            "Tu cuenta ha sido suspendida.\nContacta al administrador para más información.",
                                            Toast.LENGTH_LONG).show();
                                    return; // No continuamos con el login
                                }

                                // Usuario ACTIVO → procedemos normalmente
                                SharedPreferences.Editor editor = preferences.edit();
                                editor.putString("id_usuario", result.getString("id_usuario"));
                                editor.putString("nombre", result.getString("nombre"));
                                editor.putString("gmail", result.getString("gmail"));
                                editor.putString("pass_temp", contrasena);
                                editor.putBoolean("sesion_activa", SW_Recordar.isChecked());
                                editor.apply();

                                Toast.makeText(Login.this, "Login exitoso", Toast.LENGTH_LONG).show();
                                redirigirUsuario(correo, contrasena);

                            } catch (Exception e) {
                                Toast.makeText(Login.this,
                                        "Error al procesar la respuesta del servidor",
                                        Toast.LENGTH_LONG).show();
                            }
                        });
                    }

                    @Override
                    public void onError(String error) {
                        handler.post(() ->
                                Toast.makeText(Login.this, error, Toast.LENGTH_LONG).show()
                        );
                    }
                });
            });
        });

        TV_Registrarse.setOnClickListener(v ->
                startActivity(new Intent(Login.this, Registro.class))
        );
    }

    private void solicitarPermisos() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(PERMISOS, CODIGO_PERMISOS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CODIGO_PERMISOS) {
            SharedPreferences preferences = getSharedPreferences("user_session", MODE_PRIVATE);
            preferences.edit().putBoolean("permisos_solicitados", true).apply();
        }
    }

    private void redirigirUsuario(String correo, String contrasena) {
        Intent i;
        if (correo.equals("hugomanuel2099@gmail.com") && contrasena.equals("123456")) {
            i = new Intent(this, InicioAdmin.class);
        } else {
            i = new Intent(this, MainActivity.class);
        }
        startActivity(i);
        finish();
    }
}
