package com.hugo.sylvarapro;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

//no hay ip

public class AgregarBolitas extends AppCompatActivity {
    private Spinner spNombreBolita;
    private EditText etHumMin, etHumMax, etLuzMin, etLuzMax, etHumSuelMin, etHumSuelMax;
    private Button btnSubirBolita;
    private ImageButton btnSubirFoto;
    private ConectaWebServiceTienda webServiceTienda;
    private ConectaWebServiceBolitas webServiceBolitas;
    private List<Item_Productos> productos;
    private String imagenBase64;
    private ActivityResultLauncher<Intent> imagePickerLauncher;
    private Item_Bolita bolita;
    private boolean isEditing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_agregar_bolitas);

        // Inicializar vistas
        spNombreBolita = findViewById(R.id.SP_NombreBolita);
        etHumMin = findViewById(R.id.ET_HumMin);
        etHumMax = findViewById(R.id.ET_HumMaz);
        etLuzMin = findViewById(R.id.ET_LuzMin);
        etLuzMax = findViewById(R.id.ET_LuzMax);
        etHumSuelMin = findViewById(R.id.ET_HumSuelMin);
        etHumSuelMax = findViewById(R.id.ET_HumSuelMax);
        btnSubirBolita = findViewById(R.id.BTN_SubirNuevaBolita);
        btnSubirFoto = findViewById(R.id.BTN_SubirFotoBolita);

        // Corregir hints de los EditText
        etLuzMax.setHint("Luz Máxima");
        etHumSuelMin.setHint("Humedad Suelo Mínima");
        etHumSuelMax.setHint("Humedad Suelo Máxima");

        // Inicializar servicios
        webServiceTienda = new ConectaWebServiceTienda();
        webServiceBolitas = new ConectaWebServiceBolitas();
        productos = new ArrayList<>();

        // Configurar launcher para seleccionar imagen
        imagePickerLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), result.getData().getData());
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                    byte[] byteArray = stream.toByteArray();
                    imagenBase64 = Base64.encodeToString(byteArray, Base64.DEFAULT);
                    Toast.makeText(this, "Imagen seleccionada", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Error al cargar imagen: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });

        // Verificar si es edición
        Item_Productos producto = getIntent().getParcelableExtra("producto");
        bolita = getIntent().getParcelableExtra("bolita");
        if (bolita != null) {
            isEditing = true;
            btnSubirBolita.setText("Actualizar Bolita");
            precargarValores(bolita);
        } else if (producto != null) {
            // Si solo se pasa el producto, permitir inserción
            isEditing = false;
            btnSubirBolita.setText("Subir Bolita");
        }

        // Cargar productos en el Spinner
        cargarProductosSpinner(producto);

        // Botón Subir Foto
        btnSubirFoto.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            imagePickerLauncher.launch(intent);
        });

        // Botón Subir/Actualizar Bolita
        btnSubirBolita.setOnClickListener(v -> {
            Item_Productos productoSeleccionado = (Item_Productos) spNombreBolita.getSelectedItem();
            if (productoSeleccionado == null) {
                Toast.makeText(this, "Seleccione una bolita", Toast.LENGTH_SHORT).show();
                return;
            }

            String humMin = etHumMin.getText().toString().trim();
            String humMax = etHumMax.getText().toString().trim();
            String luzMin = etLuzMin.getText().toString().trim();
            String luzMax = etLuzMax.getText().toString().trim();
            String humSuelMin = etHumSuelMin.getText().toString().trim();
            String humSuelMax = etHumSuelMax.getText().toString().trim();

            if (humMin.isEmpty() || humMax.isEmpty() || luzMin.isEmpty() || luzMax.isEmpty() ||
                    humSuelMin.isEmpty() || humSuelMax.isEmpty()) {
                Toast.makeText(this, "Complete todos los campos", Toast.LENGTH_SHORT).show();
                return;
            }

            if (isEditing) {
                webServiceBolitas.actualizarBolita(
                        String.valueOf(bolita.getIdBolitas()),
                        productoSeleccionado.getId_producto(),
                        productoSeleccionado.getNombre(),
                        humMin, humMax, luzMin, luzMax, humSuelMin, humSuelMax,
                        imagenBase64,
                        new ConectaWebServiceBolitas.Callback<String>() {
                            @Override
                            public void onSuccess(String result) {
                                runOnUiThread(() -> {
                                    Toast.makeText(AgregarBolitas.this, result, Toast.LENGTH_SHORT).show();
                                    finish();
                                });
                            }

                            @Override
                            public void onError(String error) {
                                runOnUiThread(() -> {
                                    Toast.makeText(AgregarBolitas.this, "Error: " + error, Toast.LENGTH_LONG).show();
                                });
                            }
                        });
            } else {
                webServiceBolitas.insertarBolita(
                        productoSeleccionado.getId_producto(),
                        productoSeleccionado.getNombre(),
                        humMin, humMax, luzMin, luzMax, humSuelMin, humSuelMax,
                        imagenBase64,
                        new ConectaWebServiceBolitas.Callback<String>() {
                            @Override
                            public void onSuccess(String result) {
                                runOnUiThread(() -> {
                                    Toast.makeText(AgregarBolitas.this, result, Toast.LENGTH_SHORT).show();
                                    finish();
                                });
                            }

                            @Override
                            public void onError(String error) {
                                runOnUiThread(() -> {
                                    Toast.makeText(AgregarBolitas.this, "Error: " + error, Toast.LENGTH_LONG).show();
                                });
                            }
                        });
            }
        });
    }

    private void cargarProductosSpinner(Item_Productos productoSeleccionado) {
        webServiceTienda.obtenerProductos(new ConectaWebServiceTienda.Callback<List<Item_Productos>>() {
            @Override
            public void onSuccess(List<Item_Productos> result) {
                runOnUiThread(() -> {
                    productos.clear();
                    productos.addAll(result.stream()
                            .filter(p -> p.getNombre().toLowerCase().contains("bolita"))
                            .collect(Collectors.toList()));
                    ArrayAdapter<Item_Productos> adapter = new ArrayAdapter<>(
                            AgregarBolitas.this, android.R.layout.simple_spinner_item, productos) {
                        @Override
                        public View getView(int position, View convertView, ViewGroup parent) {
                            View view = super.getView(position, convertView, parent);
                            TextView textView = (TextView) view;
                            textView.setText(productos.get(position).getNombre());
                            return view;
                        }

                        @Override
                        public View getDropDownView(int position, View convertView, ViewGroup parent) {
                            View view = super.getDropDownView(position, convertView, parent);
                            TextView textView = (TextView) view;
                            textView.setText(productos.get(position).getNombre());
                            return view;
                        }
                    };
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spNombreBolita.setAdapter(adapter);
                    if (productoSeleccionado != null) {
                        for (int i = 0; i < productos.size(); i++) {
                            if (productos.get(i).getId_producto().equals(productoSeleccionado.getId_producto())) {
                                spNombreBolita.setSelection(i);
                                break;
                            }
                        }
                    }
                    if (productos.isEmpty()) {
                        Toast.makeText(AgregarBolitas.this, "No hay bolitas disponibles", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    Toast.makeText(AgregarBolitas.this, "Error: " + error, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void precargarValores(Item_Bolita bolita) {
        etHumMin.setText(bolita.getHumMin());
        etHumMax.setText(bolita.getHumMax());
        etLuzMin.setText(bolita.getLuzMin());
        etLuzMax.setText(bolita.getLuzMax());
        etHumSuelMin.setText(bolita.getHumSueloMin());
        etHumSuelMax.setText(bolita.getHumSueloMax());
        imagenBase64 = bolita.getImagen();
    }
}