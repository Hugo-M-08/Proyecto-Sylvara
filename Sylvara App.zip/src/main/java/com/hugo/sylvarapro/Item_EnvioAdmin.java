package com.hugo.sylvarapro;

public class Item_EnvioAdmin {
    private int id_detalle;
    private int id_compras;
    private String fecha;
    private String producto;
    private int cantidad;
    private double precio_unitario;
    private double total;
    private String status;

    public Item_EnvioAdmin(int id_detalle, int id_compras, String fecha, String producto, int cantidad, double precio_unitario, double total, String status) {
        this.id_detalle = id_detalle;
        this.id_compras = id_compras;
        this.fecha = fecha;
        this.producto = producto;
        this.cantidad = cantidad;
        this.precio_unitario = precio_unitario;
        this.total = total;
        this.status = status;
    }

    // Getters
    public int getId_detalle() {
        return id_detalle;
    }

    public int getId_compras() {
        return id_compras;
    }

    public String getFecha() {
        return fecha;
    }

    public String getProducto() {
        return producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public double getPrecio_unitario() {
        return precio_unitario;
    }

    public double getTotal() {
        return total;
    }

    public String getStatus() {
        return status;
    }

    // Setter for status (if needed for updates)
    public void setStatus(String status) {
        this.status = status;
    }
}