package com.hugo.sylvarapro;

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class ConectaWebServicePerfil {
    private static final String CARPETA_PERFIL = "Perfil/";

    private static final String VER_PERFIL_URL = Configuracion.getUrlBase() + CARPETA_PERFIL + "ver_perfil.php";
    private static final String CAMBIAR_CONTRASENA_URL = Configuracion.getUrlBase() + CARPETA_PERFIL + "cambiar_contrasena.php";
    private static final String ACTUALIZAR_FOTO_URL = Configuracion.getUrlBase() + CARPETA_PERFIL + "actualizar_foto.php";
    private static final String BORRAR_CUENTA_URL = Configuracion.getUrlBase() + CARPETA_PERFIL + "borrar_cuenta.php";

    public interface Callback<T> {
        void onSuccess(T result);
        void onError(String error);
    }

    public void verPerfil(String id_usuario, Callback<JSONObject> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            String result = "";
            try {
                URL url = new URL(VER_PERFIL_URL + "?id_usuario=" + URLEncoder.encode(id_usuario, "UTF-8"));
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("GET");

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        response.append(linea);
                    }
                    reader.close();
                    result = response.toString();

                    if (result.equals("001")) {
                        callback.onError("ID de usuario faltante");
                        return;
                    } else if (result.equals("010")) {
                        callback.onError("Usuario no encontrado");
                        return;
                    }

                    JSONObject jsonObject = new JSONObject(result);
                    callback.onSuccess(jsonObject);
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception e) {
                callback.onError("Error de servidor: " + e.getMessage());
            }
        });
    }

    public void cambiarContrasena(String id_usuario, String nuevaContrasena, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            String aux = "";
            try {
                URL url = new URL(CAMBIAR_CONTRASENA_URL);
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                String data = "id_usuario=" + URLEncoder.encode(id_usuario, "UTF-8");
                datSal.write(data);
                data = "&nueva_contraseña=" + URLEncoder.encode(nuevaContrasena, "UTF-8");
                datSal.write(data);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    String linea = reader.readLine();
                    while (linea != null) {
                        aux = aux + linea;
                        linea = reader.readLine();
                    }
                    reader.close();
                    if (aux.equals("002")) {
                        aux = "Contraseña cambiada correctamente";
                    } else if (aux.equals("001")) {
                        aux = "Datos faltantes";
                    } else if (aux.equals("000")) {
                        aux = "No se pudo cambiar la contraseña";
                    } else {
                        aux = "Error desconocido: " + aux;
                    }
                    callback.onSuccess(aux);
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception ex) {
                callback.onError("Error de servidor: " + ex.getMessage());
            }
        });
    }
    public void actualizarFoto(String id_usuario, String fotoBase64, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(ACTUALIZAR_FOTO_URL);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("POST");
                con.setDoOutput(true);
                OutputStreamWriter out = new OutputStreamWriter(con.getOutputStream());
                out.write("id_usuario=" + URLEncoder.encode(id_usuario, "UTF-8") + "&foto=" + URLEncoder.encode(fotoBase64, "UTF-8"));
                out.flush();
                out.close();

                if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    callback.onSuccess("002");
                }
                con.disconnect();
            } catch (Exception e) { callback.onError(e.getMessage()); }
        });
    }

    public void borrarCuenta(String id_usuario, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(BORRAR_CUENTA_URL + "?id_usuario=" + URLEncoder.encode(id_usuario, "UTF-8"));
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    callback.onSuccess("002");
                }
                con.disconnect();
            } catch (Exception e) { callback.onError(e.getMessage()); }
        });
    }
}