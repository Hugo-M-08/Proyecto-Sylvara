package com.hugo.sylvarapro;

public class Item_Producto {
    private String id_producto;
    private int cantidad;
    private String precio_unitario;

    public Item_Producto(String id_producto, int cantidad, String precio_unitario) {
        this.id_producto = id_producto;
        this.cantidad = cantidad;
        this.precio_unitario = precio_unitario;
    }

    // Getters
    public String getId_producto() {
        return id_producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public String getPrecio_unitario() {
        return precio_unitario;
    }
}