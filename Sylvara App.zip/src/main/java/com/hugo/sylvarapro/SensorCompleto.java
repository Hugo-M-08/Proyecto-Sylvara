package com.hugo.sylvarapro;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.Executors;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.os.Environment;
import java.io.File;
import java.io.FileOutputStream;


public class SensorCompleto extends AppCompatActivity {

    private TextView tvNombre, tvTipo, tvEstatus;
    private View viewIndicador;
    private Button btnApagar, btnEliminar, btnHoy, btnSemana, btnMes, btnDescargarPDF;
    private Item_Sensor sensor;
    private LineChart lineChart;

    private ArrayList<Entry> entradasActuales = new ArrayList<>();
    private ArrayList<String> etiquetasActuales = new ArrayList<>();
    private String rangoActual = "hoy";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sensor_completo);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tvNombre = findViewById(R.id.TV_DetalleNombre);
        tvTipo = findViewById(R.id.TV_DetalleTipo);
        tvEstatus = findViewById(R.id.TV_EstatusActual);
        viewIndicador = findViewById(R.id.viewIndicadorEstado);
        btnApagar = findViewById(R.id.BTN_AccionApagar);
        btnEliminar = findViewById(R.id.BTN_AccionEliminar);
        btnHoy = findViewById(R.id.btnHoy);
        btnSemana = findViewById(R.id.btnSemana);
        btnMes = findViewById(R.id.btnMes);
        btnDescargarPDF = findViewById(R.id.BTN_DescargarPDF);
        lineChart = findViewById(R.id.lineChart);

        sensor = getIntent().getParcelableExtra("sensor");

        if (sensor != null) {
            llenarDatos();
            obtenerHistorialServidor(sensor.getIdSensor(), "hoy");
        }

        btnHoy.setOnClickListener(v -> obtenerHistorialServidor(sensor.getIdSensor(), "hoy"));
        btnSemana.setOnClickListener(v -> obtenerHistorialServidor(sensor.getIdSensor(), "semana"));
        btnMes.setOnClickListener(v -> obtenerHistorialServidor(sensor.getIdSensor(), "mes"));

        btnApagar.setOnClickListener(v ->
                Toast.makeText(this, "Función de apagado próximamente", Toast.LENGTH_SHORT).show());

        btnEliminar.setOnClickListener(v ->
                Toast.makeText(this, "Función de eliminación próximamente", Toast.LENGTH_SHORT).show());

        btnDescargarPDF.setOnClickListener(v -> generarPDFHistorial());
    }

    private void llenarDatos() {
        tvNombre.setText(sensor.getNombre());
        tvTipo.setText("Tipo: " + sensor.getTipoSensor());

        if (sensor.isEncendido()) {
            tvEstatus.setText("Sensor Activo (ON)");
            viewIndicador.setBackgroundColor(Color.GREEN);
            btnApagar.setText("Apagar Dispositivo");
        } else {
            tvEstatus.setText("Sensor Inactivo (OFF)");
            viewIndicador.setBackgroundColor(Color.RED);
            btnApagar.setText("Encender Dispositivo");
        }
    }

    private void obtenerHistorialServidor(int id, String rango) {
        this.rangoActual = rango;

        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() +
                        "Sensores/obtener_historial_sensor.php?id_sensor=" + id + "&rango=" + rango);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                if (conn.getResponseCode() == 200) {
                    BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    JSONObject jsonRes = new JSONObject(rd.readLine());

                    if (jsonRes.getString("status").equals("success")) {
                        JSONArray data = jsonRes.getJSONArray("data");

                        ArrayList<Entry> entradas = new ArrayList<>();
                        ArrayList<String> etiquetas = new ArrayList<>();

                        for (int i = 0; i < data.length(); i++) {
                            JSONObject obj = data.getJSONObject(i);
                            entradas.add(new Entry(i, (float) obj.getDouble("valor")));
                            etiquetas.add(obj.getString("etiqueta"));
                        }

                        runOnUiThread(() -> {
                            mostrarGrafica(entradas, etiquetas, rango);
                            // Guardamos para el PDF
                            this.entradasActuales = entradas;
                            this.etiquetasActuales = etiquetas;
                        });
                    }
                }
                conn.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(this, "Error al cargar historial", Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void mostrarGrafica(ArrayList<Entry> entradas, ArrayList<String> etiquetas, String rango) {
        String titulo = "Lecturas - " + rango.toUpperCase();

        LineDataSet dataSet = new LineDataSet(entradas, titulo);
        dataSet.setColor(Color.parseColor("#4CAF50"));
        dataSet.setCircleColor(Color.parseColor("#2E7D32"));
        dataSet.setLineWidth(2.5f);
        dataSet.setDrawFilled(true);
        dataSet.setFillColor(Color.parseColor("#C8E6C9"));
        dataSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);

        LineData lineData = new LineData(dataSet);
        lineChart.setData(lineData);

        XAxis xAxis = lineChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(etiquetas));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);

        lineChart.getDescription().setEnabled(false);
        lineChart.animateY(800);
        lineChart.invalidate();
    }


    private void generarPDFHistorial() {
        if (entradasActuales.isEmpty()) {
            Toast.makeText(this, "No hay datos para generar el PDF", Toast.LENGTH_SHORT).show();
            return;
        }

        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                PdfDocument document = new PdfDocument();
                PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(595, 842, 1).create();
                PdfDocument.Page page = document.startPage(pageInfo);
                Canvas canvas = page.getCanvas();
                Paint paint = new Paint();

                paint.setColor(Color.parseColor("#E8F5E9"));
                canvas.drawRect(0, 0, 595, 120, paint);

                Bitmap logo = BitmapFactory.decodeResource(getResources(), R.drawable.logo);
                if (logo != null) {
                    int logoSize = 80;
                    Bitmap scaledLogo = Bitmap.createScaledBitmap(logo, logoSize, logoSize, true);
                    float logoX = 595 - logoSize - 40;
                    float logoY = 20;
                    canvas.drawBitmap(scaledLogo, logoX, logoY, null);
                }

                paint.setColor(Color.BLACK);
                paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
                paint.setTextSize(24f);
                canvas.drawText("SYLVARA", 50, 60, paint);

                paint.setTextSize(14f);
                paint.setTypeface(Typeface.DEFAULT);
                canvas.drawText("Reporte de Historial de Sensor", 50, 85, paint);

                paint.setTextSize(12f);
                canvas.drawText("Sensor: " + sensor.getNombre(), 50, 110, paint);
                canvas.drawText("Tipo: " + sensor.getTipoSensor(), 50, 128, paint);
                canvas.drawText("Período: " + rangoActual.toUpperCase(), 50, 146, paint);


                Bitmap chartBitmap = lineChart.getChartBitmap();
                if (chartBitmap != null) {
                    Bitmap scaledChart = Bitmap.createScaledBitmap(chartBitmap, 500, 280, true);
                    canvas.drawBitmap(scaledChart, 50, 170, null); // Posición debajo del encabezado
                } else {
                    paint.setTextSize(14f);
                    canvas.drawText("No se pudo capturar el gráfico", 50, 200, paint);
                }

                paint.setTextSize(10f);
                paint.setColor(Color.GRAY);
                canvas.drawText("Generado el " + new java.util.Date().toString(), 50, 800, paint);

                document.finishPage(page);

                File folder = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (folder != null && !folder.exists()) folder.mkdirs();

                File pdfFile = new File(folder, "Historial_" + sensor.getNombre().replace(" ", "_") + "_" + rangoActual + ".pdf");

                document.writeTo(new FileOutputStream(pdfFile));
                document.close();

                runOnUiThread(() -> {
                    Toast.makeText(this, "PDF guardado en Descargas", Toast.LENGTH_LONG).show();
                    abrirPDF(pdfFile);
                });

            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() ->
                        Toast.makeText(this, "Error al generar PDF: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private void abrirPDF(File file) {
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".provider", file);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, "application/pdf");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(intent, "Abrir PDF"));
    }

}