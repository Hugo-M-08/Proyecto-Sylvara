package com.hugo.sylvarapro;

import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class EnviosAdmin extends Fragment {
    private RecyclerView RV_EnvioSeguimiento;
    private AdaptadorEnviosAdmin adapter;
    private ConectaWebServiceEnviosAdmin webService;
    private Button IrGraficas;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_envios_admin, container, false);

        // Inicializar vistas
        RV_EnvioSeguimiento = view.findViewById(R.id.RV_EnvioSeguimiento);
        IrGraficas = view.findViewById(R.id.button2);
        IrGraficas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), VentasGraficas.class);
                startActivity(i);
            }
        });


        // Inicializar servicio Web
        webService = new ConectaWebServiceEnviosAdmin();

        // Configurar RecyclerView
        RV_EnvioSeguimiento.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new AdaptadorEnviosAdmin(getContext(), new ArrayList<>(), this::actualizarEstado);
        RV_EnvioSeguimiento.setAdapter(adapter);
        RV_EnvioSeguimiento.setItemAnimator(new androidx.recyclerview.widget.DefaultItemAnimator());
        // Cargar todos los envíos
        cargarEnvios();

        return view;
    }

    private void cargarEnvios() {
        webService.obtenerTodosEnvios(new ConectaWebServiceEnviosAdmin.Callback<List<Item_EnvioAdmin>>() {
            @Override
            public void onSuccess(List<Item_EnvioAdmin> result) {
                getActivity().runOnUiThread(() -> {
                    adapter.updateEnvios(result);
                    if (result.isEmpty()) {
                        Toast.makeText(getContext(), "No hay envíos registrados", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onError(String error) {
                getActivity().runOnUiThread(() -> Toast.makeText(getContext(), "Error: " + error, Toast.LENGTH_LONG).show());
            }
        });
    }

    // Cambiado: ahora recibe id_compras
    private void actualizarEstado(int id_compras, String nuevoStatus) {
        webService.actualizarEstado(id_compras, nuevoStatus, new ConectaWebServiceEnviosAdmin.Callback<String>() {
            @Override
            public void onSuccess(String result) {
                getActivity().runOnUiThread(() -> {
                    Toast.makeText(getContext(), result, Toast.LENGTH_SHORT).show();
                    cargarEnvios(); // Recargar para actualizar la UI
                });
            }

            @Override
            public void onError(String error) {
                getActivity().runOnUiThread(() -> Toast.makeText(getContext(), "Error: " + error, Toast.LENGTH_LONG).show());
            }
        });
    }
}