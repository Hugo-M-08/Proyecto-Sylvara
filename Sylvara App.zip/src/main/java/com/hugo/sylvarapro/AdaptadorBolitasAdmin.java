package com.hugo.sylvarapro;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;


public class AdaptadorBolitasAdmin extends RecyclerView.Adapter<AdaptadorBolitasAdmin.ViewHolder> {

    private List<Item_Productos> datos;
    private Context context;
    private ConectaWebServiceTienda webServiceTienda;
    private ConectaWebServiceBolitas webServiceBolitas;

    public AdaptadorBolitasAdmin(List<Item_Productos> datos, Context context) {
        this.datos = datos;
        this.context = context;
        this.webServiceTienda = new ConectaWebServiceTienda();
        this.webServiceBolitas = new ConectaWebServiceBolitas();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_admin_bolitas, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item_Productos item = datos.get(position);

        // --- LÓGICA DE IMAGEN BASE64 ---
        String imagenBase64 = item.getImagen();
        if (imagenBase64 != null && !imagenBase64.isEmpty()) {
            try {
                // Si la cadena contiene metadatos (ej. "data:image/jpeg;base64,"), los eliminamos
                if (imagenBase64.contains(",")) {
                    imagenBase64 = imagenBase64.split(",")[1];
                }

                // Decodificamos la cadena Base64 a un arreglo de bytes
                byte[] decodedString = Base64.decode(imagenBase64, Base64.DEFAULT);
                // Convertimos los bytes en un objeto Bitmap de Android
                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

                // Asignamos el Bitmap directamente al ImageView
                holder.imgProducto.setImageBitmap(decodedByte);
            } catch (Exception e) {
                // En caso de error en la decodificación, mostramos imagen de error
                holder.imgProducto.setImageResource(R.drawable.error);
            }
        } else {
            // Si no hay imagen en la BD, mostramos imagen por defecto
            holder.imgProducto.setImageResource(R.drawable.carga);
        }

        holder.txtNombre.setText(item.getNombre());

        // Configura el Listener para el botón de Editar.
        holder.btnEditar.setOnClickListener(v -> {
            webServiceBolitas.obtenerBolita(item.getId_producto(), new ConectaWebServiceBolitas.Callback<Item_Bolita>() {
                @Override
                public void onSuccess(Item_Bolita bolita) {
                    Intent intent = new Intent(context, AgregarBolitas.class);
                    intent.putExtra("producto", item);
                    intent.putExtra("bolita", bolita);
                    context.startActivity(intent);
                }

                @Override
                public void onError(String error) {
                    if (context instanceof FragmentActivity) {
                        ((FragmentActivity) context).runOnUiThread(() -> {
                            // Si no hay configuración de bolita previa, abrimos para crear una nueva
                            Intent intent = new Intent(context, AgregarBolitas.class);
                            intent.putExtra("producto", item);
                            context.startActivity(intent);
                        });
                    }
                }
            });
        });

        // Configura el Listener para el botón de Borrar.
        holder.btnBorrar.setOnClickListener(v -> {
            webServiceTienda.eliminarProducto(item.getId_producto(), new ConectaWebServiceTienda.Callback<String>() {
                @Override
                public void onSuccess(String result) {
                    if (context instanceof FragmentActivity) {
                        ((FragmentActivity) context).runOnUiThread(() -> {
                            int pos = holder.getAdapterPosition();
                            if (pos != RecyclerView.NO_POSITION) {
                                datos.remove(pos);
                                notifyItemRemoved(pos);
                                notifyItemRangeChanged(pos, datos.size());
                                Toast.makeText(context, "Eliminado correctamente", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }

                @Override
                public void onError(String error) {
                    if (context instanceof FragmentActivity) {
                        ((FragmentActivity) context).runOnUiThread(() -> {
                            Toast.makeText(context, "Error: " + error, Toast.LENGTH_LONG).show();
                        });
                    }
                }
            });
        });
    }

    @Override
    public int getItemCount() {
        return datos.size();
    }

    public void updateBolitas(List<Item_Productos> nuevosDatos) {
        this.datos.clear();
        this.datos.addAll(nuevosDatos);
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgProducto;
        TextView txtNombre;
        ImageButton btnEditar, btnBorrar;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgProducto = itemView.findViewById(R.id.IM_Producto);
            txtNombre = itemView.findViewById(R.id.textView6);
            btnEditar = itemView.findViewById(R.id.imageButton3);
            btnBorrar = itemView.findViewById(R.id.imageButton4);
        }
    }
}