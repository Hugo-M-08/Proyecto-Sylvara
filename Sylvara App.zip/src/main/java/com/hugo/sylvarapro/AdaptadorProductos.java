package com.hugo.sylvarapro;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
//hay ip
public class AdaptadorProductos extends RecyclerView.Adapter<AdaptadorProductos.ViewHolder> {
    private List<Item_Productos> datos;
    private Context context;
    private OnItemClickListener listener;
    private OnCarritoClickListener carritoListener;

    public interface OnItemClickListener { void onItemClick(int position); }
    public interface OnCarritoClickListener { void onCarritoClick(int position, int cantidad); }

    public AdaptadorProductos(List<Item_Productos> datos, Context context) {
        this.datos = datos;
        this.context = context;
    }

    public void setOnItemClickListener(OnItemClickListener listener) { this.listener = listener; }
    public void setOnCarritoClickListener(OnCarritoClickListener cl) { this.carritoListener = cl; }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_product, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item_Productos item = datos.get(position);

        // --- LÓGICA DE IMAGEN BASE64 ---
        String imagenBase64 = item.getImagen();
        if (imagenBase64 != null && !imagenBase64.isEmpty()) {
            try {
                // Limpieza de prefijos comunes en Base64
                if (imagenBase64.contains(",")) {
                    imagenBase64 = imagenBase64.split(",")[1];
                }
                byte[] decodedString = Base64.decode(imagenBase64, Base64.DEFAULT);
                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                holder.imgProducto.setImageBitmap(decodedByte);
            } catch (Exception e) {
                holder.imgProducto.setImageResource(R.drawable.error);
            }
        } else {
            holder.imgProducto.setImageResource(R.drawable.carga);
        }

        holder.txtTitulo.setText(item.getNombre());
        holder.txtPrecio.setText("$" + item.getPrecio());

        // Lógica de Stock Dinámico para el Spinner
        int stockDisponible = 0;
        try {
            stockDisponible = Integer.parseInt(item.getUnidades());
        } catch (NumberFormatException e) {
            stockDisponible = 0;
        }

        int limiteMaximo = Math.min(stockDisponible, 10);

        List<Integer> opcionesStock = new ArrayList<>();
        for (int i = 1; i <= limiteMaximo; i++) {
            opcionesStock.add(i);
        }

        ArrayAdapter<Integer> adapter = new ArrayAdapter<>(context, android.R.layout.simple_spinner_item, opcionesStock);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        holder.spCantidad.setAdapter(adapter);

        holder.btnAgregarCarrito.setOnClickListener(v -> {
            if (carritoListener != null && !opcionesStock.isEmpty()) {
                int cantidad = (int) holder.spCantidad.getSelectedItem();
                carritoListener.onCarritoClick(position, cantidad);
            } else if (opcionesStock.isEmpty()) {
                Toast.makeText(context, "Sin stock disponible", Toast.LENGTH_SHORT).show();
            }
        });

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onItemClick(position);
        });
    }
    @Override
    public int getItemCount() { return datos.size(); }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgProducto;
        TextView txtTitulo, txtPrecio;
        ImageButton btnAgregarCarrito;
        Spinner spCantidad;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgProducto = itemView.findViewById(R.id.IMG_Producto);
            txtTitulo = itemView.findViewById(R.id.TV_Titulo);
            txtPrecio = itemView.findViewById(R.id.TV_Precio);
            btnAgregarCarrito = itemView.findViewById(R.id.BTN_AgregarCarrito);
            spCantidad = itemView.findViewById(R.id.SP_Cantidad);
        }
    }
}