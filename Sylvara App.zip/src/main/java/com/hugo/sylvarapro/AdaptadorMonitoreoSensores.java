package com.hugo.sylvarapro;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class AdaptadorMonitoreoSensores extends RecyclerView.Adapter<AdaptadorMonitoreoSensores.ViewHolder> {
    private List<Item_LecturaSensor> datos;
    private Context context;
    private OnRelayToggleListener relayToggleListener;

    public interface OnRelayToggleListener {
        void onToggleRelay(int sensorId, String currentStatus);
    }

    public AdaptadorMonitoreoSensores(Context context, List<Item_LecturaSensor> datos, OnRelayToggleListener listener) {
        this.context = context;
        this.datos = datos;
        this.relayToggleListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_lectura_sensor, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item_LecturaSensor lectura = datos.get(position);
        holder.tvNombreSensor.setText(lectura.getNombre_sensor());
        holder.tvTipoSensor.setText("Tipo: " + lectura.getTipo_sensor());
        holder.tvValor.setText("Valor: " + String.format("%.2f", lectura.getValor()) + (lectura.getTipo_sensor().contains("Humedad") ? "%" : ""));
        holder.tvFechaHora.setText("Fecha: " + lectura.getFecha_hora());

        if (lectura.getTipo_sensor().equals("Bomba de Agua") && lectura.getRelay_status() != null) {
            holder.tvRelayStatus.setVisibility(View.VISIBLE);
            holder.tvRelayStatus.setText("Estado Relé: " + lectura.getRelay_status());
            holder.btnToggleRelay.setVisibility(View.VISIBLE);
            holder.btnToggleRelay.setText(lectura.getRelay_status().equals("ON") ? "Apagar Relé" : "Encender Relé");
            holder.btnToggleRelay.setBackgroundTintList(context.getResources().getColorStateList(
                    lectura.getRelay_status().equals("ON") ? R.color.red : R.color.green));
            holder.btnToggleRelay.setOnClickListener(v -> {
                String newStatus = lectura.getRelay_status().equals("ON") ? "OFF" : "ON";
                relayToggleListener.onToggleRelay(lectura.getSensor_id(), newStatus);
            });
        } else {
            holder.tvRelayStatus.setVisibility(View.GONE);
            holder.btnToggleRelay.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return datos.size();
    }

    public void updateLecturas(List<Item_LecturaSensor> nuevasLecturas) {
        datos.clear();
        datos.addAll(nuevasLecturas);
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvNombreSensor, tvTipoSensor, tvValor, tvFechaHora, tvRelayStatus;
        Button btnToggleRelay;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombreSensor = itemView.findViewById(R.id.tvNombreSensor);
            tvTipoSensor = itemView.findViewById(R.id.tvTipoSensor);
            tvValor = itemView.findViewById(R.id.tvValor);
            tvFechaHora = itemView.findViewById(R.id.tvFechaHora);
            tvRelayStatus = itemView.findViewById(R.id.tvRelayStatus);
            btnToggleRelay = itemView.findViewById(R.id.btnToggleRelay);
        }
    }
}