package com.hugo.sylvarapro;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import android.util.Log;
import java.util.HashMap;
import java.util.stream.Collectors;

public class ConectaWebServiceSensores {
    private static final String TAG = "ConectaWebServiceSensores";
    // Usamos tu clase para definir la base del módulo
    private static final String BASE_URL = Configuracion.getUrlBase() + "Sensores/";

    private static final String INSERTAR_SENSOR_URL = BASE_URL + "insertar_sensor.php";
    private static final String OBTENER_SENSORES_URL = BASE_URL + "ver_sensores.php";
    private static final String ELIMINAR_SENSOR_URL = BASE_URL + "eliminar_sensor_app.php";
    private static final String OBTENER_VALORES_URL = BASE_URL + "obtener_valores_sensores.php";
    private static final String ACTUALIZAR_LECTURA_URL = BASE_URL + "actualizar_lectura_sensor.php";
    private static final String OBTENER_LECTURAS_URL = BASE_URL + "obtener_lecturas_sensores.php";

    public interface Callback<T> {
        void onSuccess(T result);
        void onError(String error);
    }

    public void obtenerSensores(int idInvernadero, Callback<List<Item_Sensor>> callback) {
        if (idInvernadero <= 0) {
            callback.onError("ID de invernadero inválido");
            return;
        }

        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(OBTENER_SENSORES_URL);
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String postData = "id_invernadero=" + idInvernadero;
                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(postData);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        response.append(linea);
                    }
                    reader.close();

                    JSONObject jsonResponse = new JSONObject(response.toString());
                    String code = jsonResponse.getString("code");

                    if (code.equals("002")) {
                        List<Item_Sensor> sensores = new ArrayList<>();
                        JSONArray jsonArray = jsonResponse.getJSONArray("data");

                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject json = jsonArray.getJSONObject(i);
                            boolean encendido = "ON".equals(json.getString("estado_rele"));
                            sensores.add(new Item_Sensor(
                                    json.getInt("id_sensores"),
                                    json.getString("nombre"),
                                    json.getInt("id_invernadero"),
                                    json.getString("tipo_sensor"),
                                    encendido
                            ));
                        }
                        callback.onSuccess(sensores);
                    } else if (code.equals("010")) {
                        callback.onSuccess(new ArrayList<>());
                    } else {
                        callback.onError(jsonResponse.optString("message", "Error desconocido"));
                    }
                } else {
                    callback.onError("Error HTTP: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception ex) {
                Log.e(TAG, "Error obtenerSensores: " + ex.getMessage());
                callback.onError("Excepción: " + ex.getMessage());
            }
        });
    }

    public void insertarSensor(String nombre, int idInvernadero, String tipoSensor, Callback<String> callback) {
        if (idInvernadero <= 0) {
            callback.onError("ID de invernadero inválido");
            return;
        }
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(INSERTAR_SENSOR_URL);
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String postData = "nombre=" + URLEncoder.encode(nombre, "UTF-8") +
                        "&id_invernadero=" + idInvernadero +
                        "&tipo_sensor=" + URLEncoder.encode(tipoSensor, "UTF-8");
                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(postData);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        response.append(linea);
                    }
                    reader.close();
                    JSONObject jsonResponse = new JSONObject(response.toString());
                    String code = jsonResponse.getString("code");
                    if (code.equals("002")) {
                        callback.onSuccess(jsonResponse.getString("message"));
                    } else {
                        callback.onError(jsonResponse.getString("message"));
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception ex) {
                Log.e(TAG, "Error (insertarSensor): " + ex.getMessage());
                callback.onError("Error de servidor: " + ex.getMessage());
            }
        });
    }

    public void eliminarSensor(int idSensor, Callback<String> callback) {
        if (idSensor <= 0) {
            callback.onError("ID de sensor inválido");
            return;
        }
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(ELIMINAR_SENSOR_URL);
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String postData = "id_sensores=" + idSensor;
                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(postData);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        response.append(linea);
                    }
                    reader.close();
                    JSONObject jsonResponse = new JSONObject(response.toString());
                    String code = jsonResponse.getString("code");
                    if (code.equals("002")) {
                        callback.onSuccess(jsonResponse.getString("message"));
                    } else {
                        callback.onError(jsonResponse.getString("message"));
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception ex) {
                Log.e(TAG, "Error (eliminarSensor): " + ex.getMessage());
                callback.onError("Error de servidor: " + ex.getMessage());
            }
        });
    }

    public void obtenerValoresSensores(int idInvernadero, Callback<HashMap<String, Double>> cb) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(OBTENER_VALORES_URL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String postData = "id_invernadero=" + idInvernadero;
                OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
                writer.write(postData);
                writer.flush();
                writer.close();

                if (conn.getResponseCode() == 200) {
                    String res = new BufferedReader(new InputStreamReader(conn.getInputStream()))
                            .lines().collect(Collectors.joining());
                    JSONObject jo = new JSONObject(res);
                    if (!jo.getString("code").equals("002")) {
                        cb.onError("Código: " + jo.optString("code"));
                        return;
                    }
                    JSONObject data = jo.getJSONObject("data");
                    HashMap<String, Double> map = new HashMap<>();
                    if (data.has("humedad")) map.put("humedad", data.getDouble("humedad"));
                    if (data.has("co2")) map.put("co2", data.getDouble("co2"));
                    if (data.has("luz")) map.put("luz", data.getDouble("luz"));
                    cb.onSuccess(map);
                } else cb.onError("HTTP " + conn.getResponseCode());
            } catch (Exception e) {
                cb.onError(e.getMessage());
            }
        });
    }

    public void actualizarLectura(int idSensor, String valor, Callback<String> cb) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(ACTUALIZAR_LECTURA_URL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json");

                JSONObject b = new JSONObject();
                b.put("id_sensor", idSensor);
                b.put("valor", valor);

                OutputStream os = conn.getOutputStream();
                os.write(b.toString().getBytes());
                os.close();

                if (conn.getResponseCode() == 200) {
                    String res = new BufferedReader(new InputStreamReader(conn.getInputStream()))
                            .lines().collect(Collectors.joining());
                    JSONObject jo = new JSONObject(res);
                    if (jo.getString("code").equals("002")) cb.onSuccess(jo.getString("message"));
                    else cb.onError(jo.optString("message"));
                } else cb.onError("HTTP " + conn.getResponseCode());
            } catch (Exception e) {
                cb.onError(e.getMessage());
            }
        });
    }

    public void obtenerLecturasSensores(int idInvernadero, Callback<List<Item_LecturaSensor>> callback) {
        if (idInvernadero <= 0) {
            callback.onError("ID de invernadero inválido");
            return;
        }
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(OBTENER_LECTURAS_URL);
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String postData = "id_invernadero=" + idInvernadero;
                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(postData);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        response.append(linea);
                    }
                    reader.close();

                    JSONObject jsonResponse = new JSONObject(response.toString());
                    String code = jsonResponse.getString("code");
                    if (code.equals("001")) {
                        callback.onError(jsonResponse.getString("message"));
                    } else if (code.equals("010")) {
                        callback.onSuccess(new ArrayList<>());
                    } else if (code.equals("002")) {
                        List<Item_LecturaSensor> lecturas = new ArrayList<>();
                        JSONArray jsonArray = jsonResponse.getJSONArray("data");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject json = jsonArray.getJSONObject(i);
                            lecturas.add(new Item_LecturaSensor(
                                    json.getInt("id_lectura"),
                                    json.getInt("sensor_id"),
                                    json.getString("nombre_sensor"),
                                    json.getString("tipo_sensor"),
                                    json.getDouble("valor"),
                                    json.getString("fecha_hora"),
                                    json.isNull("relay_status") ? null : json.getString("relay_status")
                            ));
                        }
                        callback.onSuccess(lecturas);
                    } else {
                        callback.onError("Error desconocido: " + code);
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception ex) {
                Log.e(TAG, "Error (obtenerLecturasSensores): " + ex.getMessage());
                callback.onError("Error de servidor: " + ex.getMessage());
            }
        });
    }

    public void setRelayStatus(int sensorId, String status, Callback<String> callback) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(BASE_URL + "api.php?action=set_relay_status");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String postData = "sensor_id=" + sensorId + "&status=" + URLEncoder.encode(status, "UTF-8");
                OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
                writer.write(postData);
                writer.flush();
                writer.close();

                if (conn.getResponseCode() == 200) {
                    String res = new BufferedReader(new InputStreamReader(conn.getInputStream()))
                            .lines().collect(Collectors.joining());
                    JSONObject jo = new JSONObject(res);
                    if (jo.has("success") && jo.getBoolean("success")) {
                        callback.onSuccess("Estado del relé actualizado correctamente");
                    } else {
                        callback.onError(jo.optString("error", "Error desconocido"));
                    }
                } else {
                    callback.onError("HTTP " + conn.getResponseCode());
                }
                conn.disconnect();
            } catch (Exception e) {
                callback.onError(e.getMessage());
            }
        });
    }
}