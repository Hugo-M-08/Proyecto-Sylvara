package com.hugo.sylvarapro;

public class Item_LecturaSensor {
    private int id_lectura;
    private int sensor_id;
    private String nombre_sensor;
    private String tipo_sensor;
    private double valor;
    private String fecha_hora;
    private String relay_status; // Puede ser null si no hay relé asociado

    public Item_LecturaSensor(int id_lectura, int sensor_id, String nombre_sensor, String tipo_sensor, double valor, String fecha_hora, String relay_status) {
        this.id_lectura = id_lectura;
        this.sensor_id = sensor_id;
        this.nombre_sensor = nombre_sensor;
        this.tipo_sensor = tipo_sensor;
        this.valor = valor;
        this.fecha_hora = fecha_hora;
        this.relay_status = relay_status;
    }

    // Getters
    public int getId_lectura() {
        return id_lectura;
    }

    public int getSensor_id() {
        return sensor_id;
    }

    public String getNombre_sensor() {
        return nombre_sensor;
    }

    public String getTipo_sensor() {
        return tipo_sensor;
    }

    public double getValor() {
        return valor;
    }

    public String getFecha_hora() {
        return fecha_hora;
    }

    public String getRelay_status() {
        return relay_status;
    }
}