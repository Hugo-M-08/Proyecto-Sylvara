package com.hugo.sylvarapro;
import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.Toast;
import org.json.JSONObject;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.Locale;

//no hay ip




public class Perfil extends AppCompatActivity {
    private Button BTN_CambioContrasena, BTN_CerrarSesion, BTN_Soporte;
    private TextView TV_VerNombre, TV_VerCorreo, TV_AvisoLegal, BTN_BorrarCuenta;
    private EditText ET_CambContrasena, ET_ConfContrasena;
    private ImageView IV_FotoPerfil;
    private ConectaWebServicePerfil webService;
    private View TV_Barra;
    private LinearLayout BTN_CambiarIdioma;
    private TextView TV_IdiomaActual;

    private static final int REQUEST_PERMISSIONS = 100;
    private static final int PICK_IMAGE = 1;
    private static final int TAKE_PHOTO = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_perfil);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Vinculación de UI
        BTN_CambiarIdioma = findViewById(R.id.BTN_CambiarIdioma);
        TV_IdiomaActual = findViewById(R.id.TV_IdiomaActual);
        BTN_CambiarIdioma.setOnClickListener(v -> mostrarDialogoIdiomas());
        BTN_Soporte = findViewById(R.id.BTN_Soporte);
        BTN_CambioContrasena = findViewById(R.id.BTN_CambioContrasena);
        BTN_CerrarSesion = findViewById(R.id.BTN_CerrarSesion);
        BTN_BorrarCuenta = findViewById(R.id.BTN_BorrarCuenta);
        TV_VerNombre = findViewById(R.id.TV_VerNumTarjetaBancaria);
        TV_VerCorreo = findViewById(R.id.TV_VerCorreo);
        TV_Barra = findViewById(R.id.TV_Barra);
        TV_AvisoLegal = findViewById(R.id.TV_AvisoLegal);
        IV_FotoPerfil = findViewById(R.id.IV_FotoPerfil);
        ET_CambContrasena = findViewById(R.id.ET_CambContrasena);
        ET_ConfContrasena = findViewById(R.id.ET_ConfContrasena);

        webService = new ConectaWebServicePerfil();

        // Estética Admin
        boolean isAdmin = getIntent().getBooleanExtra("isAdmin", false);
        if (isAdmin) {
            IV_FotoPerfil.setImageResource(R.drawable.admin);
            TV_Barra.setBackgroundColor(Color.parseColor("#B11010"));
        }

        cargarDatosUsuario();

        // Listeners
        IV_FotoPerfil.setOnClickListener(v -> {
            if (tienePermisos()) mostrarOpcionesImagen();
            else solicitarPermisos();
        });

        BTN_Soporte.setOnClickListener(v -> mostrarChatbot());
        TV_AvisoLegal.setOnClickListener(v -> mostrarDialogoLegal());
        BTN_CambioContrasena.setOnClickListener(v -> cambiarContrasena());
        BTN_CerrarSesion.setOnClickListener(v -> cerrarSesion());
        BTN_BorrarCuenta.setOnClickListener(v -> confirmarBorrado());
    }

    private void mostrarChatbot() {
        WebView webView = new WebView(this);
        WebSettings settings = webView.getSettings();

        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);              // A veces ayuda
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);

        // Muy importante para la mayoría de chatbots modernos
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        // Ayuda a depurar (puedes quitarlo después)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                // Para depuración
                Toast.makeText(Perfil.this, "Error WebView: " + description, Toast.LENGTH_LONG).show();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Opcional: ocultar loading si tuvieras uno
            }
        });

        // Opción 1 - URL pública (más estable en muchos casos)
        webView.loadUrl("https://bots.easy-peasy.ai/bot/f551b3ed-dcc6-4c9d-bf6e-81b6451be3ca?mode=embedded");

        // Opción 2 - Si prefieres el iframe (a veces mejor dimensionado)
        // String html = "<html><body style='margin:0;padding:0;'><iframe src='https://bots.easy-peasy.ai/bot/f551b3ed-dcc6-4c9d-bf6e-81b6451be3ca?mode=embedded' width='100%' height='100%' frameborder='0'></iframe></body></html>";
        // webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);

        new AlertDialog.Builder(this)
                .setTitle("Soporte Sylvara Pro")
                .setView(webView)
                .setPositiveButton("Finalizar", (dialog, which) -> {
                    webView.destroy(); // Importante liberar recursos
                })
                .setCancelable(false) // Opcional: evita que cierren sin querer
                .show();
    }



    // --- MANTENIENDO TUS FUNCIONALIDADES ORIGINALES ---

    private void cargarDatosUsuario() {
        SharedPreferences preferences = getSharedPreferences("user_session", MODE_PRIVATE);
        String id_usuario = preferences.getString("id_usuario", "");
        if (id_usuario.isEmpty()) { cerrarSesion(); return; }

        webService.verPerfil(id_usuario, new ConectaWebServicePerfil.Callback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                runOnUiThread(() -> {
                    try {
                        TV_VerNombre.setText(result.getString("nombre"));
                        TV_VerCorreo.setText(result.getString("gmail"));
                        String foto = result.optString("foto_perfil", "");
                        if (!foto.isEmpty() && !foto.equals("null")) {
                            byte[] decodedString = Base64.decode(foto, Base64.DEFAULT);
                            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                            IV_FotoPerfil.setImageBitmap(decodedByte);
                        }
                    } catch (Exception e) { Log.e("Perfil", "Error: " + e.getMessage()); }
                });
            }
            @Override public void onError(String error) {
                runOnUiThread(() -> Toast.makeText(Perfil.this, error, Toast.LENGTH_LONG).show());
            }
        });
    }

    private void cambiarContrasena() {
        String nueva = ET_CambContrasena.getText().toString().trim();
        String conf = ET_ConfContrasena.getText().toString().trim();
        if (nueva.isEmpty() || !nueva.equals(conf)) {
            Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show();
            return;
        }
        SharedPreferences prefs = getSharedPreferences("user_session", MODE_PRIVATE);
        webService.cambiarContrasena(prefs.getString("id_usuario", ""), nueva, new ConectaWebServicePerfil.Callback<String>() {
            @Override
            public void onSuccess(String result) {
                runOnUiThread(() -> {
                    Toast.makeText(Perfil.this, "Seguridad actualizada", Toast.LENGTH_LONG).show();
                    ET_CambContrasena.setText(""); ET_ConfContrasena.setText("");
                });
            }
            @Override public void onError(String e) { runOnUiThread(() -> Toast.makeText(Perfil.this, e, Toast.LENGTH_SHORT).show()); }
        });
    }

    private void cerrarSesion() {
        SharedPreferences preferences = getSharedPreferences("user_session", MODE_PRIVATE);
        preferences.edit().clear().apply();
        Intent intent = new Intent(Perfil.this, Login.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void confirmarBorrado() {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar Cuenta")
                .setMessage("¿Confirmas la eliminación permanente?")
                .setPositiveButton("Borrar", (dialog, which) -> {
                    SharedPreferences pref = getSharedPreferences("user_session", MODE_PRIVATE);
                    webService.borrarCuenta(pref.getString("id_usuario", ""), new ConectaWebServicePerfil.Callback<String>() {
                        @Override public void onSuccess(String r) { runOnUiThread(() -> cerrarSesion()); }
                        @Override public void onError(String e) { runOnUiThread(() -> Toast.makeText(Perfil.this, "Error al eliminar", Toast.LENGTH_SHORT).show()); }
                    });
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private boolean tienePermisos() { return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED; }
    private void solicitarPermisos() { ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_PERMISSIONS); }
    private void mostrarOpcionesImagen() {
        String[] opciones = {"Cámara", "Galería", "Cancelar"};
        new AlertDialog.Builder(this).setTitle("Actualizar foto").setItems(opciones, (dialog, i) -> {
            if (i == 0) startActivityForResult(new Intent(MediaStore.ACTION_IMAGE_CAPTURE), TAKE_PHOTO);
            else if (i == 1) startActivityForResult(new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI), PICK_IMAGE);
        }).show();
    }
    private void mostrarDialogoIdiomas() {
        String[] idiomas = {
                getString(R.string.lang_default),
                getString(R.string.lang_en),
                getString(R.string.lang_es),
                getString(R.string.lang_fr),
                getString(R.string.lang_ar),
                getString(R.string.lang_ja),
                getString(R.string.lang_zh)



        };

        new AlertDialog.Builder(this)
                .setTitle(R.string.title_language)
                .setItems(idiomas, (dialog, which) -> {
                    switch (which) {
                        case 0: setLocale(""); break;    // Default
                        case 1: setLocale("en"); break;  // Inglés
                        case 2: setLocale("es"); break;  // Español
                        case 3: setLocale("fr"); break;  // Francés
                        case 4: setLocale("ar"); break;  //árabe
                        case 5: setLocale("ja"); break;  //japones
                        case 6: setLocale("zh"); break;
                    }
                }).show();
    }

    private void setLocale(String langCode) {
        Locale locale;
        if (langCode.isEmpty()) {
            locale = Locale.getDefault(); // Usa el del sistema
        } else {
            locale = new Locale(langCode);
        }

        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);

        getResources().updateConfiguration(config, getResources().getDisplayMetrics());

        SharedPreferences.Editor editor = getSharedPreferences("Settings", MODE_PRIVATE).edit();
        editor.putString("My_Lang", langCode);
        editor.apply();

        Intent intent = getIntent();
        finish();
        startActivity(intent);
    }

    private void mostrarDialogoLegal() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.action_legal_notice)
                .setMessage(R.string.privacy_agreement_text) // USANDO LA VARIABLE DE STRINGS
                .setPositiveButton(android.R.string.ok, null)
                .show();
    }
}