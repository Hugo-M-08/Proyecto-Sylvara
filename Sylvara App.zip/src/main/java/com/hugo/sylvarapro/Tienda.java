package com.hugo.sylvarapro;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import java.util.ArrayList;
import java.util.List;


public class Tienda extends Fragment implements AdaptadorProductos.OnCarritoClickListener {
    private RecyclerView rvProducts;
    private AdaptadorProductos adaptador;
    private List<Item_Productos> listaOriginal = new ArrayList<>();
    private List<Item_Productos> listaFiltrada = new ArrayList<>();
    private EditText ET_Buscar;
    private ImageButton BTN_Carrito, BTN_Envios, BTN_Guardados;
    private ConectaWebServiceTienda webService;
    private CarritoManager carritoManager;

    public Tienda() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tienda, container, false);

        // Inicialización de componentes
        carritoManager = new CarritoManager(getContext());
        rvProducts = view.findViewById(R.id.rvProducts);
        ET_Buscar = view.findViewById(R.id.ET_BuscarProducto);
        BTN_Carrito = view.findViewById(R.id.BTN_Carrito);
        BTN_Envios = view.findViewById(R.id.BTN_Envios);
        BTN_Guardados = view.findViewById(R.id.BTN_Guardados);

        // Configuración de RecyclerView con diseño Staggered (2 columnas)
        rvProducts.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));
        adaptador = new AdaptadorProductos(listaFiltrada, getContext());
        rvProducts.setAdapter(adaptador);

        // Listeners del Adaptador
        adaptador.setOnCarritoClickListener(this);
        adaptador.setOnItemClickListener(position -> {
            Intent intent = new Intent(getContext(), DetalleProducto.class);
            intent.putExtra("producto", listaFiltrada.get(position));
            startActivity(intent);
        });

        webService = new ConectaWebServiceTienda();

        // Buscador en tiempo real
        ET_Buscar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filtrarBusqueda(s.toString());
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Configuración de botones de navegación superior
        BTN_Carrito.setOnClickListener(v -> startActivity(new Intent(getContext(), CarritoCompras.class)));
        BTN_Envios.setOnClickListener(v -> startActivity(new Intent(getContext(), Envios.class)));
        BTN_Guardados.setOnClickListener(v -> startActivity(new Intent(getContext(), GuardadosActivity.class)));

        return view;
    }

    // --- MEJORA CRÍTICA: RECARGA DE DATOS ---
    @Override
    public void onResume() {
        super.onResume();
        // Al regresar de calificar un producto o ver el carrito, se refrescan las estrellas y el stock
        cargarDatos();
    }

    @Override
    public void onCarritoClick(int position, int cantidad) {
        Item_Productos producto = listaFiltrada.get(position);
        carritoManager.agregarProducto(producto, cantidad);
        Toast.makeText(getContext(), "Agregado al carrito", Toast.LENGTH_SHORT).show();
    }

    private void cargarDatos() {
        webService.obtenerProductos(new ConectaWebServiceTienda.Callback<List<Item_Productos>>() {
            @Override
            public void onSuccess(List<Item_Productos> productos) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        listaOriginal.clear();
                        // Filtrado para excluir configuraciones de bolitas del catálogo general
                        for (Item_Productos p : productos) {
                            if (!p.getNombre().toLowerCase().contains("bolita")) {
                                listaOriginal.add(p);
                            }
                        }
                        listaFiltrada.clear();
                        listaFiltrada.addAll(listaOriginal);
                        adaptador.notifyDataSetChanged();
                    });
                }
            }
            @Override
            public void onError(String error) {
                // Manejo de error silencioso o Log
            }
        });
    }

    private void filtrarBusqueda(String texto) {
        listaFiltrada.clear();
        for (Item_Productos item : listaOriginal) {
            if (item.getNombre().toLowerCase().contains(texto.toLowerCase())) {
                listaFiltrada.add(item);
            }
        }
        adaptador.notifyDataSetChanged();
    }
}