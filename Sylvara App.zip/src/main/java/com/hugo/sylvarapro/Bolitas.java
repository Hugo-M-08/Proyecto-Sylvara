package com.hugo.sylvarapro;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.io.OutputStreamWriter;

public class Bolitas extends Fragment {
    private RecyclerView rvDisponibles, rvCompradas;
    private AdaptadorBolitasUsuario adapterDisponibles;
    private AdaptadorBolitasUsuario adapterCompradas;
    private String idUsuario;

    // Solución al error de símbolo: Declaración del WebService
    private ConectaWebServiceInvernadero webServiceInvernadero;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_bolitas, container, false);

        // Obtener sesión del usuario
        SharedPreferences prefs = requireActivity().getSharedPreferences("user_session", Context.MODE_PRIVATE);
        idUsuario = prefs.getString("id_usuario", "0");
        webServiceInvernadero = new ConectaWebServiceInvernadero();

        // Inicialización de vistas
        rvDisponibles = view.findViewById(R.id.RV_VerBolitasDisponibles);
        rvCompradas = view.findViewById(R.id.RV_VerBolitasCompradas);

        rvDisponibles.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));
        rvCompradas.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));

        adapterDisponibles = new AdaptadorBolitasUsuario(new ArrayList<>(), getContext(), R.layout.item_bolita_usuario);
        adapterCompradas = new AdaptadorBolitasUsuario(new ArrayList<>(), getContext(), R.layout.item_bolita_comprada);

        adapterDisponibles.setOnItemClickListener(producto -> {
            Intent intent = new Intent(getContext(), DetalleProducto.class);
            intent.putExtra("producto", producto);
            startActivity(intent);
        });

        adapterCompradas.setOnItemClickListener(this::mostrarDialogoVincularInvernadero);

        rvDisponibles.setAdapter(adapterDisponibles);
        rvCompradas.setAdapter(adapterCompradas);

        // Botón de Ayuda
        ImageButton btnAyuda = view.findViewById(R.id.BTN_AyudaBolitas);
        btnAyuda.setOnClickListener(v -> mostrarDialogoAyuda());

        cargarBolitas();
        return view;
    }

    private void mostrarDialogoAyuda() {
        new AlertDialog.Builder(requireContext())
                .setTitle(R.string.help_dialog_title)
                .setMessage(R.string.help_dialog_message)
                .setPositiveButton(R.string.btn_close, (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void cargarBolitas() {
        cargarDesdeServidor("obtener_bolitas_disponibles.php?id_usuario=" + idUsuario, adapterDisponibles);
        cargarDesdeServidor("obtener_bolitas_compradas.php?id_usuario=" + idUsuario, adapterCompradas);
    }

    private void cargarDesdeServidor(String endpoint, AdaptadorBolitasUsuario adapter) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Bolitas/" + endpoint);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setConnectTimeout(7000);
                connection.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) response.append(line);
                reader.close();

                JSONObject json = new JSONObject(response.toString());
                if (json.optString("code", "001").equals("002")) {
                    JSONArray data = json.optJSONArray("data");
                    List<Item_Productos> lista = new ArrayList<>();
                    if (data != null) {
                        for (int i = 0; i < data.length(); i++) {
                            JSONObject obj = data.getJSONObject(i);
                            Item_Productos item = new Item_Productos();
                            item.setId_producto(obj.optString("id_producto"));
                            item.setNombre(obj.optString("nombre"));
                            item.setImagen(obj.optString("imagen"));
                            item.setPrecio(obj.optString("precio", "0"));
                            lista.add(item);
                        }
                    }
                    requireActivity().runOnUiThread(() -> adapter.updateBolitas(lista));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private void mostrarDialogoVincularInvernadero(Item_Productos producto) {
        webServiceInvernadero.obtenerInvernaderos(idUsuario, new ConectaWebServiceInvernadero.Callback<List<Item_Invernadero>>() {
            @Override
            public void onSuccess(List<Item_Invernadero> listaInvernaderos) {
                if (listaInvernaderos.isEmpty()) {
                    requireActivity().runOnUiThread(() -> Toast.makeText(getContext(), "No greenhouses found", Toast.LENGTH_SHORT).show());
                    return;
                }
                requireActivity().runOnUiThread(() -> {
                    AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                    // Asegúrate de tener creado R.layout.dialog_select_greenhouse
                    View dialogView = getLayoutInflater().inflate(R.layout.dialog_select_greenhouse, null);
                    Spinner spinner = dialogView.findViewById(R.id.spinner_greenhouses);

                    ArrayAdapter<Item_Invernadero> spinnerAdapter = new ArrayAdapter<>(getContext(),
                            android.R.layout.simple_spinner_item, listaInvernaderos);
                    spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinner.setAdapter(spinnerAdapter);

                    builder.setTitle(R.string.dialog_activate_ball_title)
                            .setMessage(R.string.dialog_activate_ball_message)
                            .setView(dialogView)
                            .setPositiveButton(R.string.btn_activate, (d, w) -> {
                                Item_Invernadero sel = (Item_Invernadero) spinner.getSelectedItem();
                                activarBolitaEnServidor(sel.getIdInvernadero(), producto.getId_producto());
                            })
                            .setNegativeButton(R.string.btn_close, null)
                            .show();
                });
            }
            @Override
            public void onError(String error) {
                requireActivity().runOnUiThread(() -> Toast.makeText(getContext(), error, Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void activarBolitaEnServidor(int idInvernadero, String idProducto) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Bolitas/gestionar_automatizacion.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);

                // Enviamos id_producto, el PHP buscará el id_bolitas correspondiente
                String params = "accion=activar&id_invernadero=" + idInvernadero + "&id_producto=" + idProducto;

                OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
                wr.write(params);
                wr.flush();

                BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                JSONObject res = new JSONObject(rd.readLine());

                requireActivity().runOnUiThread(() -> {
                    try {
                        if (res.getString("code").equals("002")) {
                            // Usar recurso de string para el idioma
                            Toast.makeText(getContext(), R.string.msg_automation_activated, Toast.LENGTH_LONG).show();

                            // IMPORTANTE: Recargar datos para que el cambio sea visible
                            cargarBolitas();
                        } else {
                            Toast.makeText(getContext(), "Error DB: " + res.optString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) { e.printStackTrace(); }
                });
            } catch (Exception e) { e.printStackTrace(); }
        });
    }
}