package com.hugo.sylvarapro;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.function.Consumer;

//no hay ip

public class AdaptadorTarjeta extends RecyclerView.Adapter<AdaptadorTarjeta.TarjetaViewHolder> {
    private List<Item_Tarjeta> tarjetas;
    private Context context;
    private Consumer<Integer> onPredeterminadoClick;
    private Consumer<Integer> onEliminarClick;

    public AdaptadorTarjeta(Context context, List<Item_Tarjeta> tarjetas,
                            Consumer<Integer> onPredeterminadoClick, Consumer<Integer> onEliminarClick) {
        this.context = context;
        this.tarjetas = tarjetas;
        this.onPredeterminadoClick = onPredeterminadoClick;
        this.onEliminarClick = onEliminarClick;
    }

    @NonNull
    @Override
    public TarjetaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_pago, parent, false);
        return new TarjetaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TarjetaViewHolder holder, int position) {
        Item_Tarjeta tarjeta = tarjetas.get(position);
        holder.TV_Apodo.setText(tarjeta.getAlias());
        holder.TV_VerPropietario.setText(tarjeta.getTitular());
        // Mostrar solo los últimos 4 dígitos del número de tarjeta
        String numeroTarjeta = tarjeta.getNumero_tarjeta();
        String numeroOculto = "**** **** **** " + numeroTarjeta.substring(numeroTarjeta.length() - 4);
        holder.TV_VerNumTarjetaBancaria.setText(numeroOculto);
        holder.TV_Predeterminado.setVisibility(tarjeta.isEs_predeterminada() ? View.VISIBLE : View.GONE);

        holder.BTN_ModifTarjeta.setOnClickListener(v -> {
            Intent intent = new Intent(context, AgregarPago.class);
            intent.putExtra("isModifying", true);
            intent.putExtra("id_tarjeta", tarjeta.getId_tarjeta());
            intent.putExtra("titular", tarjeta.getTitular());
            intent.putExtra("numero_tarjeta", tarjeta.getNumero_tarjeta());
            intent.putExtra("cvv", tarjeta.getCvv());
            intent.putExtra("fecha_vencimiento", tarjeta.getFecha_vencimiento());
            intent.putExtra("alias", tarjeta.getAlias());
            ((Pago) context).startActivityForResult(intent, 1);
        });

        holder.BTN_EliminarTarjeta.setOnClickListener(v -> onEliminarClick.accept(tarjeta.getId_tarjeta()));

        holder.BTN_PredeterminadoTarjeta.setOnClickListener(v -> onPredeterminadoClick.accept(tarjeta.getId_tarjeta()));
    }

    @Override
    public int getItemCount() {
        return tarjetas.size();
    }

    public void updateTarjetas(List<Item_Tarjeta> newTarjetas) {
        this.tarjetas = newTarjetas;
        notifyDataSetChanged();
    }

    static class TarjetaViewHolder extends RecyclerView.ViewHolder {
        TextView TV_Apodo, TV_VerPropietario, TV_VerNumTarjetaBancaria, TV_Predeterminado;
        Button BTN_ModifTarjeta, BTN_EliminarTarjeta, BTN_PredeterminadoTarjeta;

        public TarjetaViewHolder(@NonNull View itemView) {
            super(itemView);
            TV_Apodo = itemView.findViewById(R.id.TV_Apodo);
            TV_VerPropietario = itemView.findViewById(R.id.TV_VerPropietario);
            TV_VerNumTarjetaBancaria = itemView.findViewById(R.id.TV_VerNumTarjetaBancaria);
            TV_Predeterminado = itemView.findViewById(R.id.TV_Predeterminado);
            BTN_ModifTarjeta = itemView.findViewById(R.id.BTN_ModifTarjeta);
            BTN_EliminarTarjeta = itemView.findViewById(R.id.BTN_EliminarTarjeta);
            BTN_PredeterminadoTarjeta = itemView.findViewById(R.id.BTN_PredeterminadoTarjeta);
        }
    }
}