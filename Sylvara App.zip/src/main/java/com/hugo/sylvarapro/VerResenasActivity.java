package com.hugo.sylvarapro;

import android.animation.ObjectAnimator;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class VerResenasActivity extends AppCompatActivity {

    private RecyclerView rvResenas;
    private List<ItemResenaData> listaResenas;
    private AdaptadorResenasDetalle adaptador;
    private String idProducto;

    // Componentes de estadísticas (Barras estilo ML)
    private ProgressBar b5, b4, b3, b2, b1;
    private TextView tvPromedioGrande, tvTotalResenas;
    private RatingBar rbPromedioCebecera;
    private ProgressBar loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_resenas);

        // 1. Recuperar ID del producto enviado desde DetalleProducto
        idProducto = getIntent().getStringExtra("id_producto");

        // 2. Inicializar Vistas de Estadísticas
        tvPromedioGrande = findViewById(R.id.TV_PromedioGrande);
        tvTotalResenas = findViewById(R.id.TV_TotalOpiniones);
        rbPromedioCebecera = findViewById(R.id.RB_Promedio);
        loading = findViewById(R.id.loading_resenas);

        b5 = findViewById(R.id.bar5);
        b4 = findViewById(R.id.bar4);
        b3 = findViewById(R.id.bar3);
        b2 = findViewById(R.id.bar2);
        b1 = findViewById(R.id.bar1);

        // 3. Configurar RecyclerView
        rvResenas = findViewById(R.id.RV_Resenas);
        rvResenas.setLayoutManager(new LinearLayoutManager(this));
        listaResenas = new ArrayList<>();
        adaptador = new AdaptadorResenasDetalle(listaResenas);
        rvResenas.setAdapter(adaptador);

        // 4. Cargar datos del servidor
        if (idProducto != null) {
            obtenerResenasServidor();
        } else {
            Toast.makeText(this, "Error: Producto no identificado", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void obtenerResenasServidor() {
        if (loading != null) loading.setVisibility(View.VISIBLE);

        Executor executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(() -> {
            try {
                // Ruta según tu estructura de carpetas: Compra/obtener_resenas.php
                URL url = new URL(Configuracion.getUrlBase() + "Compra/obtener_resenas.php?id_producto=" + idProducto);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line);

                JSONArray array = new JSONArray(sb.toString());
                listaResenas.clear();

                for (int i = 0; i < array.length(); i++) {
                    JSONObject obj = array.getJSONObject(i);
                    listaResenas.add(new ItemResenaData(
                            obj.getString("nombre"),
                            (float) obj.getDouble("estrellas"),
                            obj.getString("comentario"),
                            obj.getString("fecha")
                    ));
                }

                handler.post(() -> {
                    if (loading != null) loading.setVisibility(View.GONE);
                    actualizarEstadisticas();
                    adaptador.notifyDataSetChanged();
                });

            } catch (Exception e) {
                handler.post(() -> {
                    if (loading != null) loading.setVisibility(View.GONE);
                    Log.e("VerResenas", "Error: " + e.getMessage());
                    Toast.makeText(this, "Aún no hay reseñas para este producto", Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private void actualizarEstadisticas() {
        if (listaResenas.isEmpty()) {
            // opcional: poner todo en 0
            setProgressWithAnimation(b5, 0);
            setProgressWithAnimation(b4, 0);
            // etc...
            return;
        }

        int total = listaResenas.size();
        int[] conteo = new int[6];

        float sumaTotal = 0;
        for (ItemResenaData r : listaResenas) {
            sumaTotal += r.estrellas;
            int estrella = Math.round(r.estrellas);
            if (estrella >= 1 && estrella <= 5) {
                conteo[estrella]++;
            }
        }

        float promedio = sumaTotal / total;

        // UI principal
        tvPromedioGrande.setText(String.format(Locale.getDefault(), "%.1f", promedio));
        rbPromedioCebecera.setRating(promedio);
        tvTotalResenas.setText(total + " calificaciones");

        // Barras con animación suave
        setProgressWithAnimation(b5, (conteo[5] * 100) / total);
        setProgressWithAnimation(b4, (conteo[4] * 100) / total);
        setProgressWithAnimation(b3, (conteo[3] * 100) / total);
        setProgressWithAnimation(b2, (conteo[2] * 100) / total);
        setProgressWithAnimation(b1, (conteo[1] * 100) / total);
    }

    // Método con animación (muy usado en apps profesionales)
    private void setProgressWithAnimation(ProgressBar progressBar, int progress) {
        ObjectAnimator animation = ObjectAnimator.ofInt(progressBar, "progress", 0, progress);
        animation.setDuration(600);
        animation.setInterpolator(new DecelerateInterpolator());
        animation.start();
    }

    // --- MODELO DE DATOS INTERNO ---
    private static class ItemResenaData {
        String usuario, comentario, fecha;
        float estrellas;

        public ItemResenaData(String u, float e, String c, String f) {
            this.usuario = u;
            this.estrellas = e;
            this.comentario = c;
            this.fecha = f;
        }
    }

    // --- ADAPTADOR INTERNO ---
    private class AdaptadorResenasDetalle extends RecyclerView.Adapter<AdaptadorResenasDetalle.ViewHolder> {
        private List<ItemResenaData> mDatos;

        public AdaptadorResenasDetalle(List<ItemResenaData> datos) {
            this.mDatos = datos;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_resena_detalle, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            ItemResenaData item = mDatos.get(position);
            holder.user.setText(item.usuario);
            holder.stars.setRating(item.estrellas);
            holder.comment.setText(item.comentario);
            holder.date.setText(item.fecha);
        }

        @Override
        public int getItemCount() {
            return mDatos.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView user, comment, date;
            RatingBar stars;

            public ViewHolder(View v) {
                super(v);
                user = v.findViewById(R.id.TV_ResenaUsuario);
                comment = v.findViewById(R.id.TV_ResenaComentario);
                date = v.findViewById(R.id.TV_ResenaFecha);
                stars = v.findViewById(R.id.RB_ResenaEstrellas);
            }
        }
    }
}