package com.hugo.sylvarapro;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import java.util.ArrayList;
import java.util.List;

//no hay ip

public class TiendaAdmin extends Fragment implements AdaptadorProductosAdmin.OnBorrarClickListener {
    private Button BTN_SubirProducto;
    private RecyclerView RV_Admin_Tienda;
    private AdaptadorProductosAdmin adaptador;
    private List<Item_Productos> listaProductos;
    private ConectaWebServiceTienda webService;

    public TiendaAdmin() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tienda_admin, container, false);

        // Inicializar vistas
        BTN_SubirProducto = view.findViewById(R.id.BTN_SubirProducto);
        RV_Admin_Tienda = view.findViewById(R.id.RV_Admin_Tienda);

        // Configurar RecyclerView
        listaProductos = new ArrayList<>();
        adaptador = new AdaptadorProductosAdmin(listaProductos, getContext());
        RV_Admin_Tienda.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));

        RV_Admin_Tienda.setAdapter(adaptador);
        adaptador.setOnBorrarClickListener(this);

        // Inicializar servicio web
        webService = new ConectaWebServiceTienda();

        // Cargar productos
        cargarProductos();

        // Configurar botón para agregar producto
        BTN_SubirProducto.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), AgregarProductos.class);
            startActivity(intent);
        });

        return view;
    }

    private void cargarProductos() {
        webService.obtenerProductos(new ConectaWebServiceTienda.Callback<List<Item_Productos>>() {
            @Override
            public void onSuccess(List<Item_Productos> productos) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        listaProductos.clear();
                        listaProductos.addAll(productos);
                        adaptador.notifyDataSetChanged();
                    });
                }
            }

            @Override
            public void onError(String error) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        Toast.makeText(getContext(), error, Toast.LENGTH_LONG).show();
                    });
                }
            }
        });
    }

    @Override
    public void onBorrarClick(int position) {
        Item_Productos item = listaProductos.get(position);
        webService.eliminarProducto(item.getId_producto(), new ConectaWebServiceTienda.Callback<String>() {
            @Override
            public void onSuccess(String result) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        if (result.equals("Producto eliminado correctamente")) {
                            listaProductos.remove(position);
                            adaptador.notifyItemRemoved(position);
                            Toast.makeText(getContext(), result, Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getContext(), result, Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }

            @Override
            public void onError(String error) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        Toast.makeText(getContext(), error, Toast.LENGTH_LONG).show();
                    });
                }
            }
        });
    }
}