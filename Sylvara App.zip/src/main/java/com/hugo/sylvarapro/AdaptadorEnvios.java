package com.hugo.sylvarapro;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;
public class AdaptadorEnvios extends RecyclerView.Adapter<AdaptadorEnvios.EnvioViewHolder> {
    private List<Item_Envio> envios;
    private Context context;

    public AdaptadorEnvios(Context context, List<Item_Envio> envios) {
        this.context = context;
        this.envios = envios;
    }

    @NonNull
    @Override
    public EnvioViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_envio, parent, false);
        return new EnvioViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EnvioViewHolder holder, int position) {
        Item_Envio envio = envios.get(position);

        // --- LÓGICA DE IMAGEN BASE64 ---
        String imagenBase64 = envio.getImagen();

        if (imagenBase64 != null && !imagenBase64.isEmpty()) {
            try {
                // Eliminar prefijos de metadatos si el servidor los incluye
                if (imagenBase64.contains(",")) {
                    imagenBase64 = imagenBase64.split(",")[1];
                }

                // Decodificar la cadena Base64 a Bitmap
                byte[] decodedString = Base64.decode(imagenBase64, Base64.DEFAULT);
                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

                // Asignar al ImageView
                holder.imageView.setImageBitmap(decodedByte);
            } catch (Exception e) {
                // Imagen de error en caso de fallo en la decodificación
                holder.imageView.setImageResource(R.drawable.error);
                Log.e("AdaptadorEnvios", "Error decodificando imagen Base64: " + e.getMessage());
            }
        } else {
            // Imagen por defecto si no hay datos de imagen
            holder.imageView.setImageResource(R.drawable.carga);
        }

        holder.tvNumCompra.setText("COMPRA N°" + envio.getId_compras());
        holder.tvStatus.setText(envio.getStatus());
        holder.tvDiaEntrega.setText("Entrega: " + envio.getFecha_entrega());

        holder.itemView.setOnClickListener(v -> {
            Intent i = new Intent(context, DetalleEnvioActivity.class);
            i.putExtra("id_compras", envio.getId_compras());
            i.putExtra("status", envio.getStatus());
            i.putExtra("fecha", envio.getFecha_entrega());
            i.putExtra("imagen", envio.getImagen()); // Se pasa el Base64 completo
            i.putExtra("total", envio.getTotal());
            i.putExtra("envio_costo", envio.getEnvio());
            i.putExtra("id_producto", envio.getId_producto());
            context.startActivity(i);
        });
    }

    @Override
    public int getItemCount() {
        return envios.size();
    }

    public void updateEnvios(List<Item_Envio> newEnvios) {
        this.envios = newEnvios;
        notifyDataSetChanged();
    }

    static class EnvioViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView tvNumCompra, tvStatus, tvDiaEntrega;

        public EnvioViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.IV_ImagenProducto);
            tvNumCompra = itemView.findViewById(R.id.TV_NumCompra);
            tvStatus = itemView.findViewById(R.id.TV_Status);
            tvDiaEntrega = itemView.findViewById(R.id.TV_DiaEntrega);
        }
    }
}