package com.hugo.sylvarapro;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MonitoreoSensores extends Fragment {
    private RecyclerView rvMonitoreo;
    private AdaptadorMonitoreoSensores adaptador;
    private ConectaWebServiceSensores webService;
    private Item_Invernadero invernadero;
    private Handler handler;
    private Runnable fetchDataRunnable;

    public MonitoreoSensores() {
        // Constructor vacío requerido
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            invernadero = getArguments().getParcelable("invernadero");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_monitoreo_sensores, container, false);

        rvMonitoreo = view.findViewById(R.id.RV_Monitoreo);
        webService = new ConectaWebServiceSensores();
        rvMonitoreo.setLayoutManager(new LinearLayoutManager(getContext()));
        adaptador = new AdaptadorMonitoreoSensores(getContext(), new ArrayList<>(), this::toggleRelay);
        rvMonitoreo.setAdapter(adaptador);

        handler = new Handler(Looper.getMainLooper());
        fetchDataRunnable = this::cargarLecturas;

        if (invernadero != null && invernadero.isActiva()) {
            cargarLecturas();
            iniciarActualizacionDatos();
        } else {
            Toast.makeText(getContext(), "Invernadero no válido o desactivado", Toast.LENGTH_LONG).show();
        }

        return view;
    }

    private void cargarLecturas() {
        if (invernadero == null) return;

        webService.obtenerLecturasSensores(invernadero.getIdInvernadero(), new ConectaWebServiceSensores.Callback<List<Item_LecturaSensor>>() {
            @Override
            public void onSuccess(List<Item_LecturaSensor> result) {
                requireActivity().runOnUiThread(() -> {
                    adaptador.updateLecturas(result);
                    if (result.isEmpty()) {
                        Toast.makeText(getContext(), "No hay lecturas disponibles", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onError(String error) {
                requireActivity().runOnUiThread(() -> Toast.makeText(getContext(), "Error: " + error, Toast.LENGTH_LONG).show());
            }
        });
    }

    private void toggleRelay(int sensorId, String status) {
        webService.setRelayStatus(sensorId, status, new ConectaWebServiceSensores.Callback<String>() {
            @Override
            public void onSuccess(String result) {
                requireActivity().runOnUiThread(() -> {
                    Toast.makeText(getContext(), result, Toast.LENGTH_SHORT).show();
                    cargarLecturas(); // Actualizar lecturas tras cambiar estado
                });
            }

            @Override
            public void onError(String error) {
                requireActivity().runOnUiThread(() -> Toast.makeText(getContext(), "Error: " + error, Toast.LENGTH_LONG).show());
            }
        });
    }

    private void iniciarActualizacionDatos() {
        handler.removeCallbacks(fetchDataRunnable);
        handler.postDelayed(fetchDataRunnable, 10000); // Actualizar cada 10 segundos
    }

    private void detenerActualizacionDatos() {
        handler.removeCallbacks(fetchDataRunnable);
    }

    @Override
    public void onPause() {
        super.onPause();
        detenerActualizacionDatos();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (invernadero != null && invernadero.isActiva()) {
            iniciarActualizacionDatos();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        detenerActualizacionDatos();
        handler.removeCallbacksAndMessages(null);
    }
}