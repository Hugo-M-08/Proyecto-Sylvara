package com.hugo.sylvarapro;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import java.util.ArrayList;
import java.util.List;

//no hay ip

public class HomeAdmin extends Fragment {
    private RecyclerView rvVerUsuarios;
    private AdaptadorUsuario adapter;
    private ConectaWebServiceUsuario webServiceUsuario;

    public HomeAdmin() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home_admin, container, false);

        // Inicializar vistas
        rvVerUsuarios = view.findViewById(R.id.RV_VerUsuarios);

        // Inicializar servicio y adaptador
        webServiceUsuario = new ConectaWebServiceUsuario();
        adapter = new AdaptadorUsuario(new ArrayList<>(), getContext());
        rvVerUsuarios.setLayoutManager(new LinearLayoutManager(getContext()));
        rvVerUsuarios.setAdapter(adapter);

        // Cargar usuarios
        cargarUsuarios();

        return view;
    }

    public void cargarUsuarios() {
        webServiceUsuario.obtenerUsuarios(new ConectaWebServiceUsuario.Callback<List<Item_Usuario>>() {
            @Override
            public void onSuccess(List<Item_Usuario> result) {
                getActivity().runOnUiThread(() -> {
                    adapter.updateUsuarios(result);
                    if (result.isEmpty()) {
                        Toast.makeText(getContext(), "No hay usuarios registrados", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onError(String error) {
                getActivity().runOnUiThread(() -> {
                    Toast.makeText(getContext(), "Error: " + error, Toast.LENGTH_LONG).show();
                });
            }
        });
    }
}