package com.hugo.sylvarapro;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

public class HistorialNotas extends AppCompatActivity {
    private RecyclerView rv;
    private AdaptadorHistorial adaptador;
    private List<Item_Historial> lista = new ArrayList<>();
    private int idInvernadero;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historial_notas);

        idInvernadero = getIntent().getIntExtra("id_invernadero", 0);
        String nombreInv = getIntent().getStringExtra("nombre_inv");

        TextView tvTitulo = findViewById(R.id.tvTituloHistorial);
        tvTitulo.setText("Historial: " + nombreInv);

        rv = findViewById(R.id.rvHistorial);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adaptador = new AdaptadorHistorial(lista);
        rv.setAdapter(adaptador);

        obtenerDatosServidor();
    }

    private void obtenerDatosServidor() {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Cosechas/obtener_historial_cosechas.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);

                String data = "id_invernadero=" + idInvernadero;
                OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
                wr.write(data);
                wr.flush();

                BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                JSONObject res = new JSONObject(rd.readLine());

                if (res.getString("code").equals("002")) {
                    JSONArray jsonArray = res.getJSONArray("data");
                    lista.clear();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        lista.add(new Item_Historial(
                                obj.getString("fecha_inicio"),
                                obj.getString("fecha_fin"),
                                obj.getString("estado"),
                                obj.getString("comentarios")
                        ));
                    }
                    runOnUiThread(() -> adaptador.notifyDataSetChanged());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}