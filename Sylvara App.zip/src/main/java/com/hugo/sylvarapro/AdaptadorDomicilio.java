package com.hugo.sylvarapro;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.function.Consumer;

public class AdaptadorDomicilio extends RecyclerView.Adapter<AdaptadorDomicilio.DomicilioViewHolder> {
    private List<Item_Domicilio> domicilios;
    private Context context;
    private Consumer<Integer> onPredeterminadoClick;
    private Consumer<Integer> onEliminarClick;

    public AdaptadorDomicilio(Context context, List<Item_Domicilio> domicilios,
                              Consumer<Integer> onPredeterminadoClick, Consumer<Integer> onEliminarClick) {
        this.context = context;
        this.domicilios = domicilios;
        this.onPredeterminadoClick = onPredeterminadoClick;
        this.onEliminarClick = onEliminarClick;
    }

    @NonNull
    @Override
    public DomicilioViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_domicilio, parent, false);
        return new DomicilioViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DomicilioViewHolder holder, int position) {
        Item_Domicilio domicilio = domicilios.get(position);
        holder.TV_VerCalle.setText(String.format("%s, %s", domicilio.getCalle(), domicilio.getMunicipio()));
        holder.TV_VerNombre.setText(String.format("%s %s", domicilio.getNombre(), domicilio.getApellido()));
        holder.TV_Predeterminado.setVisibility(domicilio.isEs_predeterminado() ? View.VISIBLE : View.GONE);

        holder.BTN_ModifDomicilio.setOnClickListener(v -> {
            Intent intent = new Intent(context, AgregarDomicilio.class);
            intent.putExtra("isModifying", true);
            intent.putExtra("id_domicilio", domicilio.getId_domicilio());
            intent.putExtra("calle", domicilio.getCalle());
            intent.putExtra("codigo_postal", domicilio.getCodigo_postal());
            intent.putExtra("estado", domicilio.getEstado());
            intent.putExtra("municipio", domicilio.getMunicipio());
            intent.putExtra("referencias", domicilio.getReferencias());
            intent.putExtra("nombre", domicilio.getNombre());
            intent.putExtra("apellido", domicilio.getApellido());
            intent.putExtra("numero", domicilio.getNumero());
            ((Domicilio) context).startActivityForResult(intent, 1);
        });

        holder.BTN_EliminarDomicilio.setOnClickListener(v -> onEliminarClick.accept(domicilio.getId_domicilio()));

        holder.BTN_Predeterminado.setOnClickListener(v -> onPredeterminadoClick.accept(domicilio.getId_domicilio()));
    }

    @Override
    public int getItemCount() {
        return domicilios.size();
    }

    public void updateDomicilios(List<Item_Domicilio> newDomicilios) {
        this.domicilios = newDomicilios;
        notifyDataSetChanged();
    }

    static class DomicilioViewHolder extends RecyclerView.ViewHolder {
        TextView TV_VerCalle, TV_VerNombre, TV_Predeterminado;
        Button BTN_ModifDomicilio, BTN_EliminarDomicilio, BTN_Predeterminado;

        public DomicilioViewHolder(@NonNull View itemView) {
            super(itemView);
            TV_VerCalle = itemView.findViewById(R.id.TV_VerPropietario);
            TV_VerNombre = itemView.findViewById(R.id.TV_VerNumTarjetaBancaria);
            TV_Predeterminado = itemView.findViewById(R.id.TV_Predeterminado);
            BTN_ModifDomicilio = itemView.findViewById(R.id.BTN_ModifTarjeta);
            BTN_EliminarDomicilio = itemView.findViewById(R.id.BTN_EliminarTarjeta);
            BTN_Predeterminado = itemView.findViewById(R.id.BTN_PredeterminadoTarjeta);
        }
    }
}