package com.hugo.sylvarapro;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;


public class DetalleProducto extends AppCompatActivity {
    private ImageView IV_Imagen;
    private TextView TV_Nombre, TV_Precio, TV_Descripcion;
    private Button BTN_Comprar, BTN_Agregar;
    private ImageButton BTN_Favorito;
    private RatingBar RB_Calificacion;
    private Spinner SP_CantidadDetalle;
    private Item_Productos producto;
    private CarritoManager carritoManager;
    private GuardadosManager guardadosManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_producto);

        // Recuperar el objeto producto enviado desde la Tienda
        producto = getIntent().getParcelableExtra("producto");
        carritoManager = new CarritoManager(this);
        guardadosManager = new GuardadosManager(this);

        IV_Imagen = findViewById(R.id.IV_DetalleImagen);
        TV_Nombre = findViewById(R.id.TV_DetalleNombre);
        TV_Precio = findViewById(R.id.TV_DetallePrecio);
        TV_Descripcion = findViewById(R.id.TV_DetalleDescripcion);
        BTN_Favorito = findViewById(R.id.BTN_FavoritoDetalle);
        RB_Calificacion = findViewById(R.id.RB_CalificacionDetalle);
        RB_Calificacion.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                Intent intent = new Intent(DetalleProducto.this, VerResenasActivity.class);
                intent.putExtra("id_producto", producto.getId_producto());
                intent.putExtra("nombre_producto", producto.getNombre());
                startActivity(intent);
            }
            return true;
        });
        SP_CantidadDetalle = findViewById(R.id.SP_CantidadDetalle);
        BTN_Comprar = findViewById(R.id.BTN_ComprarAhora);
        BTN_Agregar = findViewById(R.id.BTN_AgregarDetalle);

        if (producto != null) {
            TV_Nombre.setText(producto.getNombre());
            TV_Precio.setText("$" + producto.getPrecio());
            TV_Descripcion.setText(producto.getDescripcion());

            if (guardadosManager.estaGuardado(producto.getId_producto())) {
                BTN_Favorito.setImageResource(android.R.drawable.btn_star_big_on);
            }

            // --- LÓGICA DE STOCK ---
            int stockReal = 0;
            try {
                stockReal = Integer.parseInt(producto.getUnidades());
            } catch (Exception e) {
                stockReal = 0;
            }

            int limite = Math.min(stockReal, 10);
            List<Integer> opciones = new ArrayList<>();
            for (int i = 1; i <= limite; i++) opciones.add(i);

            ArrayAdapter<Integer> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opciones);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            SP_CantidadDetalle.setAdapter(adapter);
            SP_CantidadDetalle.setSelection(0);

            // --- ACTUALIZACIÓN A IMAGEN BASE64 ---
            String imagenBase64 = producto.getImagen();
            if (imagenBase64 != null && !imagenBase64.isEmpty()) {
                try {
                    // Limpiar prefijos de metadatos si existen
                    if (imagenBase64.contains(",")) {
                        imagenBase64 = imagenBase64.split(",")[1];
                    }

                    // Decodificar la cadena Base64
                    byte[] decodedString = Base64.decode(imagenBase64, Base64.DEFAULT);
                    Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

                    // Asignar el Bitmap a la vista
                    IV_Imagen.setImageBitmap(decodedByte);
                } catch (Exception e) {
                    IV_Imagen.setImageResource(R.drawable.error);
                }
            } else {
                IV_Imagen.setImageResource(R.drawable.carga);
            }

            // --- LÓGICA ESPECÍFICA PARA BOLITAS ---
            if (producto.getNombre().toLowerCase().contains("bolita")) {
                SP_CantidadDetalle.setEnabled(false);
                RB_Calificacion.setVisibility(View.GONE);
            } else {
                RB_Calificacion.setVisibility(View.VISIBLE);
                RB_Calificacion.setRating(producto.getCalificacion());
            }
        } else {
            finish();
        }

        // --- LISTENERS ---
        BTN_Agregar.setOnClickListener(v -> {
            int cantidad = obtenerCantidadSeleccionada();
            carritoManager.agregarProducto(producto, cantidad);
            Toast.makeText(this, "Añadido al carrito", Toast.LENGTH_SHORT).show();
        });

        BTN_Comprar.setOnClickListener(v -> {
            int cantidad = obtenerCantidadSeleccionada();
            carritoManager.agregarProducto(producto, cantidad);
            startActivity(new Intent(this, CarritoCompras.class));
        });

        BTN_Favorito.setOnClickListener(v -> {
            guardadosManager.alternarGuardado(producto);
            if (guardadosManager.estaGuardado(producto.getId_producto())) {
                BTN_Favorito.setImageResource(android.R.drawable.btn_star_big_on);
                Toast.makeText(this, "Añadido a favoritos", Toast.LENGTH_SHORT).show();
            } else {
                BTN_Favorito.setImageResource(android.R.drawable.btn_star_big_off);
                Toast.makeText(this, "Eliminado de favoritos", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private int obtenerCantidadSeleccionada() {
        try {
            return (int) SP_CantidadDetalle.getSelectedItem();
        } catch (Exception e) {
            return 1;
        }
    }
}