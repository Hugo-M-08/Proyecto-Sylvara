package com.hugo.sylvarapro;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

//no hay ip
public class Domicilio extends AppCompatActivity {

    private RecyclerView RV_Domicilios;
    private Button BTN_AgregarDomicilio, BTN_Continuar;
    private AdaptadorDomicilio adapter;
    private ConectaWebServiceDomicilio webService;
    private ArrayList<Item_Productos> carritoProductos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_domicilio);

        carritoProductos = getIntent().getParcelableArrayListExtra("carrito");
        if (carritoProductos == null) carritoProductos = new ArrayList<>();

        RV_Domicilios = findViewById(R.id.RV_Domicilios);
        BTN_AgregarDomicilio = findViewById(R.id.BTN_AgregarDomicilio);
        BTN_Continuar = findViewById(R.id.BTN_Continuar);
        webService = new ConectaWebServiceDomicilio();

        RV_Domicilios.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AdaptadorDomicilio(this, new ArrayList<>(), this::setDomicilioPredeterminado, this::eliminarDomicilio);
        RV_Domicilios.setAdapter(adapter);

        cargarDomicilios();

        BTN_AgregarDomicilio.setOnClickListener(v -> {
            Intent intent = new Intent(this, AgregarDomicilio.class);
            intent.putExtra("isModifying", false);
            startActivityForResult(intent, 1);
        });

        BTN_Continuar.setOnClickListener(v -> {
            SharedPreferences pref = getSharedPreferences("user_session", MODE_PRIVATE);
            int id_dom = pref.getInt("id_domicilio_predeterminado", -1);
            if (id_dom == -1) {
                Toast.makeText(this, "Selecciona un domicilio", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(this, Pago.class);
            intent.putParcelableArrayListExtra("carrito", carritoProductos);
            startActivity(intent);
        });
    }

    private void cargarDomicilios() {
        SharedPreferences pref = getSharedPreferences("user_session", MODE_PRIVATE);
        webService.obtenerDomicilios(pref.getString("id_usuario", ""), new ConectaWebServiceDomicilio.Callback<List<Item_Domicilio>>() {
            @Override
            public void onSuccess(List<Item_Domicilio> result) {
                runOnUiThread(() -> adapter.updateDomicilios(result));
            }
            @Override
            public void onError(String error) { }
        });
    }

    private void setDomicilioPredeterminado(int id) {
        webService.setDomicilioPredeterminado(id, new ConectaWebServiceDomicilio.Callback<String>() {
            @Override
            public void onSuccess(String r) {
                runOnUiThread(() -> {
                    getSharedPreferences("user_session", MODE_PRIVATE)
                            .edit()
                            .putInt("id_domicilio_predeterminado", id)
                            .apply();
                    cargarDomicilios();
                });
            }
            @Override
            public void onError(String e) { }
        });
    }

    private void eliminarDomicilio(int id) {
        webService.eliminarDomicilio(id, new ConectaWebServiceDomicilio.Callback<String>() {
            @Override
            public void onSuccess(String r) {
                runOnUiThread(() -> cargarDomicilios());
            }
            @Override
            public void onError(String e) { }
        });
    }
}
