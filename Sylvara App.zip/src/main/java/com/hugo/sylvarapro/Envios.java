package com.hugo.sylvarapro;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class Envios extends AppCompatActivity {
    private RecyclerView RV_Envios;
    private AdaptadorEnvios adapter;
    private ConectaWebServiceEnvios webService;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_envios);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // Inicializar vistas
        RV_Envios = findViewById(R.id.RV_Envios);
        webService = new ConectaWebServiceEnvios();

        // Configurar RecyclerView
        RV_Envios.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AdaptadorEnvios(this, new ArrayList<>());
        RV_Envios.setAdapter(adapter);
        RV_Envios.setItemAnimator(new androidx.recyclerview.widget.DefaultItemAnimator());

        // Cargar envíos
        cargarEnvios();
    }

    private void cargarEnvios() {
        SharedPreferences preferences = getSharedPreferences("user_session", MODE_PRIVATE);
        String id_usuario = preferences.getString("id_usuario", "");
        if (id_usuario.isEmpty()) {
            Toast.makeText(this, "Sesión no iniciada. Por favor, inicia sesión.", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(this, Login.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            return;
        }

        webService.obtenerEnvios(id_usuario, new ConectaWebServiceEnvios.Callback<List<Item_Envio>>() {
            @Override
            public void onSuccess(List<Item_Envio> result) {
                runOnUiThread(() -> {
                    adapter.updateEnvios(result);
                    if (result.isEmpty()) {
                        Toast.makeText(Envios.this, "No hay envíos registrados", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("Envios", "Envíos cargados: " + result.size());
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> Toast.makeText(Envios.this, "Error: " + error, Toast.LENGTH_LONG).show());
                Log.e("Envios", "Error al cargar envíos: " + error);
            }
        });
    }

    private void confirmarCancelarCompra(int id_compras) {
        new AlertDialog.Builder(this)
                .setTitle("Cancelar Compra")
                .setMessage("¿Estás seguro de que deseas cancelar esta compra? No se podra deshacer esta accion")
                .setPositiveButton("Sí", (dialog, which) -> {
                    webService.cancelarCompra(id_compras, new ConectaWebServiceEnvios.Callback<String>() {
                        @Override
                        public void onSuccess(String result) {
                            runOnUiThread(() -> {
                                Toast.makeText(Envios.this, result, Toast.LENGTH_SHORT).show();
                                cargarEnvios(); // Recargar para actualizar la UI
                            });
                        }

                        @Override
                        public void onError(String error) {
                            runOnUiThread(() -> Toast.makeText(Envios.this, "Error: " + error, Toast.LENGTH_LONG).show());
                        }
                    });
                })
                .setNegativeButton("No", null)
                .show();
    }
}