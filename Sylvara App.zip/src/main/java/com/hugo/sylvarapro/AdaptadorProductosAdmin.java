package com.hugo.sylvarapro;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;

//hay ip

public class AdaptadorProductosAdmin extends RecyclerView.Adapter<AdaptadorProductosAdmin.ViewHolder> {
    private List<Item_Productos> datos;
    private Context context;
    private OnBorrarClickListener borrarListener;

    public interface OnBorrarClickListener {
        void onBorrarClick(int position);
    }

    public AdaptadorProductosAdmin(List<Item_Productos> datos, Context context) {
        this.datos = datos;
        this.context = context;
    }

    public void setOnBorrarClickListener(OnBorrarClickListener listener) {
        this.borrarListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_producto_admin, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item_Productos item = datos.get(position);

        // Lógica para Base64: Decodificar la cadena directamente
        String imagenBase64 = item.getImagen();
        if (imagenBase64 != null && !imagenBase64.isEmpty()) {
            try {
                // Si por alguna razón la cadena trae el prefijo de data:image, lo quitamos
                if (imagenBase64.contains(",")) {
                    imagenBase64 = imagenBase64.split(",")[1];
                }
                byte[] decodedString = Base64.decode(imagenBase64, Base64.DEFAULT);
                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                holder.imgProducto.setImageBitmap(decodedByte);
            } catch (Exception e) {
                holder.imgProducto.setImageResource(R.drawable.error);
            }
        } else {
            holder.imgProducto.setImageResource(R.drawable.carga);
        }

        holder.txtNombre.setText(item.getNombre());

        holder.btnEditar.setOnClickListener(v -> {
            Intent intent = new Intent(context, AgregarProductos.class);
            intent.putExtra("producto", item);
            context.startActivity(intent);
        });

        holder.btnBorrar.setOnClickListener(v -> {
            if (borrarListener != null) {
                borrarListener.onBorrarClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return datos.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgProducto;
        TextView txtNombre;
        Button btnEditar, btnBorrar;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgProducto = itemView.findViewById(R.id.IV_ProductAdmin);
            txtNombre = itemView.findViewById(R.id.TV_NombreProducAdmin);
            btnEditar = itemView.findViewById(R.id.button3);
            btnBorrar = itemView.findViewById(R.id.button5);
        }
    }
}
