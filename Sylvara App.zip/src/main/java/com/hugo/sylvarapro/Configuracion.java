package com.hugo.sylvarapro;
public class Configuracion {
    public static final String IP_SERVER = "192.168.1.216";
    public static final String PUERTO = "8081"; //va a ir cambiando gg
    public static final String CARPETA_PROYECTO = "Sylvara_pro";
    public static String getUrlBase() {
        String puertoFormateado = (PUERTO.isEmpty()) ? "" : ":" + PUERTO;
        return "http://" + IP_SERVER + puertoFormateado + "/" + CARPETA_PROYECTO + "/";
    }
}

    /*
    por si falla con el puerto gg, este manda sin puerto
    public static String getUrlBase() {
        return "http://" + IP_SERVER + PUERTO + "/" + CARPETA_PROYECTO + "/";
    }
     */

