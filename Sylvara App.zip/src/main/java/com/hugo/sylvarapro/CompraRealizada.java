package com.hugo.sylvarapro;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class CompraRealizada extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compra_realizada);

        boolean esExito = getIntent().getBooleanExtra("exito", true);

        ConstraintLayout layout = findViewById(R.id.main);
        TextView tvTitulo = findViewById(R.id.textView13);
        ImageView img = findViewById(R.id.imageView3);
        Button btnContinuar = findViewById(R.id.BTN_VolverMain);

        if (esExito) {
            layout.setBackgroundColor(Color.parseColor("#C6ECFD"));
            tvTitulo.setText("¡Gracias por tu compra!");
            img.setImageResource(R.drawable.agradecido);
            limpiarCarritoLocal();
        } else {
            layout.setBackgroundColor(Color.parseColor("#D51717"));
            tvTitulo.setText("No se pudo realizar la compra");
            tvTitulo.setTextColor(Color.BLACK);
            img.setImageResource(R.drawable.rechazar);
        }

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() { }
        });

        btnContinuar.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void limpiarCarritoLocal() {
        SharedPreferences pref = getSharedPreferences("CarritoPrefs", MODE_PRIVATE);
        pref.edit().clear().apply();
    }
}
