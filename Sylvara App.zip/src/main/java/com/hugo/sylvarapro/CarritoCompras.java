package com.hugo.sylvarapro;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
//no hay direccion ip


public class CarritoCompras extends AppCompatActivity implements AdaptadorCarrito.OnCantidadChangeListener {

    private RecyclerView rvCarrito;
    private AdaptadorCarrito adaptador;
    private ArrayList<Item_Productos> carritoProductos;
    private TextView tvProductos, TV_EnvioPrecio, TV_TotalCompra;
    private Button BTN_IrDomicilio;
    private CarritoManager carritoManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrito_compras);

        carritoManager = new CarritoManager(this);
        rvCarrito = findViewById(R.id.rvCarrito);
        tvProductos = findViewById(R.id.TV_Productos);
        TV_EnvioPrecio = findViewById(R.id.TV_EnvioPrecio);
        TV_TotalCompra = findViewById(R.id.TV_TotalCompra);
        BTN_IrDomicilio = findViewById(R.id.BTN_IrDomicilio);

        carritoProductos = carritoManager.obtenerCarrito();

        rvCarrito.setLayoutManager(new LinearLayoutManager(this));
        adaptador = new AdaptadorCarrito(carritoProductos, this, this);
        rvCarrito.setAdapter(adaptador);

        actualizarTotal();

        BTN_IrDomicilio.setOnClickListener(v -> {
            if (carritoProductos.isEmpty()) {
                Toast.makeText(this, "El carrito está vacío", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(this, Domicilio.class);
                intent.putParcelableArrayListExtra("carrito", carritoProductos);
                startActivity(intent);
            }
        });
    }

    private void actualizarTotal() {
        double subtotal = 0;
        boolean tieneProductosFisicos = false;

        for (Item_Productos item : carritoProductos) {
            String precioLimpio = item.getPrecio().replaceAll("[^0-9.]", "");
            subtotal += Double.parseDouble(precioLimpio) * item.getCantidad();
            if (!item.getNombre().toLowerCase().contains("bolita")) {
                tieneProductosFisicos = true;
            }
        }

        double envio = (tieneProductosFisicos && subtotal < 200) ? 49.0 : 0.0;

        tvProductos.setText(String.format("$%.2f", subtotal));
        TV_EnvioPrecio.setText(String.format("$%.2f", envio));
        TV_TotalCompra.setText(String.format("$%.2f", subtotal + envio));

        carritoManager.guardarCarrito(carritoProductos);
    }

    @Override
    public void onCantidadChanged() {
        actualizarTotal();
    }
}
