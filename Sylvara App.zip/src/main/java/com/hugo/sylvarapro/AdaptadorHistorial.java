package com.hugo.sylvarapro;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdaptadorHistorial extends RecyclerView.Adapter<AdaptadorHistorial.ViewHolder> {
    private List<Item_Historial> lista;

    public AdaptadorHistorial(List<Item_Historial> lista) { this.lista = lista; }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_historial_cosecha, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item_Historial item = lista.get(position);
        holder.tvFecha.setText("Finalizó: " + item.getFechaFin());
        holder.tvComentario.setText(item.getComentarios().isEmpty() ? "Sin comentarios" : item.getComentarios());
        holder.tvEstado.setText(item.getEstado().toUpperCase());

        if (item.getEstado().equalsIgnoreCase("Exitosa")) {
            holder.tvEstado.setTextColor(Color.parseColor("#2E7D32")); // Verde
        } else {
            holder.tvEstado.setTextColor(Color.RED);
        }
    }

    @Override public int getItemCount() { return lista.size(); }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvFecha, tvEstado, tvComentario;
        public ViewHolder(@NonNull View v) {
            super(v);
            tvFecha = v.findViewById(R.id.tvFechaNota);
            tvEstado = v.findViewById(R.id.tvEstadoNota);
            tvComentario = v.findViewById(R.id.tvComentarioNota);
        }
    }
}