package com.hugo.sylvarapro;

import android.os.Parcel;
import android.os.Parcelable;

public class Item_Invernadero implements Parcelable {
    private int idInvernadero;
    private String nombre;
    private int idUsuario;
    private boolean activa;
    private double latitud;
    private double longitud;
    private int idBolitaActiva; // Nueva mejora para automatización

    public Item_Invernadero(int idInvernadero, String nombre, int idUsuario, boolean activa, double latitud, double longitud, int idBolitaActiva) {
        this.idInvernadero = idInvernadero;
        this.nombre = nombre;
        this.idUsuario = idUsuario;
        this.activa = activa;
        this.latitud = latitud;
        this.longitud = longitud;
        this.idBolitaActiva = idBolitaActiva;
    }

    protected Item_Invernadero(Parcel in) {
        idInvernadero = in.readInt();
        nombre = in.readString();
        idUsuario = in.readInt();
        activa = in.readByte() != 0;
        latitud = in.readDouble();
        longitud = in.readDouble();
        idBolitaActiva = in.readInt();
    }

    public static final Creator<Item_Invernadero> CREATOR = new Creator<Item_Invernadero>() {
        @Override
        public Item_Invernadero createFromParcel(Parcel in) { return new Item_Invernadero(in); }
        @Override
        public Item_Invernadero[] newArray(int size) { return new Item_Invernadero[size]; }
    };

    @Override
    public int describeContents() { return 0; }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(idInvernadero);
        dest.writeString(nombre);
        dest.writeInt(idUsuario);
        dest.writeByte((byte) (activa ? 1 : 0));
        dest.writeDouble(latitud);
        dest.writeDouble(longitud);
        dest.writeInt(idBolitaActiva);
    }

    // Getters y Setters
    public int getIdInvernadero() { return idInvernadero; }
    public String getNombre() { return nombre; }
    public boolean isActiva() { return activa; }
    public double getLatitud() { return latitud; }
    public double getLongitud() { return longitud; }
    public int getIdBolitaActiva() { return idBolitaActiva; }
    public void setIdBolitaActiva(int idBolitaActiva) { this.idBolitaActiva = idBolitaActiva; }

    @Override
    public String toString() { return nombre; }
}