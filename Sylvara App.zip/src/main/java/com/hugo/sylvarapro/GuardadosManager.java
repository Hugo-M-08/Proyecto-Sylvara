package com.hugo.sylvarapro;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class GuardadosManager {
    private static final String PREF_NAME = "GuardadosPrefs";
    private static final String KEY_GUARDADOS = "lista_guardados";
    private SharedPreferences sharedPreferences;
    private Gson gson;

    public GuardadosManager(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
    }

    public void alternarGuardado(Item_Productos producto) {
        ArrayList<Item_Productos> lista = obtenerGuardados();
        if (lista.contains(producto)) {
            lista.remove(producto);
        } else {
            lista.add(producto);
        }
        String json = gson.toJson(lista);
        sharedPreferences.edit().putString(KEY_GUARDADOS, json).apply();
    }

    public ArrayList<Item_Productos> obtenerGuardados() {
        String json = sharedPreferences.getString(KEY_GUARDADOS, null);
        if (json == null) return new ArrayList<>();
        Type type = new TypeToken<ArrayList<Item_Productos>>() {}.getType();
        return gson.fromJson(json, type);
    }

    public boolean estaGuardado(String id_producto) {
        ArrayList<Item_Productos> lista = obtenerGuardados();
        for (Item_Productos p : lista) {
            if (p.getId_producto().equals(id_producto)) return true;
        }
        return false;
    }
}