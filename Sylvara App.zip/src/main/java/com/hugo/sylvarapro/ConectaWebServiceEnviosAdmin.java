package com.hugo.sylvarapro;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;
public class ConectaWebServiceEnviosAdmin {
    public interface Callback<T> {
        void onSuccess(T result);
        void onError(String error);
    }

    private static final String CARPETA_COMPRA = "Compra/";
    private static final String BASE_URL = Configuracion.getUrlBase() + CARPETA_COMPRA + "obtener_todos_envios.php";
    private static final String ACTUALIZAR_URL = Configuracion.getUrlBase() + CARPETA_COMPRA + "actualizar_estado.php";

    public void obtenerTodosEnvios(Callback<List<Item_EnvioAdmin>> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(BASE_URL);
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("GET");

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        response.append(linea);
                    }
                    reader.close();

                    if (response.toString().equals("010")) {
                        callback.onSuccess(new ArrayList<>());
                    } else {
                        List<Item_EnvioAdmin> envios = new ArrayList<>();
                        JSONArray jsonArray = new JSONArray(response.toString());
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject json = jsonArray.getJSONObject(i);
                            envios.add(new Item_EnvioAdmin(
                                    json.getInt("id_detalle"),
                                    json.getInt("id_compras"),
                                    json.getString("fecha"),
                                    json.getString("producto"),
                                    json.getInt("cantidad"),
                                    json.getDouble("precio_unitario"),
                                    json.getDouble("total"),
                                    json.getString("status")
                            ));
                        }
                        callback.onSuccess(envios);
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception e) {
                callback.onError("Error de servidor: " + e.getMessage());
            }
        });
    }

    // Cambiado: ahora recibe id_compras en lugar de id_detalle
    public void actualizarEstado(int id_compras, String nuevoStatus, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            String aux = "";
            try {
                URL url = new URL(ACTUALIZAR_URL);
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                // Cambiado: envía id_compras en lugar de id_detalle
                String data = "id_compras=" + URLEncoder.encode(String.valueOf(id_compras), "UTF-8") +
                        "&status=" + URLEncoder.encode(nuevoStatus, "UTF-8");

                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(data);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    String response = reader.readLine();
                    reader.close();

                    switch (response) {
                        case "001":
                            callback.onError("Datos faltantes");
                            break;
                        case "002":
                            callback.onSuccess("Estado actualizado correctamente");
                            break;
                        case "000":
                            callback.onError("No se pudo actualizar el estado");
                            break;
                        default:
                            callback.onError("Respuesta desconocida: " + response);
                            break;
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception e) {
                callback.onError("Error de servidor: " + e.getMessage());
            }
        });
    }
}