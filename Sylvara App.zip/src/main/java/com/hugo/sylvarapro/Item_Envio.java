package com.hugo.sylvarapro;
import android.os.Parcel;
import android.os.Parcelable;

public class Item_Envio implements Parcelable {
    private int id_compras;
    private String imagen;
    private String status;
    private String fecha_entrega;
    private int id_usuario;
    private double total;
    private double envio;
    private int id_producto;

    public Item_Envio(int id_compras, String imagen, String status, String fecha_entrega, int id_usuario, double total, double envio, int id_producto) {
        this.id_compras = id_compras;
        this.imagen = imagen;
        this.status = status;
        this.fecha_entrega = fecha_entrega;
        this.id_usuario = id_usuario;
        this.total = total;
        this.envio = envio;
        this.id_producto = id_producto;
    }

    protected Item_Envio(Parcel in) {
        id_compras = in.readInt();
        imagen = in.readString();
        status = in.readString();
        fecha_entrega = in.readString();
        id_usuario = in.readInt();
        total = in.readDouble();
        envio = in.readDouble();
        id_producto = in.readInt();
    }

    public static final Creator<Item_Envio> CREATOR = new Creator<Item_Envio>() {
        @Override
        public Item_Envio createFromParcel(Parcel in) {
            return new Item_Envio(in);
        }

        @Override
        public Item_Envio[] newArray(int size) {
            return new Item_Envio[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id_compras);
        dest.writeString(imagen);
        dest.writeString(status);
        dest.writeString(fecha_entrega);
        dest.writeInt(id_usuario);
        dest.writeDouble(total);
        dest.writeDouble(envio);
        dest.writeInt(id_producto);
    }

    public int getId_compras() { return id_compras; }
    public String getImagen() { return imagen; }
    public String getStatus() { return status; }
    public String getFecha_entrega() { return fecha_entrega; }
    public int getId_usuario() { return id_usuario; }
    public double getTotal() { return total; }
    public double getEnvio() { return envio; }
    public int getId_producto() { return id_producto; }
}