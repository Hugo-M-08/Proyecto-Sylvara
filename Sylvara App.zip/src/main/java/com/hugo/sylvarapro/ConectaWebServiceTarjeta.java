package com.hugo.sylvarapro;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.Locale;

public class ConectaWebServiceTarjeta {
    public interface Callback<T> {
        void onSuccess(T result);
        void onError(String error);
    }

    public void obtenerTarjetas(String id_usuario, Callback<List<Item_Tarjeta>> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Pago/ver_tarjetas.php");
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String data = "id_usuario=" + URLEncoder.encode(id_usuario, "UTF-8");
                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(data);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        response.append(linea);
                    }
                    reader.close();

                    JSONObject jsonResponse = new JSONObject(response.toString());
                    String code = jsonResponse.getString("code");
                    if (code.equals("001")) {
                        callback.onError(jsonResponse.getString("message"));
                    } else if (code.equals("010")) {
                        callback.onSuccess(new ArrayList<>());
                    } else if (code.equals("002")) {
                        List<Item_Tarjeta> tarjetas = new ArrayList<>();
                        JSONArray jsonArray = jsonResponse.getJSONArray("data");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject json = jsonArray.getJSONObject(i);
                            tarjetas.add(new Item_Tarjeta(
                                    json.getInt("id_tarjeta"),
                                    json.getString("titular"),
                                    json.getString("numero_tarjeta"),
                                    json.getString("cvv"),
                                    json.getString("fecha_vencimiento"),
                                    json.getString("alias"),
                                    json.getInt("id_usuario"),
                                    json.getInt("es_predeterminada") == 1
                            ));
                        }
                        callback.onSuccess(tarjetas);
                    } else {
                        callback.onError("Error desconocido: " + code);
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception ex) {
                callback.onError("Error de servidor: " + ex.getMessage());
            }
        });
    }

    public void insertarTarjeta(String titular, String numero_tarjeta, String cvv, String fecha_vencimiento,
                                String alias, String id_usuario, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Pago/insertar_tarjeta.php");
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String data = "titular=" + URLEncoder.encode(titular, "UTF-8") +
                        "&numero_tarjeta=" + URLEncoder.encode(numero_tarjeta, "UTF-8") +
                        "&cvv=" + URLEncoder.encode(cvv, "UTF-8") +
                        "&fecha_vencimiento=" + URLEncoder.encode(fecha_vencimiento, "UTF-8") +
                        "&alias=" + URLEncoder.encode(alias, "UTF-8") +
                        "&id_usuario=" + URLEncoder.encode(id_usuario, "UTF-8");

                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(data);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    String response = reader.readLine();
                    reader.close();

                    JSONObject jsonResponse = new JSONObject(response);
                    if (jsonResponse.getString("code").equals("002")) {
                        callback.onSuccess(jsonResponse.getString("message"));
                    } else {
                        callback.onError(jsonResponse.getString("message"));
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception ex) {
                callback.onError("Error de servidor: " + ex.getMessage());
            }
        });
    }

    public void modificarTarjeta(int id_tarjeta, String titular, String numero_tarjeta, String cvv,
                                 String fecha_vencimiento, String alias, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Pago/modificar_tarjeta.php");
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String data = "id_tarjeta=" + id_tarjeta +
                        "&titular=" + URLEncoder.encode(titular, "UTF-8") +
                        "&numero_tarjeta=" + URLEncoder.encode(numero_tarjeta, "UTF-8") +
                        "&cvv=" + URLEncoder.encode(cvv, "UTF-8") +
                        "&fecha_vencimiento=" + URLEncoder.encode(fecha_vencimiento, "UTF-8") +
                        "&alias=" + URLEncoder.encode(alias, "UTF-8");

                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(data);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    String response = reader.readLine();
                    reader.close();
                    JSONObject jsonResponse = new JSONObject(response);
                    if (jsonResponse.getString("code").equals("002")) {
                        callback.onSuccess(jsonResponse.getString("message"));
                    } else {
                        callback.onError(jsonResponse.getString("message"));
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception ex) {
                callback.onError("Error de servidor: " + ex.getMessage());
            }
        });
    }

    public void eliminarTarjeta(int id_tarjeta, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Pago/eliminar_tarjeta.php");
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String data = "id_tarjeta=" + id_tarjeta;
                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(data);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    String response = reader.readLine();
                    reader.close();
                    JSONObject jsonResponse = new JSONObject(response);
                    if (jsonResponse.getString("code").equals("002")) {
                        callback.onSuccess(jsonResponse.getString("message"));
                    } else {
                        callback.onError(jsonResponse.getString("message"));
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception ex) {
                callback.onError("Error de servidor: " + ex.getMessage());
            }
        });
    }

    public void setTarjetaPredeterminada(int id_tarjeta, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Pago/set_tarjeta_predeterminada.php");
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String data = "id_tarjeta=" + id_tarjeta;
                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(data);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    String response = reader.readLine();
                    reader.close();
                    JSONObject jsonResponse = new JSONObject(response);
                    if (jsonResponse.getString("code").equals("002")) {
                        callback.onSuccess(jsonResponse.getString("message"));
                    } else {
                        callback.onError(jsonResponse.getString("message"));
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception ex) {
                callback.onError("Error de servidor: " + ex.getMessage());
            }
        });
    }

    public void insertarCompra(String id_usuario, int id_tarjeta, double total, JSONArray detalles, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Pago/insertar_compra.php");
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("POST");
                con.setDoOutput(true);
                con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                // MEJORA: Asegurar que el total tenga formato de punto decimal y no coma
                String totalStr = String.valueOf(total);
                String detallesStr = detalles.toString();

                String data = "id_usuario=" + URLEncoder.encode(id_usuario, "UTF-8") +
                        "&id_tarjeta=" + id_tarjeta +
                        "&total=" + URLEncoder.encode(totalStr, "UTF-8") +
                        "&detalles=" + URLEncoder.encode(detallesStr, "UTF-8");

                OutputStreamWriter out = new OutputStreamWriter(con.getOutputStream());
                out.write(data);
                out.flush();
                out.close();

                if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) { response.append(line); }
                    reader.close();

                    JSONObject json = new JSONObject(response.toString());
                    if (json.getString("code").equals("002")) {
                        callback.onSuccess(json.getString("message"));
                    } else {
                        // Aquí el PHP nos dirá si es "Saldo insuficiente" o "Carrito vacío"
                        callback.onError(json.getString("message"));
                    }
                } else {
                    callback.onError("Error de conexión: " + con.getResponseCode());
                }
            } catch (Exception e) {
                callback.onError("Error en la petición: " + e.getMessage());
            }
        });
    }


}