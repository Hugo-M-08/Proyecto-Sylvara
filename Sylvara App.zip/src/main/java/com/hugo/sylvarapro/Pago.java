package com.hugo.sylvarapro;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
//no hay ip
public class Pago extends AppCompatActivity {

    private RecyclerView RV_Tarjetas;
    private Button BTN_AgregarTarjeta, BTN_Pagar;
    private AdaptadorTarjeta adapter;
    private ConectaWebServiceTarjeta webService;
    private ArrayList<Item_Productos> carritoProductos;
    private static final int REQUEST_CODE_AGREGAR_TARJETA = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pago);

        carritoProductos = getIntent().getParcelableArrayListExtra("carrito");
        if (carritoProductos == null) carritoProductos = new ArrayList<>();

        RV_Tarjetas = findViewById(R.id.RV_Tarjetas);
        BTN_AgregarTarjeta = findViewById(R.id.BTN_AgregarTarjeta);
        BTN_Pagar = findViewById(R.id.BTN_Pagar);

        webService = new ConectaWebServiceTarjeta();

        RV_Tarjetas.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AdaptadorTarjeta(this, new ArrayList<>(),
                this::setTarjetaPredeterminada,
                this::eliminarTarjeta);
        RV_Tarjetas.setAdapter(adapter);

        cargarTarjetas();

        BTN_AgregarTarjeta.setOnClickListener(v -> {
            Intent intent = new Intent(Pago.this, AgregarPago.class);
            intent.putExtra("isModifying", false);
            startActivityForResult(intent, REQUEST_CODE_AGREGAR_TARJETA);
        });

        BTN_Pagar.setOnClickListener(v -> procesarPago());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) cargarTarjetas();
    }

    private void cargarTarjetas() {
        SharedPreferences pref = getSharedPreferences("user_session", MODE_PRIVATE);
        webService.obtenerTarjetas(pref.getString("id_usuario", ""),
                new ConectaWebServiceTarjeta.Callback<List<Item_Tarjeta>>() {
                    @Override
                    public void onSuccess(List<Item_Tarjeta> result) {
                        runOnUiThread(() -> adapter.updateTarjetas(result));
                    }
                    @Override
                    public void onError(String error) {
                        runOnUiThread(() ->
                                Toast.makeText(Pago.this, error, Toast.LENGTH_SHORT).show());
                    }
                });
    }

    private void setTarjetaPredeterminada(int id_tarjeta) {
        webService.setTarjetaPredeterminada(id_tarjeta,
                new ConectaWebServiceTarjeta.Callback<String>() {
                    @Override
                    public void onSuccess(String result) {
                        runOnUiThread(() -> {
                            SharedPreferences pref = getSharedPreferences("user_session", MODE_PRIVATE);
                            pref.edit().putInt("id_tarjeta_predeterminada", id_tarjeta).apply();
                            cargarTarjetas();
                        });
                    }
                    @Override
                    public void onError(String error) {
                        runOnUiThread(() ->
                                Toast.makeText(Pago.this, error, Toast.LENGTH_SHORT).show());
                    }
                });
    }

    private void eliminarTarjeta(int id_tarjeta) {
        webService.eliminarTarjeta(id_tarjeta,
                new ConectaWebServiceTarjeta.Callback<String>() {
                    @Override
                    public void onSuccess(String result) {
                        runOnUiThread(() -> cargarTarjetas());
                    }
                    @Override
                    public void onError(String error) {
                        runOnUiThread(() ->
                                Toast.makeText(Pago.this, error, Toast.LENGTH_SHORT).show());
                    }
                });
    }

    private void procesarPago() {
        SharedPreferences pref = getSharedPreferences("user_session", MODE_PRIVATE);
        String id_usuario = pref.getString("id_usuario", "");

        int id_tarjeta = pref.getInt("id_tarjeta_predeterminada", -1);

        if (id_tarjeta == -1) {
            Toast.makeText(this, "Por favor, selecciona una tarjeta", Toast.LENGTH_SHORT).show();
            return;
        }

        double total = 0;
        JSONArray detalles = new JSONArray();

        try {
            for (Item_Productos p : carritoProductos) {
                // Limpiar el precio de símbolos de moneda para evitar errores de Double
                String precioLimpio = p.getPrecio().replaceAll("[^0-9.]", "");
                double precio = Double.parseDouble(precioLimpio);
                total += precio * p.getCantidad();

                JSONObject o = new JSONObject();
                o.put("id_producto", p.getId_producto());
                o.put("cantidad", p.getCantidad());
                o.put("precio_unitario", precio);
                detalles.put(o);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error al procesar los productos", Toast.LENGTH_SHORT).show();
            return;
        }

        // Enviamos el total y el JSON de detalles como String
        webService.insertarCompra(id_usuario, id_tarjeta, total, detalles,
                new ConectaWebServiceTarjeta.Callback<String>() {
                    @Override
                    public void onSuccess(String result) {
                        runOnUiThread(() -> {
                            Intent intent = new Intent(Pago.this, CompraRealizada.class);
                            intent.putExtra("exito", true);
                            startActivity(intent);
                            finish();
                        });
                    }

                    @Override
                    public void onError(String error) {
                        runOnUiThread(() -> {
                            // Logcat para que veas el error exacto que manda el PHP
                            Log.e("API_ERROR", "Respuesta del servidor: " + error);
                            Intent intent = new Intent(Pago.this, CompraRealizada.class);
                            intent.putExtra("exito", false);
                            intent.putExtra("mensaje", error);
                            startActivity(intent);
                        });
                    }
                });
    }
}
