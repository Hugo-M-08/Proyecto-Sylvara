package com.hugo.sylvarapro;

public class Item_Historial {
    private String fechaInicio, fechaFin, estado, comentarios;

    public Item_Historial(String fechaInicio, String fechaFin, String estado, String comentarios) {
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.estado = estado;
        this.comentarios = comentarios;
    }

    public String getFechaFin() { return fechaFin; }
    public String getEstado() { return estado; }
    public String getComentarios() { return comentarios; }
}