package com.hugo.sylvarapro;

import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class ConectaWebServiceTienda {
    private static final String CARPETA_TIENDA = "Tienda/";

    private static final String BASE_URL = Configuracion.getUrlBase() + CARPETA_TIENDA + "mostrar_productos.php";
    private static final String INSERTAR_URL = Configuracion.getUrlBase() + CARPETA_TIENDA + "subir_producto.php";
    private static final String MODIFICAR_URL = Configuracion.getUrlBase() + CARPETA_TIENDA + "modificar_producto.php";
    private static final String ELIMINAR_URL = Configuracion.getUrlBase() + CARPETA_TIENDA + "eliminar_producto.php";

    public interface Callback<T> {
        void onSuccess(T result);
        void onError(String error);
    }

    public String insertarProducto(String nombre, String descripcion, String precio, String unidades, String imagenBase64) {
        String aux = "";
        try {
            URL url = new URL(INSERTAR_URL);
            HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
            conexion.setRequestMethod("POST");
            conexion.setDoOutput(true);
            conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

            String data = "nombre=" + URLEncoder.encode(nombre, "UTF-8") +
                    "&descripcion=" + URLEncoder.encode(descripcion, "UTF-8") +
                    "&precio=" + URLEncoder.encode(precio, "UTF-8") +
                    "&unidades=" + URLEncoder.encode(unidades, "UTF-8") +
                    "&imagen=" + URLEncoder.encode(imagenBase64, "UTF-8");

            OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
            datSal.write(data);
            datSal.flush();
            datSal.close();

            if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                StringBuilder response = new StringBuilder();
                String linea;
                while ((linea = reader.readLine()) != null) {
                    response.append(linea);
                }
                reader.close();
                aux = response.toString();

                switch (aux) {
                    case "002":
                        aux = "Producto registrado correctamente";
                        break;
                    case "001":
                        aux = "Datos faltantes";
                        break;
                    case "000":
                        aux = "No se pudo registrar el producto";
                        break;
                    case "003":
                        aux = "Error al guardar la imagen en el servidor";
                        break;
                    default:
                        aux = "Error desconocido: " + aux;
                        break;
                }
            } else {
                aux = "ERROR al procesar servicio: " + conexion.getResponseCode();
            }

            conexion.disconnect();
        } catch (Exception ex) {
            aux = "ERROR de SERVIDOR: " + ex.getMessage();
        }
        return aux;
    }


    public void obtenerProductos(Callback<List<Item_Productos>> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            String result = "";
            try {
                URL url = new URL(BASE_URL);
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("GET");

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        response.append(linea);
                    }
                    reader.close();
                    result = response.toString();

                    try {
                        JSONObject jsonResponse = new JSONObject(result);
                        if (jsonResponse.has("error")) {
                            callback.onError(jsonResponse.getString("error"));
                            return;
                        } else if (jsonResponse.has("code") && jsonResponse.getString("code").equals("010")) {
                            callback.onError(jsonResponse.getString("message"));
                            return;
                        }
                    } catch (Exception e) {
                        // Si no es un objeto JSON, asumimos que es un array de productos
                    }

                    List<Item_Productos> productos = new ArrayList<>();
                    JSONArray jsonArray = new JSONArray(result);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject producto = jsonArray.getJSONObject(i);
                        productos.add(new Item_Productos(
                                producto.optString("id_producto", ""),
                                producto.getString("nombre"),
                                producto.getString("descripcion"),
                                producto.getString("precio"),
                                producto.getString("unidades"),
                                producto.getString("imagen"),
                                (float) producto.optDouble("calificacion", 0.0)
                        ));
                    }
                    callback.onSuccess(productos);
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception e) {
                callback.onError("Error de servidor: " + e.getMessage());
            }
        });
    }

    public void modificarProducto(String id_producto, String nombre, String descripcion, String precio, String unidades, String imagenBase64, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            String aux = "";
            try {
                URL url = new URL(MODIFICAR_URL);
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                String data = "id_producto=" + URLEncoder.encode(id_producto, "UTF-8");
                datSal.write(data);
                data = "&nombre=" + URLEncoder.encode(nombre, "UTF-8");
                datSal.write(data);
                data = "&descripcion=" + URLEncoder.encode(descripcion, "UTF-8");
                datSal.write(data);
                data = "&precio=" + URLEncoder.encode(precio, "UTF-8");
                datSal.write(data);
                data = "&unidades=" + URLEncoder.encode(unidades, "UTF-8");
                datSal.write(data);
                data = "&imagen=" + URLEncoder.encode(imagenBase64, "UTF-8");
                datSal.write(data);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    String linea = reader.readLine();
                    while (linea != null) {
                        aux = aux + linea;
                        linea = reader.readLine();
                    }
                    reader.close();
                    if (aux.equals("002")) {
                        aux = "Producto modificado correctamente";
                    } else if (aux.equals("001")) {
                        aux = "Datos faltantes";
                    } else if (aux.equals("000")) {
                        aux = "No se pudo modificar el producto";
                    } else {
                        aux = "Error desconocido: " + aux;
                    }
                    callback.onSuccess(aux);
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception ex) {
                callback.onError("ERROR de SERVIDOR: " + ex.getMessage());
            }
        });
    }

    public void eliminarProducto(String id_producto, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            String aux = "";
            try {
                URL url = new URL(ELIMINAR_URL + "?id_producto=" + URLEncoder.encode(id_producto, "UTF-8"));
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("GET");

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    String linea = reader.readLine();
                    while (linea != null) {
                        aux = aux + linea;
                        linea = reader.readLine();
                    }
                    reader.close();
                    if (aux.equals("002")) {
                        aux = "Producto eliminado correctamente";
                    } else if (aux.equals("001")) {
                        aux = "ID faltante";
                    } else if (aux.equals("010")) {
                        aux = "No se encontró el producto";
                    } else {
                        aux = "Error desconocido: " + aux;
                    }
                    callback.onSuccess(aux);
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception ex) {
                callback.onError("ERROR de SERVIDOR: " + ex.getMessage());
            }
        });
    }
}