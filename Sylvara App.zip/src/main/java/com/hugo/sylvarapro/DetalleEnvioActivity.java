package com.hugo.sylvarapro;

import android.content.ContentValues;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class DetalleEnvioActivity extends AppCompatActivity {
    private TextView tvStatus, tvFecha, tvNumCompra, tvSubtotal, tvCostoEnvio, tvTotal;
    private Button btnAccion, BTN_DescargarRecibo, btnCalificar;
    private ImageView ivProducto;
    private ConectaWebServiceEnvios webService;
    private int idCompra;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_envio);

        // 1. Inicializar el servicio Web
        webService = new ConectaWebServiceEnvios();

        // 2. Obtener datos enviados desde la actividad anterior (Intent)
        idCompra = getIntent().getIntExtra("id_compras", 0);
        String status = getIntent().getStringExtra("status");
        String fecha = getIntent().getStringExtra("fecha");
        String imagenBase64 = getIntent().getStringExtra("imagen");
        double total = getIntent().getDoubleExtra("total", 0.0);
        double costoEnvio = getIntent().getDoubleExtra("envio_costo", 0.0);
        double subtotal = total - costoEnvio;

        // 3. Inicializar Vistas con findViewById (DEBE HACERSE ANTES DE USARLAS)
        tvStatus = findViewById(R.id.TV_DetalleStatus);
        tvFecha = findViewById(R.id.TV_DetalleFecha);
        tvNumCompra = findViewById(R.id.TV_DetalleID);
        btnAccion = findViewById(R.id.BTN_AccionEnvio);
        ivProducto = findViewById(R.id.IV_DetalleEnvioImagen);
        BTN_DescargarRecibo = findViewById(R.id.BTN_DescargarRecibo);
        btnCalificar = findViewById(R.id.btnCalificar);
        tvSubtotal = findViewById(R.id.TV_ResumenSubtotal);
        tvCostoEnvio = findViewById(R.id.TV_ResumenEnvio);
        tvTotal = findViewById(R.id.TV_ResumenTotal);

        // 4. Procesar y mostrar la imagen en Base64
        if (imagenBase64 != null && !imagenBase64.isEmpty()) {
            try {
                if (imagenBase64.contains(",")) {
                    imagenBase64 = imagenBase64.split(",")[1];
                }
                byte[] decodedString = Base64.decode(imagenBase64, Base64.DEFAULT);
                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                ivProducto.setImageBitmap(decodedByte);
            } catch (Exception e) {
                ivProducto.setImageResource(R.drawable.error);
                Log.e("DetalleEnvio", "Error decodificando Base64: " + e.getMessage());
            }
        } else {
            ivProducto.setImageResource(R.drawable.carga);
        }

        // 5. Asignar textos a la interfaz
        tvNumCompra.setText("Pedido #" + idCompra);
        tvStatus.setText(status);
        tvFecha.setText("Fecha estimada: " + fecha);
        tvSubtotal.setText(String.format("$%.2f", subtotal));
        tvCostoEnvio.setText(String.format("$%.2f", costoEnvio));
        tvTotal.setText(String.format("$%.2f", total));

        // 6. Actualizar UI según el estado del envío
        if (status != null) {
            actualizarBarraProgreso(status);
        }

        // 7. Configurar Listeners
        BTN_DescargarRecibo.setOnClickListener(v -> crearPdfReal());
        btnCalificar.setOnClickListener(v -> mostrarDialogoCalificacion());
        configurarBotonAccion(status, fecha);
    }

    private void configurarBotonAccion(String status, String fechaEntrega) {
        btnCalificar.setVisibility(View.GONE);
        if (status == null) return;

        if (status.equalsIgnoreCase("Entregado")) {
            btnCalificar.setVisibility(View.VISIBLE);
            if (verificarPlazoDevolucion(fechaEntrega)) {
                btnAccion.setVisibility(View.VISIBLE);
                btnAccion.setText("Devolución de artículos");
                btnAccion.setOnClickListener(v -> procesarDevolucion());
            } else {
                btnAccion.setVisibility(View.GONE);
            }
        } else if (status.equalsIgnoreCase("Proceso de devolución") || status.equalsIgnoreCase("Devuelto") || status.equalsIgnoreCase("Cancelado")) {
            btnAccion.setVisibility(View.GONE);
        } else {
            btnAccion.setVisibility(View.VISIBLE);
            btnAccion.setText("Cancelar compra");
            btnAccion.setOnClickListener(v -> confirmarCancelacion());
        }
    }

    private boolean verificarPlazoDevolucion(String fechaEntrega) {
        if (fechaEntrega == null) return false;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date dateEntrega = sdf.parse(fechaEntrega);
            Date hoy = new Date();
            long diff = hoy.getTime() - dateEntrega.getTime();
            return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS) <= 30;
        } catch (Exception e) {
            return false;
        }
    }

    private void confirmarCancelacion() {
        new AlertDialog.Builder(this)
                .setTitle("¿Cancelar pedido?")
                .setMessage("Esta acción no se puede deshacer.")
                .setPositiveButton("Sí, cancelar", (d, w) -> {
                    webService.cancelarCompra(idCompra, new ConectaWebServiceEnvios.Callback<String>() {
                        @Override
                        public void onSuccess(String result) {
                            runOnUiThread(() -> {
                                Toast.makeText(DetalleEnvioActivity.this, "Pedido Cancelado", Toast.LENGTH_SHORT).show();
                                finish();
                            });
                        }
                        @Override
                        public void onError(String error) {
                            runOnUiThread(() -> Toast.makeText(DetalleEnvioActivity.this, error, Toast.LENGTH_SHORT).show());
                        }
                    });
                }).setNegativeButton("No", null).show();
    }

    private void procesarDevolucion() {
        new AlertDialog.Builder(this)
                .setTitle("Solicitar Devolución")
                .setMessage("El estatus cambiará a Proceso de devolución. ¿Continuar?")
                .setPositiveButton("Sí", (d, w) -> {
                    webService.solicitarDevolucion(idCompra, new ConectaWebServiceEnvios.Callback<String>() {
                        @Override
                        public void onSuccess(String result) {
                            runOnUiThread(() -> {
                                tvStatus.setText("Proceso de devolución");
                                actualizarBarraProgreso("Proceso de devolución");
                                btnAccion.setVisibility(View.GONE);
                                Toast.makeText(DetalleEnvioActivity.this, "Solicitud enviada", Toast.LENGTH_SHORT).show();
                            });
                        }
                        @Override
                        public void onError(String error) { }
                    });
                }).setNegativeButton("No", null).show();
    }

    private void actualizarBarraProgreso(String status) {
        View step1 = findViewById(R.id.step1);
        View step2 = findViewById(R.id.step2);
        View step3 = findViewById(R.id.step3);
        View line1 = findViewById(R.id.line1);
        View line2 = findViewById(R.id.line2);

        int colorBlue = Color.parseColor("#00A8E8");
        int colorOrange = Color.parseColor("#FFA500");
        int colorRed = Color.parseColor("#D51717");
        int colorGray = Color.parseColor("#E0E0E0");

        step1.setBackgroundColor(colorGray);
        line1.setBackgroundColor(colorGray);
        step2.setBackgroundColor(colorGray);
        line2.setBackgroundColor(colorGray);
        step3.setBackgroundColor(colorGray);

        if (status.equalsIgnoreCase("Preparando envío")) {
            step1.setBackgroundColor(colorBlue);
        } else if (status.equalsIgnoreCase("En tránsito")) {
            step1.setBackgroundColor(colorBlue);
            line1.setBackgroundColor(colorBlue);
            step2.setBackgroundColor(colorBlue);

        }  else if (status.equalsIgnoreCase("Fallido")) {
            step1.setBackgroundColor(colorRed);
            line1.setBackgroundColor(colorRed);
            step2.setBackgroundColor(colorRed);
        } else if (status.equalsIgnoreCase("Segundo intento de entrega")) {
            step1.setBackgroundColor(colorOrange);
            line1.setBackgroundColor(colorOrange);
            step2.setBackgroundColor(colorOrange);
        }  else if (status.equalsIgnoreCase("Tercer intento de entrega")) {
            step1.setBackgroundColor(colorOrange);
            line1.setBackgroundColor(colorOrange);
            step2.setBackgroundColor(colorOrange);
        }
        else if (status.equalsIgnoreCase("Entregado")) {
            step1.setBackgroundColor(colorBlue);
            line1.setBackgroundColor(colorBlue);
            step2.setBackgroundColor(colorBlue);
            line2.setBackgroundColor(colorBlue);
            step3.setBackgroundColor(colorBlue);
        } else if (status.equalsIgnoreCase("Proceso de devolución")) {
            step1.setBackgroundColor(colorOrange);
            line1.setBackgroundColor(colorOrange);
            step2.setBackgroundColor(colorOrange);
            line2.setBackgroundColor(colorOrange);
            step3.setBackgroundColor(colorOrange);
        } else if (status.equalsIgnoreCase("Devuelto")) {
            step1.setBackgroundColor(colorRed);
            line1.setBackgroundColor(colorRed);
            step2.setBackgroundColor(colorRed);
            line2.setBackgroundColor(colorRed);
            step3.setBackgroundColor(colorRed);
        }
    }

    private void crearPdfReal() {
        PdfDocument documento = new PdfDocument();
        Paint paint = new Paint();
        PdfDocument.PageInfo paginaInfo = new PdfDocument.PageInfo.Builder(300, 500, 1).create();
        PdfDocument.Page pagina = documento.startPage(paginaInfo);
        Canvas canvas = pagina.getCanvas();

        try {
            Bitmap bitmapOriginal = BitmapFactory.decodeResource(getResources(), R.drawable.logo);
            Bitmap logoEscalado = Bitmap.createScaledBitmap(bitmapOriginal, 40, 40, false);
            canvas.drawBitmap(logoEscalado, 240, 20, paint);
        } catch (Exception e) {
            Log.e("PDF", "Error al cargar logo: " + e.getMessage());
        }

        paint.setTextAlign(Paint.Align.LEFT);
        paint.setTextSize(14f);
        paint.setFakeBoldText(true);
        paint.setColor(Color.BLACK);
        canvas.drawText("SYLVARA SHOP", 20, 45, paint);

        paint.setStrokeWidth(1f);
        canvas.drawLine(20, 70, 280, 70, paint);

        paint.setTextSize(10f);
        paint.setFakeBoldText(false);
        canvas.drawText("Recibo de Pedido #" + idCompra, 20, 100, paint);
        canvas.drawText("Estado: " + tvStatus.getText().toString(), 20, 120, paint);
        canvas.drawText("Fecha: " + new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date()), 20, 140, paint);

        paint.setFakeBoldText(true);
        paint.setTextSize(12f);
        canvas.drawText("TOTAL PAGADO: " + tvTotal.getText().toString(), 20, 180, paint);

        paint.setFakeBoldText(false);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(8f);
        paint.setColor(Color.GRAY);
        canvas.drawText("Este documento es un comprobante oficial de compra.", 150, 460, paint);
        canvas.drawText("¡Gracias por confiar en Sylvara!", 150, 475, paint);

        documento.finishPage(pagina);

        String nombreArchivo = "Recibo_Sylvara_" + idCompra + ".pdf";
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, nombreArchivo);
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues);
                if (uri != null) {
                    OutputStream fos = getContentResolver().openOutputStream(uri);
                    documento.writeTo(fos);
                    fos.close();
                    Toast.makeText(this, "Recibo guardado en Descargas", Toast.LENGTH_SHORT).show();
                }
            } else {
                java.io.File file = new java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), nombreArchivo);
                OutputStream fos = new java.io.FileOutputStream(file);
                documento.writeTo(fos);
                fos.close();
                Toast.makeText(this, "Recibo guardado en Descargas", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e("PDF", "Error al guardar PDF: " + e.getMessage());
        } finally {
            documento.close();
        }
    }

    private void mostrarDialogoCalificacion() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialogo_calificar, null);
        builder.setView(view);

        AlertDialog dialog = builder.create();
        dialog.show();

        RatingBar ratingBar = view.findViewById(R.id.RB_Calificar);
        EditText etComentario = view.findViewById(R.id.ET_ComentarioResena);
        Button btnEnviar = view.findViewById(R.id.BTN_EnviarResena);

        btnEnviar.setOnClickListener(v -> {
            float estrellas = ratingBar.getRating();
            String comentario = etComentario.getText().toString();
            if (estrellas == 0) {
                Toast.makeText(this, "Selecciona al menos una estrella", Toast.LENGTH_SHORT).show();
                return;
            }
            enviarCalificacionServidor((int)estrellas, comentario, dialog);
        });
    }

    private void enviarCalificacionServidor(int estrellas, String comentario, AlertDialog dialog) {
        SharedPreferences pref = getSharedPreferences("user_session", MODE_PRIVATE);
        int idUsuario = Integer.parseInt(pref.getString("id_usuario", "0"));
        int idProducto = getIntent().getIntExtra("id_producto", 0);

        webService.agregarResena(idProducto, idUsuario, estrellas, comentario, new ConectaWebServiceEnvios.Callback<String>() {
            @Override
            public void onSuccess(String result) {
                runOnUiThread(() -> {
                    Toast.makeText(DetalleEnvioActivity.this, "¡Gracias por tu reseña!", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                    btnCalificar.setVisibility(View.GONE);
                });
            }
            @Override
            public void onError(String error) {
                runOnUiThread(() -> Toast.makeText(DetalleEnvioActivity.this, "Error: " + error, Toast.LENGTH_SHORT).show());
            }
        });
    }
}