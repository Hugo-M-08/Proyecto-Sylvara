package com.hugo.sylvarapro;

import android.util.Log;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class ConectaWebServiceBolitas {
    private static final String TAG = "ConectaWebServiceBolitas";
    private static final String CARPETA_BOLITAS = "Bolitas/";
    private static final String INSERTAR_URL = Configuracion.getUrlBase() + CARPETA_BOLITAS + "insertar_bolita.php";
    private static final String OBTENER_URL    = Configuracion.getUrlBase() + CARPETA_BOLITAS + "obtener_bolita.php";
    private static final String ACTUALIZAR_URL = Configuracion.getUrlBase() + CARPETA_BOLITAS + "actualizar_bolita.php";

    public interface Callback<T> {
        void onSuccess(T result);
        void onError(String error);
    }

    public void insertarBolita(String id_producto, String nombre, String hum_min, String hum_max,
                               String luz_min, String luz_max, String hum_suelo_min, String hum_suelo_max,
                               String imagenBase64, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                Log.d(TAG, "Insertando bolita con id_producto: " + id_producto);
                URL url = new URL(INSERTAR_URL);
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String data = "id_producto=" + URLEncoder.encode(id_producto, "UTF-8") +
                        "&nombre=" + URLEncoder.encode(nombre, "UTF-8") +
                        "&hum_min=" + URLEncoder.encode(hum_min, "UTF-8") +
                        "&hum_max=" + URLEncoder.encode(hum_max, "UTF-8") +
                        "&luz_min=" + URLEncoder.encode(luz_min, "UTF-8") +
                        "&luz_max=" + URLEncoder.encode(luz_max, "UTF-8") +
                        "&hum_suelo_min=" + URLEncoder.encode(hum_suelo_min, "UTF-8") +
                        "&hum_suelo_max=" + URLEncoder.encode(hum_suelo_max, "UTF-8");
                if (imagenBase64 != null && !imagenBase64.isEmpty()) {
                    data += "&imagen=" + URLEncoder.encode(imagenBase64, "UTF-8");
                }
                Log.d(TAG, "Datos enviados (insertar): " + data);

                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(data);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        response.append(linea);
                    }
                    reader.close();

                    JSONObject jsonResponse = new JSONObject(response.toString());
                    Log.d(TAG, "Response (insertar): " + jsonResponse.toString());
                    String code = jsonResponse.getString("code");
                    if (code.equals("002")) {
                        callback.onSuccess(jsonResponse.getString("message"));
                    } else {
                        callback.onError(jsonResponse.getString("message"));
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception ex) {
                Log.e(TAG, "Error (insertar): " + ex.getMessage());
                callback.onError("Error de servidor: " + ex.getMessage());
            }
        });
    }

    public void obtenerBolita(String id_producto, Callback<Item_Bolita> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                Log.d(TAG, "Obteniendo bolita con id_producto: " + id_producto);
                URL url = new URL(OBTENER_URL + "?id_producto=" + URLEncoder.encode(id_producto, "UTF-8"));
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("GET");

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        response.append(linea);
                    }
                    reader.close();

                    JSONObject jsonResponse = new JSONObject(response.toString());
                    Log.d(TAG, "Response (obtener): " + jsonResponse.toString());
                    String code = jsonResponse.getString("code");
                    if (code.equals("002")) {
                        JSONObject data = jsonResponse.getJSONObject("data");
                        Item_Bolita bolita = new Item_Bolita(
                                data.getInt("id_bolitas"),
                                Integer.parseInt(id_producto),
                                data.getString("nombre"),
                                data.getString("hum_min"),
                                data.getString("hum_max"),
                                data.getString("luz_min"),
                                data.getString("luz_max"),
                                data.getString("hum_suelo_min"),
                                data.getString("hum_suelo_max"),
                                data.optString("imagen", null)
                        );
                        callback.onSuccess(bolita);
                    } else {
                        callback.onError(jsonResponse.getString("message"));
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception ex) {
                Log.e(TAG, "Error (obtener): " + ex.getMessage());
                callback.onError("Error de servidor: " + ex.getMessage());
            }
        });
    }

    public void actualizarBolita(String id_bolitas, String id_producto, String nombre, String hum_min, String hum_max,
                                 String luz_min, String luz_max, String hum_suelo_min, String hum_suelo_max,
                                 String imagenBase64, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                Log.d(TAG, "Actualizando bolita con id_bolitas: " + id_bolitas);
                URL url = new URL(ACTUALIZAR_URL);
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String data = "id_bolitas=" + URLEncoder.encode(id_bolitas, "UTF-8") +
                        "&id_producto=" + URLEncoder.encode(id_producto, "UTF-8") +
                        "&nombre=" + URLEncoder.encode(nombre, "UTF-8") +
                        "&hum_min=" + URLEncoder.encode(hum_min, "UTF-8") +
                        "&hum_max=" + URLEncoder.encode(hum_max, "UTF-8") +
                        "&luz_min=" + URLEncoder.encode(luz_min, "UTF-8") +
                        "&luz_max=" + URLEncoder.encode(luz_max, "UTF-8") +
                        "&hum_suelo_min=" + URLEncoder.encode(hum_suelo_min, "UTF-8") +
                        "&hum_suelo_max=" + URLEncoder.encode(hum_suelo_max, "UTF-8");
                if (imagenBase64 != null && !imagenBase64.isEmpty()) {
                    data += "&imagen=" + URLEncoder.encode(imagenBase64, "UTF-8");
                }
                Log.d(TAG, "Datos enviados (actualizar): " + data);

                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(data);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        response.append(linea);
                    }
                    reader.close();

                    JSONObject jsonResponse = new JSONObject(response.toString());
                    Log.d(TAG, "Response (actualizar): " + jsonResponse.toString());
                    String code = jsonResponse.getString("code");
                    if (code.equals("002")) {
                        callback.onSuccess(jsonResponse.getString("message"));
                    } else {
                        callback.onError(jsonResponse.getString("message"));
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception ex) {
                Log.e(TAG, "Error (actualizar): " + ex.getMessage());
                callback.onError("Error de servidor: " + ex.getMessage());
            }
        });
    }
}