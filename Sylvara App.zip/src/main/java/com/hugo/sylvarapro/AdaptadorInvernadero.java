package com.hugo.sylvarapro;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
//no hay ip
import android.util.Log;

//no hay ip

public class AdaptadorInvernadero extends RecyclerView.Adapter<AdaptadorInvernadero.ViewHolder> {
    private static final String TAG = "AdaptadorInvernadero";
    private List<Item_Invernadero> datos;
    private Context context;
    private OnEliminarClickListener eliminarClickListener;

    public interface OnEliminarClickListener {
        void onEliminarClick(int idInvernadero);
    }

    public AdaptadorInvernadero(Context context, List<Item_Invernadero> datos, OnEliminarClickListener listener) {
        this.context = context;
        this.datos = datos;
        this.eliminarClickListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_invernadero, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item_Invernadero invernadero = datos.get(position);
        holder.txtNombre.setText(invernadero.getNombre());
        holder.imgInvernadero.setImageResource(R.drawable.invernadero);

        Log.d(TAG, "Binding invernadero: " + invernadero.getNombre() + ", ID: " + invernadero.getIdInvernadero());

        holder.itemView.setOnClickListener(v -> {
            Log.d(TAG, "Invernadero enviado: ID=" + invernadero.getIdInvernadero() + ", Nombre=" + invernadero.getNombre());
            Intent intent = new Intent(context, InvernaderoCompleto.class);
            intent.putExtra("invernadero", invernadero);
            context.startActivity(intent);
        });

        holder.btnEliminar.setOnClickListener(v -> {
            if (eliminarClickListener != null) {
                eliminarClickListener.onEliminarClick(invernadero.getIdInvernadero());
            }
        });
    }

    @Override
    public int getItemCount() {
        return datos.size();
    }

    public void updateInvernaderos(List<Item_Invernadero> nuevosInvernaderos) {
        datos.clear();
        datos.addAll(nuevosInvernaderos);
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgInvernadero;
        TextView txtNombre;
        Button btnEliminar;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgInvernadero = itemView.findViewById(R.id.imageView5);
            txtNombre = itemView.findViewById(R.id.TV_VerNomInvernadero);
            btnEliminar = itemView.findViewById(R.id.button);
        }
    }
}