package com.hugo.sylvarapro;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;
import java.util.ArrayList;

//hay ip

public class AdaptadorCarrito extends RecyclerView.Adapter<AdaptadorCarrito.ViewHolder> {
    private List<Item_Productos> datos;
    private Context context;
    private OnCantidadChangeListener cantidadChangeListener;

    public interface OnCantidadChangeListener {
        void onCantidadChanged();
    }

    public AdaptadorCarrito(List<Item_Productos> datos, Context context, OnCantidadChangeListener listener) {
        this.datos = datos;
        this.context = context;
        this.cantidadChangeListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_carrito, parent, false);
        return new ViewHolder(view);
    }


    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item_Productos item = datos.get(position);

        String imagenBase64 = item.getImagen();
        if (imagenBase64 != null && !imagenBase64.isEmpty()) {
            try {
                if (imagenBase64.contains(",")) {
                    imagenBase64 = imagenBase64.split(",")[1];
                }

                byte[] decodedString = Base64.decode(imagenBase64, Base64.DEFAULT);
                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

                holder.imgProducto.setImageBitmap(decodedByte);
            } catch (Exception e) {
                holder.imgProducto.setImageResource(R.drawable.error);
            }
        } else {
            holder.imgProducto.setImageResource(R.drawable.carga);
        }

        holder.txtNombre.setText(item.getNombre());
        holder.txtPrecio.setText("Precio: $" + item.getPrecio());

        int stockReal = 0;
        try {
            stockReal = Integer.parseInt(item.getUnidades());
        } catch (NumberFormatException e) {
            stockReal = 0;
        }

        int limite = Math.min(stockReal, 10);
        List<Integer> opciones = new ArrayList<>();
        for (int i = 1; i <= limite; i++) opciones.add(i);

        ArrayAdapter<Integer> adapter = new ArrayAdapter<>(context, android.R.layout.simple_spinner_item, opciones);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        holder.spCantidad.setAdapter(adapter);

        if (item.getNombre().toLowerCase().contains("bolita")) {
            holder.spCantidad.setEnabled(false);
            holder.spCantidad.setSelection(0);
        } else {
            int posSeleccionada = Math.min(item.getCantidad(), limite) - 1;
            holder.spCantidad.setSelection(Math.max(0, posSeleccionada));
        }

        holder.spCantidad.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                int nuevaCant = (int) parent.getItemAtPosition(pos);
                if (item.getCantidad() != nuevaCant) {
                    item.setCantidad(nuevaCant);
                    // Actualizar subtotal individual
                    double nuevoSubtotal = Double.parseDouble(item.getPrecio()) * item.getCantidad();
                    holder.txtSubtotal.setText(String.format("Subtotal: $%.2f", nuevoSubtotal));
                    // Notificar a la actividad para actualizar el total general
                    if (cantidadChangeListener != null) cantidadChangeListener.onCantidadChanged();
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        double subtotal = Double.parseDouble(item.getPrecio()) * item.getCantidad();
        holder.txtSubtotal.setText(String.format("Subtotal: $%.2f", subtotal));

        holder.btnEliminar.setOnClickListener(v -> {
            int currentPos = holder.getAdapterPosition();
            if (currentPos != RecyclerView.NO_POSITION) {
                datos.remove(currentPos);
                notifyItemRemoved(currentPos);
                if (cantidadChangeListener != null) cantidadChangeListener.onCantidadChanged();
            }
        });
    }
    @Override
    public int getItemCount() { return datos.size(); }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgProducto;
        TextView txtNombre, txtPrecio, txtSubtotal;
        Spinner spCantidad;
        Button btnEliminar;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgProducto = itemView.findViewById(R.id.IV_ProductoImagen);
            txtNombre = itemView.findViewById(R.id.TV_CarritoNombre);
            txtPrecio = itemView.findViewById(R.id.TV_CarritoPrecio);
            spCantidad = itemView.findViewById(R.id.SP_CantidadCarrito);
            txtSubtotal = itemView.findViewById(R.id.TV_ProductoTotal);
            btnEliminar = itemView.findViewById(R.id.BTN_BorrarProducto);
        }
    }
}