package com.hugo.sylvarapro;

import android.os.Parcel;
import android.os.Parcelable;

public class Item_Bolita implements Parcelable {
    private int idBolitas;
    private int idProducto;
    private String nombre;
    private String humMin;
    private String humMax;
    private String luzMin;
    private String luzMax;
    private String humSueloMin;
    private String humSueloMax;
    private String imagen;

    public Item_Bolita(int idBolitas, int idProducto, String nombre, String humMin, String humMax,
                       String luzMin, String luzMax, String humSueloMin, String humSueloMax, String imagen) {
        this.idBolitas = idBolitas;
        this.idProducto = idProducto;
        this.nombre = nombre;
        this.humMin = humMin;
        this.humMax = humMax;
        this.luzMin = luzMin;
        this.luzMax = luzMax;
        this.humSueloMin = humSueloMin;
        this.humSueloMax = humSueloMax;
        this.imagen = imagen;
    }

    protected Item_Bolita(Parcel in) {
        idBolitas = in.readInt();
        idProducto = in.readInt();
        nombre = in.readString();
        humMin = in.readString();
        humMax = in.readString();
        luzMin = in.readString();
        luzMax = in.readString();
        humSueloMin = in.readString();
        humSueloMax = in.readString();
        imagen = in.readString();
    }

    public static final Creator<Item_Bolita> CREATOR = new Creator<Item_Bolita>() {
        @Override
        public Item_Bolita createFromParcel(Parcel in) {
            return new Item_Bolita(in);
        }

        @Override
        public Item_Bolita[] newArray(int size) {
            return new Item_Bolita[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(idBolitas);
        dest.writeInt(idProducto);
        dest.writeString(nombre);
        dest.writeString(humMin);
        dest.writeString(humMax);
        dest.writeString(luzMin);
        dest.writeString(luzMax);
        dest.writeString(humSueloMin);
        dest.writeString(humSueloMax);
        dest.writeString(imagen);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    // Getters
    public int getIdBolitas() {
        return idBolitas;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public String getHumMin() {
        return humMin;
    }

    public String getHumMax() {
        return humMax;
    }

    public String getLuzMin() {
        return luzMin;
    }

    public String getLuzMax() {
        return luzMax;
    }

    public String getHumSueloMin() {
        return humSueloMin;
    }

    public String getHumSueloMax() {
        return humSueloMax;
    }

    public String getImagen() {
        return imagen;
    }
}