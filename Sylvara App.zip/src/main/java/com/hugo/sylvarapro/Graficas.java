package com.hugo.sylvarapro;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import android.os.Environment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.github.mikephil.charting.charts.CombinedChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.CombinedData;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;


public class Graficas extends Fragment {

    private Spinner spInvernadero, spTipoGrafica, spTiempo;
    private CombinedChart chart;
    private List<Item_Invernadero> listaInvernaderos = new ArrayList<>();
    private int idUsuario;
    private JSONArray ultimoDataRecibido;

    public Graficas() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_graficas, container, false);

        chart = view.findViewById(R.id.combinedChart);
        spInvernadero = view.findViewById(R.id.spInvernadero);
        spTipoGrafica = view.findViewById(R.id.spTipoGrafica);
        spTiempo = view.findViewById(R.id.spTiempo);
        ImageButton btnPdf = view.findViewById(R.id.BTN_PDF);

        SharedPreferences prefs = getActivity().getSharedPreferences("user_session", Context.MODE_PRIVATE);
        idUsuario = Integer.parseInt(prefs.getString("id_usuario", "0"));

        configurarSpinnersFijos();
        cargarInvernaderos();

        AdapterView.OnItemSelectedListener listenerMaestro = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (!listaInvernaderos.isEmpty()) cargarDatosGrafica();
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {}
        };

        spInvernadero.setOnItemSelectedListener(listenerMaestro);
        spTipoGrafica.setOnItemSelectedListener(listenerMaestro);
        spTiempo.setOnItemSelectedListener(listenerMaestro);

        btnPdf.setOnClickListener(v -> exportarAPDF());

        return view;
    }

    private void configurarSpinnersFijos() {
        String[] tipos = {"Ambiental (Temp/Hum)", "Cosechas (Éxito/Fallo)", "Consumo de Agua"};
        spTipoGrafica.setAdapter(new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, tipos));

        String[] tiempos = {"Hoy", "Semana", "Mes", "Año"};
        spTiempo.setAdapter(new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, tiempos));
    }

    private void cargarInvernaderos() {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Graficas/obtener_invernaderos_grafica.php?id_usuario=" + idUsuario);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                if (conn.getResponseCode() == 200) {
                    BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    JSONArray json = new JSONArray(rd.readLine());
                    List<String> nombres = new ArrayList<>();
                    listaInvernaderos.clear();
                    for (int i = 0; i < json.length(); i++) {
                        JSONObject obj = json.getJSONObject(i);

                        // CORRECCIÓN: Usar el constructor de 7 parámetros para Item_Invernadero
                        // Usamos optInt y optDouble por seguridad si el PHP de gráficas no envía todos los datos
                        listaInvernaderos.add(new Item_Invernadero(
                                obj.getInt("id_invernadero"),
                                obj.getString("nombre"),
                                idUsuario,           // id_usuario
                                true,                // activa
                                0.0,                 // latitud
                                0.0,                 // longitud
                                0                    // id_bolita_activa
                        ));

                        nombres.add(obj.getString("nombre"));
                    }
                    if (isAdded()) {
                        getActivity().runOnUiThread(() -> spInvernadero.setAdapter(new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, nombres)));
                    }
                }
            } catch (Exception e) { e.printStackTrace(); }
        });
    }
    private void cargarDatosGrafica() {
        int pos = spInvernadero.getSelectedItemPosition();
        if (pos < 0) return;

        int idInv = listaInvernaderos.get(pos).getIdInvernadero();
        String tipoRaw = spTipoGrafica.getSelectedItem().toString();
        String rango = spTiempo.getSelectedItem().toString().toLowerCase().replace("año", "anio");
        String tipoParam = tipoRaw.contains("Cosechas") ? "cosechas" : (tipoRaw.contains("Agua") ? "agua" : "ambiental");

        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Graficas/obtener_graficas_sylvara.php?tipo=" + tipoParam + "&id_invernadero=" + idInv + "&rango=" + rango);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                if (conn.getResponseCode() == 200) {
                    BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    JSONObject res = new JSONObject(rd.readLine());
                    ultimoDataRecibido = res.getJSONArray("data");
                    if (isAdded()) {
                        getActivity().runOnUiThread(() -> {
                            procesarYMostrarGrafica(ultimoDataRecibido, tipoParam);
                            actualizarTablaResumen(ultimoDataRecibido);
                        });
                    }
                }
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    private void procesarYMostrarGrafica(JSONArray data, String tipo) {
        chart.setDrawOrder(new CombinedChart.DrawOrder[]{
                CombinedChart.DrawOrder.BAR, CombinedChart.DrawOrder.LINE
        });

        CombinedData combinedData = new CombinedData();

        if (tipo.equals("cosechas")) {
            ArrayList<BarEntry> barEntries = new ArrayList<>();
            for (int i = 0; i < data.length(); i++) {
                try {
                    barEntries.add(new BarEntry(i, (float) data.getJSONObject(i).getDouble("promedio")));
                } catch (Exception e) {}
            }
            if (!barEntries.isEmpty()) {
                BarDataSet set = new BarDataSet(barEntries, "Conteo Cosechas");
                set.setColors(ColorTemplate.MATERIAL_COLORS);
                combinedData.setData(new BarData(set));
            }
            // Enviar LineData vacío para evitar crash
            combinedData.setData(new LineData());
        } else {
            ArrayList<Entry> lineEntries = new ArrayList<>();
            for (int i = 0; i < data.length(); i++) {
                try {
                    lineEntries.add(new Entry(i, (float) data.getJSONObject(i).getDouble("promedio")));
                } catch (Exception e) {}
            }
            if (!lineEntries.isEmpty()) {
                LineDataSet set = new LineDataSet(lineEntries, tipo.equals("agua") ? "Consumo de Agua" : "Tendencia Ambiental");
                set.setColor(Color.GREEN);
                set.setLineWidth(2.5f);
                set.setCircleColor(Color.GREEN);
                combinedData.setData(new LineData(set));
            }
            // Enviar BarData vacío para evitar crash
            combinedData.setData(new BarData());
        }

        chart.setData(combinedData);
        chart.getXAxis().setAxisMinimum(-0.5f);
        chart.getXAxis().setAxisMaximum(combinedData.getXMax() + 0.5f);
        chart.notifyDataSetChanged();
        chart.invalidate();
        chart.animateY(1000);
    }

    private void actualizarTablaResumen(JSONArray data) {
        if (!isAdded() || getView() == null) return;
        GridLayout grid = getView().findViewById(R.id.dataGridLayout);
        if (grid == null) return;
        grid.removeAllViews();
        grid.setColumnCount(4);

        String[] headers = {"Ref", "Inv", "Tipo", "Valor"};
        for (String h : headers) {
            TextView tv = new TextView(getContext());
            tv.setText(h);
            tv.setPadding(10, 10, 10, 10);
            tv.setTypeface(null, Typeface.BOLD);
            tv.setBackgroundColor(Color.parseColor("#E0E0E0"));
            grid.addView(tv);
        }

        for (int i = 0; i < data.length(); i++) {
            try {
                JSONObject obj = data.getJSONObject(i);
                grid.addView(crearCelda(obj.optString("nombre", "N/A")));
                grid.addView(crearCelda(spInvernadero.getSelectedItem().toString()));
                grid.addView(crearCelda(obj.optString("tipo_sensor", "-")));
                grid.addView(crearCelda(String.format("%.1f", obj.optDouble("promedio", 0.0))));
            } catch (Exception e) {}
        }
    }

    private TextView crearCelda(String texto) {
        TextView tv = new TextView(getContext());
        tv.setText(texto);
        tv.setPadding(8, 8, 8, 8);
        tv.setGravity(Gravity.CENTER);
        return tv;
    }

    private void exportarAPDF() {
        if (chart.getData() == null || ultimoDataRecibido == null) {
            Toast.makeText(getContext(), "No hay datos para exportar", Toast.LENGTH_SHORT).show();
            return;
        }

        PdfDocument document = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(595, 842, 1).create(); // A4 tamaño
        PdfDocument.Page page = document.startPage(pageInfo);
        Canvas canvas = page.getCanvas();
        Paint paint = new Paint();

        try {
            // Obtener el bitmap del logo desde drawable
            Bitmap logoBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.logo);

            if (logoBitmap != null) {
                // Redimensionar el logo (ajusta el tamaño según necesites)
                int logoWidth = 120;  // ancho deseado en puntos (~1.5-2cm)
                int logoHeight = (int) (logoBitmap.getHeight() * ((float) logoWidth / logoBitmap.getWidth()));

                Bitmap scaledLogo = Bitmap.createScaledBitmap(logoBitmap, logoWidth, logoHeight, true);

                // Posición: derecha con margen de 40 puntos
                float logoX = 595 - logoWidth - 40;  // 595 = ancho A4 en puntos
                float logoY = 40;                    // margen superior

                canvas.drawBitmap(scaledLogo, logoX, logoY, null);

                // Opcional: liberar memoria (buena práctica)
                scaledLogo.recycle();
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Si falla el logo, simplemente continuamos sin él
        }

        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(24f);
        paint.setColor(Color.BLACK);
        canvas.drawText("Sylvara Pro - Reporte", 50, 80, paint);  // bajamos un poco para dar espacio al logo

        // Información general
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(14f);
        canvas.drawText("Invernadero: " + spInvernadero.getSelectedItem().toString(), 50, 110, paint);
        canvas.drawText("Tipo de gráfica: " + spTipoGrafica.getSelectedItem().toString(), 50, 130, paint);
        canvas.drawText("Período: " + spTiempo.getSelectedItem().toString(), 50, 150, paint);

        // Gráfico
        Bitmap chartBitmap = chart.getChartBitmap();
        if (chartBitmap != null) {
            Bitmap scaledChart = Bitmap.createScaledBitmap(chartBitmap, 500, 280, false);
            canvas.drawBitmap(scaledChart, 50, 180, null);  // bajamos el gráfico para dar espacio
        }

        float yPos = 180 + 280 + 40; // Debajo del gráfico
        paint.setTextSize(16f);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        canvas.drawText("RESUMEN DE DATOS", 50, yPos, paint);

        yPos += 30;
        paint.setTextSize(12f);
        paint.setTypeface(Typeface.DEFAULT);

        // Encabezados
        canvas.drawText("Referencia", 50, yPos, paint);
        canvas.drawText("Invernadero", 170, yPos, paint);
        canvas.drawText("Tipo", 320, yPos, paint);
        canvas.drawText("Valor", 460, yPos, paint);

        yPos += 20;
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));

        // Datos
        try {
            for (int i = 0; i < ultimoDataRecibido.length(); i++) {
                JSONObject obj = ultimoDataRecibido.getJSONObject(i);

                String ref   = obj.optString("nombre", "N/A");
                String inv   = spInvernadero.getSelectedItem().toString();
                String tipo  = obj.optString("tipo_sensor", "-");
                String valor = String.format("%.1f", obj.optDouble("promedio", 0.0));

                canvas.drawText(ref,   50,  yPos, paint);
                canvas.drawText(inv,   170, yPos, paint);
                canvas.drawText(tipo,  320, yPos, paint);
                canvas.drawText(valor, 460, yPos, paint);

                yPos += 18;

                // Control de página si hay muchas filas (opcional)
                if (yPos > 750) {
                    document.finishPage(page);
                    page = document.startPage(pageInfo);
                    canvas = page.getCanvas();
                    yPos = 60;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        document.finishPage(page);

        // Guardar y abrir
        File folder = getActivity().getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (folder != null && !folder.exists()) folder.mkdirs();

        File file = new File(folder, "Reporte_Sylvara_" + System.currentTimeMillis() + ".pdf");

        try (FileOutputStream out = new FileOutputStream(file)) {
            document.writeTo(out);
            abrirPDF(file);
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "Error al generar PDF", Toast.LENGTH_SHORT).show();
        }

        document.close();
    }
    private void abrirPDF(File file) {
        Context context = getContext();
        if (context == null || !file.exists()) return;
        String authority = context.getPackageName() + ".provider";
        try {
            Uri uri = FileProvider.getUriForFile(context, authority, file);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "application/pdf");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(Intent.createChooser(intent, "Abrir reporte con:"));
        } catch (Exception e) {
            Toast.makeText(context, "Instale un lector de PDF", Toast.LENGTH_LONG).show();
        }
    }

}