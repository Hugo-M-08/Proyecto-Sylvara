package com.hugo.sylvarapro;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.hugo.sylvarapro.databinding.ActivityMainBinding;
import com.onesignal.OneSignal;
import com.onesignal.debug.LogLevel;
import org.json.JSONObject;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executors;
import android.os.Handler;
import android.os.Looper;
import androidx.core.graphics.Insets;


public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private ConectaWebServiceUsuario webServiceUsuario;
    private boolean dobleToqueParaSalir = false;

    private static final String ONESIGNAL_APP_ID = "1c8caecc-f012-4572-adcc-2119a7fefe42";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // OneSignal v5
        OneSignal.getDebug().setLogLevel(LogLevel.VERBOSE);
        OneSignal.initWithContext(this, ONESIGNAL_APP_ID);

        String onesignalId = OneSignal.getUser().getPushSubscription().getId();
        if (onesignalId != null && !onesignalId.isEmpty()) {
            registrarTokenEnBD(onesignalId);
        }

        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom);
            return insets;
        });

        webServiceUsuario = new ConectaWebServiceUsuario();

        // Ir al perfil
        binding.IMGPerfil.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, Perfil.class));
        });

        // Navegación inicial
        binding.bottomNavigationView.setSelectedItemId(R.id.home);
        replaceFragment(new Home());

        binding.bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.home) replaceFragment(new Home());
            else if (id == R.id.tienda) replaceFragment(new Tienda());
            else if (id == R.id.bolitas) replaceFragment(new Bolitas());
            else if (id == R.id.graficas) replaceFragment(new Graficas());
            else if (id == R.id.invernaderos) replaceFragment(new Invernaderos());
            return true;
        });

        setupBackPressedHandler();
    }

    private void registrarTokenEnBD(String token) {
        SharedPreferences preferences = getSharedPreferences("user_session", MODE_PRIVATE);
        String idUsuario = preferences.getString("id_usuario", "");

        if (!idUsuario.isEmpty()) {
            Executors.newSingleThreadExecutor().execute(() -> {
                try {
                    URL url = new URL(Configuracion.getUrlBase() + "actualizar_onesignal.php");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);
                    String data = "id_usuario=" + idUsuario + "&onesignal_id=" + token;
                    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
                    wr.write(data);
                    wr.flush();
                    conn.disconnect();
                } catch (Exception e) {
                    Log.e("OneSignal", "Error: " + e.getMessage());
                }
            });
        }
    }

    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, fragment);
        fragmentTransaction.commit();
    }

    private void recuperarYDatosPerfil() {
        SharedPreferences preferences = getSharedPreferences("user_session", MODE_PRIVATE);
        String idUsuario = preferences.getString("id_usuario", "");

        if (idUsuario.isEmpty()) return;

        ConectaWebServicePerfil conecta = new ConectaWebServicePerfil();
        conecta.verPerfil(idUsuario, new ConectaWebServicePerfil.Callback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                // Se usa el nombre de la columna en tu BD (foto_perfil)
                String fotoBase64 = result.optString("foto_perfil", "");
                if (!fotoBase64.isEmpty()) {
                    runOnUiThread(() -> ponerFotoPerfil(fotoBase64));
                }
            }

            @Override
            public void onError(String error) {
                Log.e("ErrorPerfil", error);
            }
        });
    }

    private void ponerFotoPerfil(String base64) {
        try {
            byte[] decodedString = Base64.decode(base64, Base64.DEFAULT);
            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            binding.IMGPerfil.setImageBitmap(decodedByte);
        } catch (Exception e) {
            binding.IMGPerfil.setImageResource(R.drawable.perfil);
        }
    }

    private void setupBackPressedHandler() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.frame_layout);

                // Si no estamos en Home, regresamos a Home primero
                if (!(currentFragment instanceof Home)) {
                    binding.bottomNavigationView.setSelectedItemId(R.id.home);
                    replaceFragment(new Home());
                    dobleToqueParaSalir = false;
                } else {
                    // Lógica para salir con doble toque
                    if (dobleToqueParaSalir) {
                        finish();
                        return;
                    }
                    dobleToqueParaSalir = true;
                    Toast.makeText(MainActivity.this, "Atrás de nuevo para salir", Toast.LENGTH_SHORT).show();
                    new Handler(Looper.getMainLooper()).postDelayed(() -> dobleToqueParaSalir = false, 2000);
                }
            }
        });
    }

    private void verificarEstadoUsuarioEnServidor() {
        SharedPreferences preferences = getSharedPreferences("user_session", MODE_PRIVATE);
        String idUsuario = preferences.getString("id_usuario", "");
        if (idUsuario.isEmpty()) return;

        webServiceUsuario.verificarEstadoUsuario(idUsuario, new ConectaWebServiceUsuario.Callback<Integer>() {
            @Override
            public void onSuccess(Integer estado) {
                if (estado == 0) {
                    runOnUiThread(() -> cerrarSesionYRedirigirLogin());
                }
            }
            @Override public void onError(String error) { Log.e("Estado", error); }
        });
    }

    private void cerrarSesionYRedirigirLogin() {
        SharedPreferences preferences = getSharedPreferences("user_session", MODE_PRIVATE);
        preferences.edit().clear().apply();
        Intent intent = new Intent(MainActivity.this, Login.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        recuperarYDatosPerfil();
        verificarEstadoUsuarioEnServidor();
    }
}