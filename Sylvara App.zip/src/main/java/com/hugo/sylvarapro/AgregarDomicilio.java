package com.hugo.sylvarapro;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
//no hay ip
public class AgregarDomicilio extends AppCompatActivity {
    private TextView TV_TituloDomicilio;
    private EditText ET_Calle, ET_CP, ET_Municipio, ET_Referencias, ET_Nombre, ET_Apellido, ET_Telef;
    private Spinner SP_Estados;
    private Button BTN_Guardar;
    private ConectaWebServiceDomicilio webService;
    private boolean isModifying;
    private int id_domicilio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_agregar_domicilio);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TV_TituloDomicilio = findViewById(R.id.TV_TituloTarjeta);
        ET_Calle = findViewById(R.id.TV_Titular);
        ET_CP = findViewById(R.id.TV_NumeroTarjeta);
        ET_Municipio = findViewById(R.id.TV_CVV);
        ET_Referencias = findViewById(R.id.TV_FechaVenc);
        ET_Nombre = findViewById(R.id.TV_Alias);
        ET_Apellido = findViewById(R.id.TV_ApellidoDom);
        ET_Telef = findViewById(R.id.TV_Telef);
        SP_Estados = findViewById(R.id.SP_Estados);
        BTN_Guardar = findViewById(R.id.BTN_RegistrarTarjeta);

        webService = new ConectaWebServiceDomicilio();

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.estados, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        SP_Estados.setAdapter(adapter);

        Intent intent = getIntent();
        isModifying = intent.getBooleanExtra("isModifying", false);

        if (isModifying) {
            TV_TituloDomicilio.setText("Modificar Domicilio");
            id_domicilio = intent.getIntExtra("id_domicilio", 0);
            ET_Calle.setText(intent.getStringExtra("calle"));
            ET_CP.setText(intent.getStringExtra("codigo_postal"));
            ET_Municipio.setText(intent.getStringExtra("municipio"));
            ET_Referencias.setText(intent.getStringExtra("referencias"));
            ET_Nombre.setText(intent.getStringExtra("nombre"));
            ET_Apellido.setText(intent.getStringExtra("apellido"));
            ET_Telef.setText(intent.getStringExtra("numero"));

            String estado = intent.getStringExtra("estado");
            if (estado != null) {
                int position = adapter.getPosition(estado);
                SP_Estados.setSelection(position);
            }
        }

        BTN_Guardar.setOnClickListener(v -> guardarDomicilio());
    }

    private void guardarDomicilio() {
        String calle = ET_Calle.getText().toString().trim();
        String cp = ET_CP.getText().toString().trim();
        String estado = SP_Estados.getSelectedItem().toString();
        String municipio = ET_Municipio.getText().toString().trim();
        String referencias = ET_Referencias.getText().toString().trim();
        String nombre = ET_Nombre.getText().toString().trim();
        String apellido = ET_Apellido.getText().toString().trim();
        String numero = ET_Telef.getText().toString().trim();

        if (calle.isEmpty() || cp.isEmpty() || municipio.isEmpty() || nombre.isEmpty() || numero.isEmpty()) {
            Toast.makeText(this, "Completa los campos obligatorios", Toast.LENGTH_SHORT).show();
            return;
        }

        if (cp.length() > 10) {
            Toast.makeText(this, "El código postal es demasiado largo", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences preferences = getSharedPreferences("user_session", MODE_PRIVATE);
        String id_usuario = preferences.getString("id_usuario", "");

        if (isModifying) {
            webService.modificarDomicilio(id_domicilio, calle, cp, estado, municipio, referencias,
                    nombre, apellido, numero, new ConectaWebServiceDomicilio.Callback<String>() {
                        @Override
                        public void onSuccess(String result) {
                            runOnUiThread(() -> {
                                Toast.makeText(AgregarDomicilio.this, result, Toast.LENGTH_SHORT).show();
                                setResult(RESULT_OK);
                                finish();
                            });
                        }
                        @Override
                        public void onError(String error) {
                            runOnUiThread(() -> Toast.makeText(AgregarDomicilio.this, error, Toast.LENGTH_SHORT).show());
                        }
                    });
        } else {
            webService.insertarDomicilio(calle, cp, estado, municipio, referencias,
                    nombre, apellido, numero, id_usuario, new ConectaWebServiceDomicilio.Callback<String>() {
                        @Override
                        public void onSuccess(String result) {
                            runOnUiThread(() -> {
                                Toast.makeText(AgregarDomicilio.this, result, Toast.LENGTH_SHORT).show();
                                setResult(RESULT_OK);
                                finish();
                            });
                        }
                        @Override
                        public void onError(String error) {
                            runOnUiThread(() -> Toast.makeText(AgregarDomicilio.this, error, Toast.LENGTH_SHORT).show());
                        }
                    });
        }
    }
}