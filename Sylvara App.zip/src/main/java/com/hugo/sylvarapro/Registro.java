package com.hugo.sylvarapro;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import android.Manifest;

public class Registro extends AppCompatActivity {
    EditText ET_Nombre, ET_CorreoElectronico, ET_ContraseñaRegis, ET_ConfirContr;
    Button BTN_Registrar, BTN_SubirFoto;
    private String fotoBase64 = "";
    private ConectaWebServiceLogin webService;

    private static final int REQUEST_PERMISSIONS = 100;
    private static final int PICK_IMAGE = 1;
    private static final int TAKE_PHOTO = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        ET_Nombre = findViewById(R.id.ET_Nombre);
        ET_CorreoElectronico = findViewById(R.id.ET_CorreoElectronico);
        ET_ContraseñaRegis = findViewById(R.id.ET_ContraseñaRegis);
        ET_ConfirContr = findViewById(R.id.ET_ConfirContr);
        BTN_Registrar = findViewById(R.id.BTN_Registrar);
        BTN_SubirFoto = findViewById(R.id.BTN_SubirFoto);
        webService = new ConectaWebServiceLogin();

        verificarYSolicitarPermisos();

        BTN_SubirFoto.setOnClickListener(v -> {
            if (tienePermisos()) {
                mostrarOpcionesImagen();
            } else {
                verificarYSolicitarPermisos();
            }
        });

        BTN_Registrar.setOnClickListener(v -> ejecutarRegistro());
    }

    private boolean tienePermisos() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    private void verificarYSolicitarPermisos() {
        if (!tienePermisos()) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE},
                    REQUEST_PERMISSIONS);
        }
    }

    private void mostrarOpcionesImagen() {
        String[] opciones = {"Cámara", "Galería", "Cancelar"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Seleccionar foto de perfil");
        builder.setItems(opciones, (dialog, which) -> {
            if (which == 0) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, TAKE_PHOTO);
            } else if (which == 1) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, PICK_IMAGE);
            } else {
                dialog.dismiss();
            }
        });
        builder.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            Bitmap bitmap = null;
            try {
                if (requestCode == PICK_IMAGE) {
                    Uri imageUri = data.getData();
                    InputStream inputStream = getContentResolver().openInputStream(imageUri);
                    bitmap = BitmapFactory.decodeStream(inputStream);
                } else if (requestCode == TAKE_PHOTO) {
                    bitmap = (Bitmap) data.getExtras().get("data");
                }

                if (bitmap != null) {
                    fotoBase64 = convertirBitmapBase64(bitmap);
                    Toast.makeText(this, "Foto lista para el registro", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Error al procesar imagen", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private String convertirBitmapBase64(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 50, baos);
        byte[] imageBytes = baos.toByteArray();
        return Base64.encodeToString(imageBytes, Base64.DEFAULT);
    }

    private void ejecutarRegistro() {
        String nombre = ET_Nombre.getText().toString().trim();
        String correo = ET_CorreoElectronico.getText().toString().trim();
        String contrasena = ET_ContraseñaRegis.getText().toString().trim();
        String confirmar = ET_ConfirContr.getText().toString().trim();

        if (nombre.isEmpty() || correo.isEmpty() || contrasena.isEmpty() || confirmar.isEmpty()) {
            Toast.makeText(this, "Por favor llena todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!contrasena.equals(confirmar)) {
            Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show();
            return;
        }

        webService.registrar(nombre, correo, contrasena, fotoBase64, new ConectaWebServiceLogin.Callback<JSONObject>() {
            @Override
            public void onSuccess(JSONObject result) {
                runOnUiThread(() -> {
                    try {
                        SharedPreferences preferences = getSharedPreferences("user_session", MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.putString("id_usuario", result.getString("id_usuario"));
                        editor.apply();

                        startActivity(new Intent(Registro.this, MainActivity.class));
                        finish();
                    } catch (Exception e) {
                        Toast.makeText(Registro.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> Toast.makeText(Registro.this, error, Toast.LENGTH_LONG).show());
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permisos concedidos", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Los permisos son necesarios para la foto de perfil", Toast.LENGTH_LONG).show();
            }
        }
    }
}