package com.hugo.sylvarapro;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

//no hay direccion ip

public class BolitasAdmin extends Fragment {
    private RecyclerView rvAdminBolitas;
    private AdaptadorBolitasAdmin adaptador;
    private ConectaWebServiceTienda webServiceTienda;
    private Button btnSubirBolita;

    public BolitasAdmin() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_bolitas_admin, container, false);

        // Inicializar vistas
        rvAdminBolitas = view.findViewById(R.id.RV_Admin_Bolitas);
        btnSubirBolita = view.findViewById(R.id.BTN_SubirBolita);

        // Configurar RecyclerView
        webServiceTienda = new ConectaWebServiceTienda();
        adaptador = new AdaptadorBolitasAdmin(new ArrayList<>(), getContext());
        rvAdminBolitas.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));
        rvAdminBolitas.setAdapter(adaptador);

        // Cargar bolitas
        cargarBolitas();

        // Botón Configurar Bolita
        btnSubirBolita.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), AgregarBolitas.class);
            startActivity(intent);
        });

        return view;
    }

    public void cargarBolitas() {
        webServiceTienda.obtenerProductos(new ConectaWebServiceTienda.Callback<List<Item_Productos>>() {
            @Override
            public void onSuccess(List<Item_Productos> result) {
                getActivity().runOnUiThread(() -> {
                    List<Item_Productos> bolitas = result.stream()
                            .filter(p -> p.getNombre().toLowerCase().contains("bolita"))
                            .collect(Collectors.toList());
                    adaptador.updateBolitas(bolitas);
                    if (bolitas.isEmpty()) {
                        Toast.makeText(getContext(), "No hay bolitas registradas", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onError(String error) {
                getActivity().runOnUiThread(() -> {
                    Toast.makeText(getContext(), "Error: " + error, Toast.LENGTH_LONG).show();
                });
            }
        });
    }
}