package com.hugo.sylvarapro;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

//no hay ip
public class AgregarPago extends AppCompatActivity {
    private TextView TV_TituloTarjeta;
    private EditText TV_Titular, TV_NumeroTarjeta, TV_CVV, TV_FechaVenc, TV_Alias;
    private Button BTN_RegistrarTarjeta;
    private ConectaWebServiceTarjeta webService;
    private boolean isModifying;
    private int id_tarjeta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_agregar_pago);

        TV_TituloTarjeta = findViewById(R.id.TV_TituloTarjeta);
        TV_Titular = findViewById(R.id.TV_Titular);
        TV_NumeroTarjeta = findViewById(R.id.TV_NumeroTarjeta);
        TV_CVV = findViewById(R.id.TV_CVV);
        TV_FechaVenc = findViewById(R.id.TV_FechaVenc);
        TV_Alias = findViewById(R.id.TV_Alias);
        BTN_RegistrarTarjeta = findViewById(R.id.BTN_RegistrarTarjeta);
        webService = new ConectaWebServiceTarjeta();

        Intent intent = getIntent();
        isModifying = intent.getBooleanExtra("isModifying", false);
        if (isModifying) {
            TV_TituloTarjeta.setText("Modificar Tarjeta");
            id_tarjeta = intent.getIntExtra("id_tarjeta", 0);
            TV_Titular.setText(intent.getStringExtra("titular"));
            TV_NumeroTarjeta.setText(intent.getStringExtra("numero_tarjeta"));
            TV_CVV.setText(intent.getStringExtra("cvv"));
            TV_FechaVenc.setText(intent.getStringExtra("fecha_vencimiento"));
            TV_Alias.setText(intent.getStringExtra("alias"));
        }

        BTN_RegistrarTarjeta.setOnClickListener(v -> guardarTarjeta());
    }

    private void guardarTarjeta() {
        String titular = TV_Titular.getText().toString().trim();
        String numero = TV_NumeroTarjeta.getText().toString().trim();
        String cvv = TV_CVV.getText().toString().trim();
        String fecha = TV_FechaVenc.getText().toString().trim(); // MM/AA
        String alias = TV_Alias.getText().toString().trim();

        if (titular.isEmpty() || numero.length() != 16 || !fecha.matches("(0[1-9]|1[0-2])/\\d{2}")) {
            Toast.makeText(this, "Datos inválidos", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!validarVencimiento(fecha)) {
            Toast.makeText(this, "La tarjeta está vencida", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences pref = getSharedPreferences("user_session", MODE_PRIVATE);
        webService.insertarTarjeta(titular, numero, cvv, fecha, alias, pref.getString("id_usuario", ""), new ConectaWebServiceTarjeta.Callback<String>() {
            @Override
            public void onSuccess(String r) { runOnUiThread(() -> { setResult(RESULT_OK); finish(); }); }
            @Override
            public void onError(String e) { }
        });
    }



    private boolean validarVencimiento(String fecha) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("MM/yy", Locale.US);
            Date fechaVenc = sdf.parse(fecha);
            return fechaVenc != null && fechaVenc.after(new Date());
        } catch (ParseException e) {
            return false;
        }
    }
}