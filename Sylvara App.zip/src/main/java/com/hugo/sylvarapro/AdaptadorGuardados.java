package com.hugo.sylvarapro;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import java.util.List;
//hay ip




public class AdaptadorGuardados extends RecyclerView.Adapter<AdaptadorGuardados.ViewHolder> {
    private List<Item_Productos> datos;
    private Context context;
    private OnFavoritoClickListener listener;

    public interface OnFavoritoClickListener {
        void onItemClick(Item_Productos producto);

        void onQuitarClick(Item_Productos producto, int position);
    }

    public AdaptadorGuardados(List<Item_Productos> datos, Context context, OnFavoritoClickListener listener) {
        this.datos = datos;
        this.context = context;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_guardado, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item_Productos item = datos.get(position);

        // --- LÓGICA DE IMAGEN BASE64 ---
        String imagenBase64 = item.getImagen();
        if (imagenBase64 != null && !imagenBase64.isEmpty()) {
            try {
                // Limpiar prefijos de metadatos si existen
                if (imagenBase64.contains(",")) {
                    imagenBase64 = imagenBase64.split(",")[1];
                }

                // Decodificar la cadena Base64 a bytes
                byte[] decodedString = Base64.decode(imagenBase64, Base64.DEFAULT);
                // Convertir bytes a Bitmap
                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

                // Asignar el Bitmap al ImageView
                holder.img.setImageBitmap(decodedByte);
            } catch (Exception e) {
                // Imagen de error si falla la decodificación
                holder.img.setImageResource(R.drawable.error);
            }
        } else {
            // Imagen por defecto si la cadena es nula o vacía
            holder.img.setImageResource(R.drawable.carga);
        }
        holder.tvTitulo.setText(item.getNombre());
        holder.tvUnidades.setText("Unidades disponibles: " + item.getUnidades());
        holder.tvTitulo.setText(item.getNombre());
        holder.tvUnidades.setText("Unidades disponibles: " + item.getUnidades());
        if (holder.rbCalificacion != null) {
            holder.rbCalificacion.setRating(item.getCalificacion());
            holder.itemView.setOnClickListener(v -> listener.onItemClick(item));
            holder.tvQuitar.setOnClickListener(v -> listener.onQuitarClick(item, holder.getAdapterPosition()));
        }

        // Navegación al detalle
        holder.itemView.setOnClickListener(v -> listener.onItemClick(item));

        // Acción de quitar de favoritos
        holder.tvQuitar.setOnClickListener(v -> {
            int currentPos = holder.getAdapterPosition();
            if (currentPos != RecyclerView.NO_POSITION) {
                listener.onQuitarClick(item, currentPos);
            }
        });
    }

    @Override
    public int getItemCount() {
        return datos.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView img;
        TextView tvTitulo, tvUnidades, tvQuitar;
        RatingBar rbCalificacion;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            img = itemView.findViewById(R.id.IV_FotoFavorito);
            tvTitulo = itemView.findViewById(R.id.TV_TituloFavorito);
            tvUnidades = itemView.findViewById(R.id.TV_UnidadesDisponibles);
            tvQuitar = itemView.findViewById(R.id.TV_QuitarFavorito);
            rbCalificacion = itemView.findViewById(R.id.RB_CalificacionDetalle);
        }
    }
}