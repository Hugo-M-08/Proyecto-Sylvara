package com.hugo.sylvarapro;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Executors;
import android.view.LayoutInflater;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import java.util.function.Consumer;

public class InvernaderoCompleto extends AppCompatActivity {

    private TextView tvNombre, tvAgua, tvCo2, tvEstatusUbicacion, tvMetros, tvHumRapida, tvTempRapida, tvLuzRapida;
    private Button btnCosecha, btnRegar, btnVentilar, btnAgregarSensores, btnGestionarBolita, btnVerNotas;
    private View viewSemaforo;
    private RecyclerView rvSensores;
    private AdaptadorSensores adaptador;
    private Item_Invernadero invernadero;
    private ConectaWebServiceInvernadero webServiceInvernadero;
    private ConectaWebServiceSensores webServiceSensores;
    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback locationCallback;
    private Handler handlerMonitoreo = new Handler(Looper.getMainLooper());
    private Runnable runnableMonitoreo;
    private boolean hayAutomatizacionActiva = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invernadero_completo);

        invernadero = getIntent().getParcelableExtra("invernadero");
        if (invernadero == null) { finish(); return; }

        vincularVistas();

        webServiceInvernadero = new ConectaWebServiceInvernadero();
        webServiceSensores = new ConectaWebServiceSensores();
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        tvNombre.setText(invernadero.getNombre());
        rvSensores.setLayoutManager(new LinearLayoutManager(this));
        configurarAdaptador();
        configurarListeners();

        verificarEstadoAutomatizacion();
        verificarEstadoCosecha();
        cargarSensores();
        iniciarMonitoreoSensores();
        configurarRastreoUbicacion();
    }

    private void vincularVistas() {
        View panelEstadoRapido = findViewById(R.id.panelEstadoRapido);

        if (panelEstadoRapido != null) {
            TextView tvTituloInterno = panelEstadoRapido.findViewById(R.id.textView16);
            if (tvTituloInterno != null) {
                tvTituloInterno.setVisibility(View.GONE);
            }
        }

        tvHumRapida = findViewById(R.id.textView17);
        tvTempRapida = findViewById(R.id.textView18);
        tvLuzRapida = findViewById(R.id.textView19);

        tvNombre = findViewById(R.id.TV_NombreInvernadero);
        tvAgua = findViewById(R.id.TV_ObtenerAgua);
        tvCo2 = findViewById(R.id.TV_ObtenerCo2);
        tvEstatusUbicacion = findViewById(R.id.TV_EstatusUbicacion);
        tvMetros = findViewById(R.id.TV_Metros);
        viewSemaforo = findViewById(R.id.viewSemaforo);
        btnCosecha = findViewById(R.id.BTN_Cosecha);
        btnRegar = findViewById(R.id.BTN_Regar);
        btnVentilar = findViewById(R.id.BTN_Ventilar);
        btnAgregarSensores = findViewById(R.id.BTN_AgregarSensores);
        btnGestionarBolita = findViewById(R.id.BTN_GestionarBolita);
        btnVerNotas = findViewById(R.id.BTN_VerNotas);
        rvSensores = findViewById(R.id.RV_Sensores_Invernadero);
    }

    private void configurarAdaptador() {
        adaptador = new AdaptadorSensores(this, new ArrayList<>(), new AdaptadorSensores.OnSensorActionListener() {
            @Override public void onToggleSensor(int id, boolean estado) { cambiarEstadoSensor(id, estado); }
            @Override public void onEliminarSensor(int id) { confirmarEliminacionSensor(id); }
            @Override public void onClickSensor(Item_Sensor sensor) {
                Intent intent = new Intent(InvernaderoCompleto.this, SensorCompleto.class);
                intent.putExtra("sensor", sensor);
                startActivity(intent);
            }
        });
        rvSensores.setAdapter(adaptador);
    }

    private void configurarListeners() {
        btnVerNotas.setOnClickListener(v -> {
            Intent intent = new Intent(InvernaderoCompleto.this, HistorialNotas.class);
            intent.putExtra("id_invernadero", invernadero.getIdInvernadero());
            intent.putExtra("nombre_inv", invernadero.getNombre());
            startActivity(intent);
        });
        btnRegar.setOnClickListener(v -> accionarReleRapido("riego"));
        btnVentilar.setOnClickListener(v -> accionarReleRapido("ventilacion"));
        btnCosecha.setOnClickListener(v -> accionCosecha());
        btnAgregarSensores.setOnClickListener(v -> mostrarDialogoVincularSensor());
        btnGestionarBolita.setOnClickListener(v -> {
            if (hayAutomatizacionActiva) { mostrarDialogoConfirmarDetener(); }
            else { mostrarDialogoSeleccionarBolita(); }
        });
    }

    private void verificarEstadoAutomatizacion() {
        hayAutomatizacionActiva = invernadero.getIdBolitaActiva() > 0;
        actualizarInterfazAutomatizacion();
    }

    private void actualizarInterfazAutomatizacion() {
        runOnUiThread(() -> {
            if (hayAutomatizacionActiva) {
                btnRegar.setEnabled(false);
                btnVentilar.setEnabled(false);
                btnRegar.setAlpha(0.5f);
                btnVentilar.setAlpha(0.5f);
                btnGestionarBolita.setText(R.string.btn_stop_automation);
            } else {
                btnRegar.setEnabled(true);
                btnVentilar.setEnabled(true);
                btnRegar.setAlpha(1.0f);
                btnVentilar.setAlpha(1.0f);
                btnGestionarBolita.setText(R.string.btn_activate_bolita);
            }
        });
    }

    private void mostrarDialogoConfirmarDetener() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.dialog_title_stop_automation)
                .setMessage(R.string.dialog_message_confirm_stop_automation)
                .setPositiveButton(R.string.yes, (d, w) -> detenerAutomatizacionEnServidor())
                .setNegativeButton(R.string.no, null).show();
    }

    private void detenerAutomatizacionEnServidor() {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Bolitas/gestionar_automatizacion.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                String data = "accion=desactivar&id_invernadero=" + invernadero.getIdInvernadero();
                OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
                wr.write(data); wr.flush();
                if (conn.getResponseCode() == 200) {
                    invernadero.setIdBolitaActiva(0);
                    hayAutomatizacionActiva = false;
                    actualizarInterfazAutomatizacion();
                }
                conn.disconnect();
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    private void mostrarDialogoSeleccionarBolita() {
        cargarBolitasCompradas(bolitas -> {
            if (bolitas == null || bolitas.isEmpty()) {
                Toast.makeText(this, R.string.toast_no_bolitas_available, Toast.LENGTH_LONG).show();
                return;
            }
            View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_seleccionar_bolita, null);
            Spinner spinnerBolita = dialogView.findViewById(R.id.spinner_bolita);
            List<String> nombres = new ArrayList<>();
            for (Item_Productos b : bolitas) nombres.add(b.getNombre() != null ? b.getNombre() : "Bolita #" + b.getId_producto());
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, nombres);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerBolita.setAdapter(adapter);
            new AlertDialog.Builder(this)
                    .setTitle(R.string.dialog_title_install_bolita)
                    .setView(dialogView)
                    .setPositiveButton(R.string.action_install, (d, w) -> {
                        int pos = spinnerBolita.getSelectedItemPosition();
                        activarBolitaEnServidor(invernadero.getIdInvernadero(), bolitas.get(pos).getId_producto());
                    })
                    .setNegativeButton(R.string.cancel, null).create().show();
        });
    }

    private void cargarBolitasCompradas(Consumer<List<Item_Productos>> callback) {
        SharedPreferences prefs = getSharedPreferences("user_session", Context.MODE_PRIVATE);
        String idUsuario = prefs.getString("id_usuario", "0");
        if ("0".equals(idUsuario)) {
            runOnUiThread(() -> { Toast.makeText(this, R.string.error_no_user, Toast.LENGTH_LONG).show(); callback.accept(null); });
            return;
        }
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Bolitas/obtener_bolitas_compradas.php?id_usuario=" + idUsuario);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) response.append(line);
                    reader.close();
                    JSONObject json = new JSONObject(response.toString());
                    List<Item_Productos> bolitas = new ArrayList<>();
                    if (json.optString("code").equals("002")) {
                        JSONArray data = json.optJSONArray("data");
                        if (data != null) {
                            for (int i = 0; i < data.length(); i++) {
                                JSONObject obj = data.getJSONObject(i);
                                Item_Productos item = new Item_Productos();
                                item.setId_producto(obj.optString("id_producto", ""));
                                item.setNombre(obj.optString("nombre", "Sin nombre"));
                                bolitas.add(item);
                            }
                        }
                    }
                    runOnUiThread(() -> callback.accept(bolitas));
                }
                conn.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> {
                    Toast.makeText(this, getString(R.string.error_loading_bolitas, e.getMessage()), Toast.LENGTH_LONG).show();
                    callback.accept(new ArrayList<>());
                });
            }
        });
    }

    private void activarBolitaEnServidor(int idInv, String idProd) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                runOnUiThread(() -> {
                    hayAutomatizacionActiva = true;
                    invernadero.setIdBolitaActiva(Integer.parseInt(idProd));
                    actualizarInterfazAutomatizacion();
                    Toast.makeText(this, R.string.toast_automation_started, Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    private void accionarReleRapido(String tipo) {
        for (Item_Sensor s : adaptador.getLista()) {
            if (s.getTipoSensor().toLowerCase().contains(tipo)) {
                cambiarEstadoSensor(s.getIdSensor(), s.getEstado() == 0);
                return;
            }
        }
        Toast.makeText(this, R.string.toast_no_system_found, Toast.LENGTH_SHORT).show();
    }

    private void cambiarEstadoSensor(int id, boolean encender) {
        String valorEstado = encender ? "1" : "0";
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Sensores/actualizar_estado_sensor.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                String data = "id_sensor=" + id + "&estado=" + valorEstado;
                OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
                wr.write(data); wr.flush();
                if (conn.getResponseCode() == 200) cargarSensores();
                conn.disconnect();
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    private void iniciarMonitoreoSensores() {
        runnableMonitoreo = new Runnable() {
            @Override
            public void run() {
                webServiceSensores.obtenerValoresSensores(invernadero.getIdInvernadero(), new ConectaWebServiceSensores.Callback<HashMap<String, Double>>() {
                    @Override
                    public void onSuccess(HashMap<String, Double> v) {
                        runOnUiThread(() -> {
                            if (v.containsKey("humedad")) {
                                double h = v.get("humedad");
                                tvHumRapida.setText(String.format("%.0f%%", h));
                                viewSemaforo.setBackgroundTintList(ColorStateList.valueOf(h < 30 ? Color.RED : (h < 50 ? Color.YELLOW : Color.GREEN)));
                            }
                            if (v.containsKey("temperatura")) tvTempRapida.setText(String.format("%.0f°", v.get("temperatura")));
                            if (v.containsKey("luz")) tvLuzRapida.setText(v.get("luz") > 100 ? getString(R.string.light_ok) : getString(R.string.light_low));
                            tvCo2.setText(String.format("☁️ %.1fppm", v.getOrDefault("co2", 0.0)));
                        });
                    }
                    @Override public void onError(String e) {}
                });
                obtenerConsumoAguaActual();
                handlerMonitoreo.postDelayed(this, 5000);
            }
        };
        handlerMonitoreo.post(runnableMonitoreo);
    }

    private void obtenerConsumoAguaActual() {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Sensores/obtener_consumo_agua.php?id_invernadero=" + invernadero.getIdInvernadero());
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                if (conn.getResponseCode() == 200) {
                    JSONObject res = new JSONObject(new BufferedReader(new InputStreamReader(conn.getInputStream())).readLine());
                    double litros = res.optDouble("consumo_agua_total", 0.0);
                    runOnUiThread(() -> tvAgua.setText(String.format("💧 %.2f L", litros)));
                }
                conn.disconnect();
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    private void cargarSensores() {
        webServiceSensores.obtenerSensores(invernadero.getIdInvernadero(), new ConectaWebServiceSensores.Callback<List<Item_Sensor>>() {
            @Override public void onSuccess(List<Item_Sensor> result) { runOnUiThread(() -> adaptador.updateSensores(result)); }
            @Override public void onError(String error) {}
        });
    }

    private void configurarRastreoUbicacion() {
        LocationRequest request = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000).setMinUpdateDistanceMeters(10).build();
        locationCallback = new LocationCallback() {
            @Override public void onLocationResult(@NonNull LocationResult result) {
                for (Location l : result.getLocations()) actualizarProximidadNativa(l);
            }
        };
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationClient.requestLocationUpdates(request, locationCallback, Looper.getMainLooper());
        }
    }

    private void actualizarProximidadNativa(Location usuarioLoc) {
        Location invLoc = new Location("Invernadero");
        invLoc.setLatitude(invernadero.getLatitud());
        invLoc.setLongitude(invernadero.getLongitud());
        float dist = usuarioLoc.distanceTo(invLoc);
        runOnUiThread(() -> {
            tvMetros.setText(dist >= 1000 ? String.format("%.1f km", dist/1000) : String.format("%.0f m", dist));
            tvEstatusUbicacion.setText(dist <= 25 ? R.string.status_at_greenhouse : R.string.status_on_the_way);
            tvEstatusUbicacion.setTextColor(dist <= 25 ? Color.GREEN : Color.BLUE);
        });
    }

    private void verificarEstadoCosecha() {
        webServiceInvernadero.gestionarCosecha(invernadero.getIdInvernadero(), "ver_estado", "", "", new ConectaWebServiceInvernadero.Callback<JSONObject>() {
            @Override public void onSuccess(JSONObject res) {
                runOnUiThread(() -> {
                    String est = res.optString("estado", "None");
                    boolean enProceso = est.equals("En Proceso");
                    btnCosecha.setText(enProceso ? R.string.btn_finish_harvest : R.string.btn_start_harvest);
                    btnCosecha.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(enProceso ? "#FFB74D" : "#C6ECFD")));
                });
            }
            @Override public void onError(String error) {}
        });
    }

    private void accionCosecha() {
        if (btnCosecha.getText().toString().equals(getString(R.string.btn_start_harvest))) {
            webServiceInvernadero.gestionarCosecha(invernadero.getIdInvernadero(), "iniciar", "", "", new ConectaWebServiceInvernadero.Callback<JSONObject>() {
                @Override public void onSuccess(JSONObject res) { runOnUiThread(() -> verificarEstadoCosecha()); }
                @Override public void onError(String e) {}
            });
        } else {
            LinearLayout layout = new LinearLayout(this); layout.setOrientation(LinearLayout.VERTICAL); layout.setPadding(50, 40, 50, 10);
            final EditText et = new EditText(this); et.setHint(R.string.hint_harvest_comment); layout.addView(et);
            new AlertDialog.Builder(this).setTitle(R.string.dialog_title_finish_harvest).setView(layout)
                    .setPositiveButton(R.string.action_successful, (d, w) -> finalizarCosechaServidor("Exitosa", et.getText().toString().trim()))
                    .setNegativeButton(R.string.action_failed, (d, w) -> finalizarCosechaServidor("Fallida", et.getText().toString().trim())).show();
        }
    }

    private void finalizarCosechaServidor(String res, String com) {
        webServiceInvernadero.gestionarCosecha(invernadero.getIdInvernadero(), "finalizar", res, com, new ConectaWebServiceInvernadero.Callback<JSONObject>() {
            @Override public void onSuccess(JSONObject resJson) { runOnUiThread(() -> verificarEstadoCosecha()); }
            @Override public void onError(String e) {}
        });
    }

    private void confirmarEliminacionSensor(int id) {
        new AlertDialog.Builder(this).setTitle(R.string.dialog_title_delete_sensor).setMessage(R.string.dialog_message_unlink_device)
                .setPositiveButton(R.string.yes, (d, w) -> eliminarSensor(id)).setNegativeButton(R.string.no, null).show();
    }

    private void eliminarSensor(int id) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Sensores/eliminar_sensor.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST"); conn.setDoOutput(true);
                OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
                wr.write("id_sensor=" + id); wr.flush();
                if (conn.getResponseCode() == 200) runOnUiThread(() -> { Toast.makeText(this, R.string.toast_device_unlinked, Toast.LENGTH_SHORT).show(); cargarSensores(); });
                conn.disconnect();
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    private void mostrarDialogoVincularSensor() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View v = getLayoutInflater().inflate(R.layout.dialog_vincular_sensor, null);
        builder.setView(v);
        EditText etCod = v.findViewById(R.id.etCodigoDispositivo), etNom = v.findViewById(R.id.etNombreSensor);
        v.findViewById(R.id.labelSpinner).setVisibility(View.GONE);
        v.findViewById(R.id.spinnerInvernadero).setVisibility(View.GONE);
        AlertDialog dialog = builder.create();
        v.findViewById(R.id.btnVincular).setOnClickListener(view -> {
            String c = etCod.getText().toString().trim(), n = etNom.getText().toString().trim();
            if (!c.isEmpty() && !n.isEmpty()) vincularSensorGlobal(c, n, invernadero.getIdInvernadero(), dialog, "no");
        });
        v.findViewById(R.id.btnCancelar).setOnClickListener(view -> dialog.dismiss());
        dialog.show();
    }

    private void vincularSensorGlobal(String c, String n, int id, AlertDialog diag, String conf) {
        SharedPreferences p = getSharedPreferences("user_session", Context.MODE_PRIVATE);
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Sensores/vincular_por_codigo.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST"); conn.setDoOutput(true);
                String d = "device_id=" + URLEncoder.encode(c, "UTF-8") + "&nombre=" + URLEncoder.encode(n, "UTF-8") + "&id_invernadero=" + id + "&id_usuario=" + p.getString("id_usuario", "0") + "&confirmar=" + conf;
                OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream()); wr.write(d); wr.flush();
                if (conn.getResponseCode() == 200) {
                    JSONObject res = new JSONObject(new BufferedReader(new InputStreamReader(conn.getInputStream())).readLine());
                    runOnUiThread(() -> { try { if (res.getString("code").equals("002")) { cargarSensores(); diag.dismiss(); } } catch (Exception e) {} });
                }
                conn.disconnect();
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    @Override protected void onResume() { super.onResume(); if (locationCallback != null) configurarRastreoUbicacion(); }
    @Override protected void onPause() { super.onPause(); if (fusedLocationClient != null) fusedLocationClient.removeLocationUpdates(locationCallback); }
    @Override protected void onDestroy() { super.onDestroy(); if (handlerMonitoreo != null) handlerMonitoreo.removeCallbacks(runnableMonitoreo); }
}
