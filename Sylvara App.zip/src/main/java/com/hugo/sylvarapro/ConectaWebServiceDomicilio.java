package com.hugo.sylvarapro;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class ConectaWebServiceDomicilio {
    public interface Callback<T> {
        void onSuccess(T result);
        void onError(String error);
    }

    public void obtenerDomicilios(String id_usuario, Callback<List<Item_Domicilio>> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Compra/obtener_domicilios.php?id_usuario=" + URLEncoder.encode(id_usuario, "UTF-8"));
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("GET");

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        response.append(linea);
                    }
                    reader.close();

                    if (response.toString().equals("001")) {
                        callback.onError("ID de usuario faltante");
                    } else if (response.toString().equals("010")) {
                        callback.onSuccess(new ArrayList<>());
                    } else {
                        JSONArray jsonArray = new JSONArray(response.toString());
                        List<Item_Domicilio> domicilios = new ArrayList<>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject json = jsonArray.getJSONObject(i);
                            domicilios.add(new Item_Domicilio(
                                    json.getInt("id_domicilio"),
                                    json.getString("calle"),
                                    json.getString("codigo_postal"),
                                    json.getString("estado"),
                                    json.getString("municipio"),
                                    json.getString("referencias"),
                                    json.getString("nombre"),
                                    json.getString("apellido"),
                                    json.getString("numero"),
                                    json.getInt("id_usuario"),
                                    json.getInt("es_predeterminado") == 1
                            ));
                        }
                        callback.onSuccess(domicilios);
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception e) {
                callback.onError("Error de servidor: " + e.getMessage());
            }
        });
    }

    public void insertarDomicilio(String calle, String codigo_postal, String estado, String municipio,
                                  String referencias, String nombre, String apellido, String numero,
                                  String id_usuario, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Compra/insertar_domicilio.php");
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String data = "calle=" + URLEncoder.encode(calle, "UTF-8") +
                        "&codigo_postal=" + URLEncoder.encode(codigo_postal, "UTF-8") +
                        "&estado=" + URLEncoder.encode(estado, "UTF-8") +
                        "&municipio=" + URLEncoder.encode(municipio, "UTF-8") +
                        "&referencias=" + URLEncoder.encode(referencias, "UTF-8") +
                        "&nombre=" + URLEncoder.encode(nombre, "UTF-8") +
                        "&apellido=" + URLEncoder.encode(apellido, "UTF-8") +
                        "&numero=" + URLEncoder.encode(numero, "UTF-8") +
                        "&id_usuario=" + URLEncoder.encode(id_usuario, "UTF-8");

                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(data);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    String response = reader.readLine();
                    reader.close();
                    switch (response) {
                        case "001":
                            callback.onError("Datos faltantes");
                            break;
                        case "002":
                            callback.onSuccess("Domicilio agregado correctamente");
                            break;
                        case "000":
                            callback.onError("No se pudo agregar el domicilio");
                            break;
                        default:
                            callback.onError("Respuesta desconocida: " + response);
                            break;
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception e) {
                callback.onError("Error de servidor: " + e.getMessage());
            }
        });
    }

    public void modificarDomicilio(int id_domicilio, String calle, String codigo_postal, String estado,
                                   String municipio, String referencias, String nombre, String apellido,
                                   String numero, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Compra/modificar_domicilio.php");
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String data = "id_domicilio=" + id_domicilio +
                        "&calle=" + URLEncoder.encode(calle, "UTF-8") +
                        "&codigo_postal=" + URLEncoder.encode(codigo_postal, "UTF-8") +
                        "&estado=" + URLEncoder.encode(estado, "UTF-8") +
                        "&municipio=" + URLEncoder.encode(municipio, "UTF-8") +
                        "&referencias=" + URLEncoder.encode(referencias, "UTF-8") +
                        "&nombre=" + URLEncoder.encode(nombre, "UTF-8") +
                        "&apellido=" + URLEncoder.encode(apellido, "UTF-8") +
                        "&numero=" + URLEncoder.encode(numero, "UTF-8");

                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(data);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    String response = reader.readLine();
                    reader.close();
                    switch (response) {
                        case "001":
                            callback.onError("Datos faltantes");
                            break;
                        case "002":
                            callback.onSuccess("Domicilio modificado correctamente");
                            break;
                        case "000":
                            callback.onError("No se pudo modificar el domicilio");
                            break;
                        default:
                            callback.onError("Respuesta desconocida: " + response);
                            break;
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception e) {
                callback.onError("Error de servidor: " + e.getMessage());
            }
        });
    }

    public void eliminarDomicilio(int id_domicilio, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Compra/eliminar_domicilio.php");
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String data = "id_domicilio=" + id_domicilio;

                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(data);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    String response = reader.readLine();
                    reader.close();
                    switch (response) {
                        case "001":
                            callback.onError("ID de domicilio faltante");
                            break;
                        case "002":
                            callback.onSuccess("Domicilio eliminado correctamente");
                            break;
                        case "000":
                            callback.onError("No se pudo eliminar el domicilio");
                            break;
                        default:
                            callback.onError("Respuesta desconocida: " + response);
                            break;
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception e) {
                callback.onError("Error de servidor: " + e.getMessage());
            }
        });
    }

    public void setDomicilioPredeterminado(int id_domicilio, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Compra/set_domicilio_predeterminado.php");
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String data = "id_domicilio=" + id_domicilio;

                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(data);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    String response = reader.readLine();
                    reader.close();
                    switch (response) {
                        case "001":
                            callback.onError("ID de domicilio faltante");
                            break;
                        case "002":
                            callback.onSuccess("Domicilio establecido como predeterminado");
                            break;
                        case "000":
                            callback.onError("No se pudo establecer el domicilio predeterminado");
                            break;
                        default:
                            callback.onError("Respuesta desconocida: " + response);
                            break;
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception e) {
                callback.onError("Error de servidor: " + e.getMessage());
            }
        });
    }
}