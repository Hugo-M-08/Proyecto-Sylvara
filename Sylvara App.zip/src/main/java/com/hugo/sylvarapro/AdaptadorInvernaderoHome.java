package com.hugo.sylvarapro;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.HashMap;
import java.util.List;

// no hay ip

public class AdaptadorInvernaderoHome extends RecyclerView.Adapter<AdaptadorInvernaderoHome.ViewHolder> {
    private List<Item_Invernadero> listaInvernaderos;
    private Context context;
    private ConectaWebServiceSensores webServiceSensor;

    public AdaptadorInvernaderoHome(List<Item_Invernadero> listaInvernaderos, Context context) {
        this.listaInvernaderos = listaInvernaderos;
        this.context = context;
        this.webServiceSensor = new ConectaWebServiceSensores();
    }

    public void updateInvernaderos(List<Item_Invernadero> nuevaLista) {
        this.listaInvernaderos = nuevaLista;
        notifyDataSetChanged();
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item_Invernadero inv = listaInvernaderos.get(position);
        holder.tvNombre.setText(inv.getNombre());

        // Valores iniciales por defecto
        holder.tvHumedad.setText("?");
        holder.tvTemperatura.setText("?");
        holder.tvLuz.setText("?");

        // Consultar valores reales
        webServiceSensor.obtenerValoresSensores(inv.getIdInvernadero(), new ConectaWebServiceSensores.Callback<HashMap<String, Double>>() {
            @Override
            public void onSuccess(HashMap<String, Double> valores) {
                if (context instanceof Activity) {
                    ((Activity) context).runOnUiThread(() -> {
                        if (valores.containsKey("humedad")) {
                            holder.tvHumedad.setText(String.format("%.0f%%", valores.get("humedad")));
                        }
                        if (valores.containsKey("temperatura")) {
                            holder.tvTemperatura.setText(String.format("%.0f°", valores.get("temperatura")));
                        }
                        if (valores.containsKey("luz")) {
                            holder.tvLuz.setText(valores.get("luz") > 100 ? "Ok" : "Baja");
                        }
                    });
                }
            }
            @Override
            public void onError(String error) {
                // Si hay error, se quedan con "?"
            }
        });

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, InvernaderoCompleto.class);
            intent.putExtra("invernadero", inv);
            context.startActivity(intent);
        });
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_estado_invernadero, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public int getItemCount() {
        return listaInvernaderos != null ? listaInvernaderos.size() : 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvNombre, tvHumedad, tvTemperatura, tvLuz;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombre = itemView.findViewById(R.id.textView16);
            tvHumedad = itemView.findViewById(R.id.textView17);
            tvTemperatura = itemView.findViewById(R.id.textView18);
            tvLuz = itemView.findViewById(R.id.textView19);
        }
    }
}
