package com.hugo.sylvarapro;

public class Item_Usuario {
    private int idUsuario;
    private String nombre;
    private String gmail;
    private int estado; // 1: Activo, 0: Baneado
    private String fotoPerfil;

    public Item_Usuario(int idUsuario, String nombre, String gmail, int estado, String fotoPerfil) {
        this.idUsuario = idUsuario;
        this.nombre = nombre;
        this.gmail = gmail;
        this.estado = estado;
        this.fotoPerfil = fotoPerfil;
    }

    public String getGmail() {
        return gmail;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public String getNombre() {
        return nombre;
    }

    // Agrega los Getters correspondientes
    public int getEstado() { return estado; }
    public String getFotoPerfil() { return fotoPerfil; }
}