package com.hugo.sylvarapro;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

//no hay ip

public class AdaptadorUsuario extends RecyclerView.Adapter<AdaptadorUsuario.ViewHolder> {
    private List<Item_Usuario> datos;
    private Context context;
    private ConectaWebServiceUsuario webServiceUsuario;

    public AdaptadorUsuario(List<Item_Usuario> datos, Context context) {
        this.datos = datos;
        this.context = context;
        this.webServiceUsuario = new ConectaWebServiceUsuario();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_usuarios, parent, false);
        return new ViewHolder(view);
    }


    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item_Usuario usuario = datos.get(position);
        holder.txtNombre.setText(usuario.getNombre());
        holder.txtCorreo.setText(usuario.getGmail());

        // Cargar Foto
        if (usuario.getFotoPerfil() != null && !usuario.getFotoPerfil().isEmpty() && !usuario.getFotoPerfil().equals("null")) {
            byte[] decodedString = Base64.decode(usuario.getFotoPerfil(), Base64.DEFAULT);
            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            holder.imgUser.setImageBitmap(decodedByte);
        } else {
            holder.imgUser.setImageResource(R.drawable.perfilusuario);
        }

        // Configuración visual del botón según estado
        if (usuario.getEstado() == 1) {
            holder.btnBanear.setText("Banear");
            holder.btnBanear.setTextColor(Color.parseColor("#BC0D0D"));
        } else {
            holder.btnBanear.setText("Desbanear");
            holder.btnBanear.setTextColor(Color.parseColor("#1976D2"));
        }

        // Lógica de click para baneo/desbaneo
        holder.btnBanear.setOnClickListener(v -> {
            int nuevoEstado = (usuario.getEstado() == 1) ? 0 : 1;
            String titulo = (nuevoEstado == 0) ? "Banear Usuario" : "Reactivar Usuario";

            new AlertDialog.Builder(context)
                    .setTitle(titulo)
                    .setMessage("¿Deseas cambiar el estado de " + usuario.getNombre() + "?")
                    .setPositiveButton("Sí", (dialog, which) -> {
                        // Llamamos al WebService para actualizar en la BD
                        webServiceUsuario.gestionarBaneo(String.valueOf(usuario.getIdUsuario()), nuevoEstado, new ConectaWebServiceUsuario.Callback<String>() {
                            @Override
                            public void onSuccess(String result) {
                                ((FragmentActivity) context).runOnUiThread(() -> {
                                    Toast.makeText(context, result, Toast.LENGTH_SHORT).show();
                                    // Recargamos los datos desde el Fragment
                                    if (context instanceof MainActivityAdmin) {
                                        // Buscamos el fragmento actual para refrescar la lista
                                        HomeAdmin fragment = (HomeAdmin) ((MainActivityAdmin) context)
                                                .getSupportFragmentManager().findFragmentById(R.id.frame_layout1);
                                        if (fragment != null) fragment.cargarUsuarios();
                                    }
                                });
                            }

                            @Override
                            public void onError(String error) {
                                ((FragmentActivity) context).runOnUiThread(() ->
                                        Toast.makeText(context, "Error: " + error, Toast.LENGTH_SHORT).show());
                            }
                        });
                    })
                    .setNegativeButton("No", null)
                    .show();
        });
    }

    private void actualizarEstadoBaneo(int idUsuario, int nuevoEstado) {
        // Lógica para conectar con el nuevo PHP gestor de baneo
        // Al terminar con éxito, recargar la lista:
        if (context instanceof FragmentActivity) {
            HomeAdmin fragment = (HomeAdmin) ((FragmentActivity) context).getSupportFragmentManager().findFragmentByTag("f0");
            // 'f0' es el tag común del primer fragmento, si no, usa una interfaz callback
            if (fragment != null) fragment.cargarUsuarios();
        }
    }

    @Override
    public int getItemCount() { return datos.size(); }

    public void updateUsuarios(List<Item_Usuario> nuevosDatos) {
        this.datos.clear();
        this.datos.addAll(nuevosDatos);
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtNombre, txtCorreo;
        ImageView imgUser;
        Button btnBanear;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtNombre = itemView.findViewById(R.id.TV_NombreUsuario);
            txtCorreo = itemView.findViewById(R.id.TV_CorreoUsuario);
            imgUser = itemView.findViewById(R.id.IV_UserItem);
            btnBanear = itemView.findViewById(R.id.BTN_Banear);
        }
    }
}