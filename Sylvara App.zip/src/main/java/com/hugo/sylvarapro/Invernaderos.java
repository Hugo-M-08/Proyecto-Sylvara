package com.hugo.sylvarapro;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.Manifest;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;

import java.util.ArrayList;
import java.util.List;


public class Invernaderos extends Fragment {
    private RecyclerView rvInvernaderos;
    private AdaptadorInvernadero adaptador;
    private Button btnAgregarInvernadero;
    private ConectaWebServiceInvernadero webService;
    private FusedLocationProviderClient fusedLocationClient;
    private String nombreTemp = "";
    private AlertDialog dialogTemp;

    public Invernaderos() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_invernaderos, container, false);
        rvInvernaderos = view.findViewById(R.id.RV_Invernaderos);
        btnAgregarInvernadero = view.findViewById(R.id.BTN_AgregarInvernadero);
        webService = new ConectaWebServiceInvernadero();
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity());
        rvInvernaderos.setLayoutManager(new LinearLayoutManager(getContext()));
        adaptador = new AdaptadorInvernadero(getContext(), new ArrayList<>(), this::eliminarInvernadero);
        rvInvernaderos.setAdapter(adaptador);
        cargarInvernaderos();
        btnAgregarInvernadero.setOnClickListener(v -> mostrarDialogoAgregarInvernadero());
        return view;
    }

    private void mostrarDialogoAgregarInvernadero() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_agregar_invernaderos, null);
        builder.setView(dialogView);

        EditText etNombre = dialogView.findViewById(R.id.etNombreInvernadero);
        Button btnCrear = dialogView.findViewById(R.id.btnCrear);
        Button btnCancelar = dialogView.findViewById(R.id.btnCancelar);

        dialogTemp = builder.create();

        btnCancelar.setOnClickListener(v -> dialogTemp.dismiss());

        btnCrear.setOnClickListener(v -> {
            nombreTemp = etNombre.getText().toString().trim();
            if (!nombreTemp.isEmpty()) {
                if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 100);
                } else {
                    solicitarUbicacionYConfirmar();
                }
            } else {
                Toast.makeText(getContext(), "Escribe un nombre", Toast.LENGTH_SHORT).show();
            }
        });
        dialogTemp.show();
    }

    private void solicitarUbicacionYConfirmar() {
        if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(getContext(), "Localizando tu invernadero...", Toast.LENGTH_SHORT).show();
            fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
                    .addOnSuccessListener(location -> {
                        if (location != null) {
                            String direccionLegible = obtenerDireccionTexto(location.getLatitude(), location.getLongitude());
                            new AlertDialog.Builder(requireContext())
                                    .setTitle("📍 Ubicación Detectada")
                                    .setMessage("Tu invernadero '" + nombreTemp + "' se guardará en:\n\n" +
                                            direccionLegible + "\n\n" +
                                            "¿La ubicación es correcta?")
                                    .setPositiveButton("Sí, guardar", (d, w) -> {
                                        enviarAlServidor(location.getLatitude(), location.getLongitude());
                                        if (dialogTemp != null) dialogTemp.dismiss();
                                    })
                                    .setNegativeButton("Reintentar", (d, w) -> {
                                        solicitarUbicacionYConfirmar();
                                    })
                                    .show();
                        } else {
                            Toast.makeText(getContext(), "No se pudo obtener la ubicación. Verifica tu GPS.", Toast.LENGTH_LONG).show();
                        }
                    });
        }
    }

    private String obtenerDireccionTexto(double lat, double lon) {
        android.location.Geocoder geocoder = new android.location.Geocoder(requireContext(), java.util.Locale.getDefault());
        try {
            java.util.List<android.location.Address> direcciones = geocoder.getFromLocation(lat, lon, 1);
            if (direcciones != null && !direcciones.isEmpty()) {
                // Retorna la calle y el número si están disponibles
                return direcciones.get(0).getAddressLine(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        // Si falla el Geocoder (por falta de internet), devolvemos las coordenadas
        return "Lat: " + lat + " | Lon: " + lon;
    }

    private void enviarAlServidor(double lat, double lon) {
        SharedPreferences prefs = requireActivity().getSharedPreferences("user_session", Context.MODE_PRIVATE);
        webService.insertarInvernaderoFull(nombreTemp, prefs.getString("id_usuario", ""), lat, lon, new ConectaWebServiceInvernadero.Callback<String>() {
            @Override
            public void onSuccess(String res) {
                requireActivity().runOnUiThread(() -> {
                    Toast.makeText(getContext(), res, Toast.LENGTH_SHORT).show();
                    cargarInvernaderos();
                    if (dialogTemp != null) dialogTemp.dismiss();
                });
            }
            @Override
            public void onError(String err) {
                requireActivity().runOnUiThread(() -> Toast.makeText(getContext(), "Error: " + err, Toast.LENGTH_SHORT).show());
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 100 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            solicitarUbicacionYConfirmar();
        }
    }

    private void cargarInvernaderos() {
        SharedPreferences prefs = requireActivity().getSharedPreferences("user_session", Context.MODE_PRIVATE);
        webService.obtenerInvernaderos(prefs.getString("id_usuario", ""), new ConectaWebServiceInvernadero.Callback<List<Item_Invernadero>>() {
            @Override
            public void onSuccess(List<Item_Invernadero> result) {
                requireActivity().runOnUiThread(() -> adaptador.updateInvernaderos(result));
            }
            @Override
            public void onError(String error) {}
        });
    }

    private void eliminarInvernadero(int id) {
        webService.eliminarInvernadero(id, new ConectaWebServiceInvernadero.Callback<String>() {
            @Override
            public void onSuccess(String r) { requireActivity().runOnUiThread(() -> cargarInvernaderos()); }
            @Override
            public void onError(String e) {}
        });
    }
}