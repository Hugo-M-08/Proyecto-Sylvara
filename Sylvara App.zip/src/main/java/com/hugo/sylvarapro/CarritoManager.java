package com.hugo.sylvarapro;
import android.content.Context;
import android.content.SharedPreferences;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class CarritoManager {
    private static final String PREF_NAME = "CarritoPrefs";
    private static final String KEY_CARRITO = "lista_carrito";
    private SharedPreferences sharedPreferences;
    private Gson gson;

    public CarritoManager(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
    }

    public void guardarCarrito(List<Item_Productos> lista) {
        String json = gson.toJson(lista);
        sharedPreferences.edit().putString(KEY_CARRITO, json).apply();
    }

    public ArrayList<Item_Productos> obtenerCarrito() {
        String json = sharedPreferences.getString(KEY_CARRITO, null);
        if (json == null) return new ArrayList<>();
        Type type = new TypeToken<ArrayList<Item_Productos>>() {}.getType();
        return gson.fromJson(json, type);
    }

    public void agregarProducto(Item_Productos producto, int cantidad) {
        ArrayList<Item_Productos> carritoActual = obtenerCarrito();
        int index = -1;

        for (int i = 0; i < carritoActual.size(); i++) {
            if (carritoActual.get(i).getId_producto().equals(producto.getId_producto())) {
                index = i;
                break;
            }
        }

        if (index == -1) {
            producto.setCantidad(producto.getNombre().toLowerCase().contains("bolita") ? 1 : cantidad);
            carritoActual.add(producto);
        } else {
            if (!producto.getNombre().toLowerCase().contains("bolita")) {
                carritoActual.get(index).setCantidad(cantidad);
            }
        }
        guardarCarrito(carritoActual);
    }
}