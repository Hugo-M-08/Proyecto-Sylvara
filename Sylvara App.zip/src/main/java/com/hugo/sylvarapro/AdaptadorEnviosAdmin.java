package com.hugo.sylvarapro;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class AdaptadorEnviosAdmin extends RecyclerView.Adapter<AdaptadorEnviosAdmin.EnvioAdminViewHolder> {
    private List<Item_EnvioAdmin> envios;
    private Context context;
    private OnActualizarClickListener onActualizarClickListener;

    // Cambiado: interfaz ahora usa id_compras
    public interface OnActualizarClickListener {
        void onActualizarClick(int id_compras, String nuevoStatus);
    }

    public AdaptadorEnviosAdmin(Context context, List<Item_EnvioAdmin> envios, OnActualizarClickListener listener) {
        this.context = context;
        this.envios = envios;
        this.onActualizarClickListener = listener;
    }

    @NonNull
    @Override
    public EnvioAdminViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_envio_admin, parent, false);
        return new EnvioAdminViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EnvioAdminViewHolder holder, int position) {
        Item_EnvioAdmin envio = envios.get(position);
        // Configurar textos (sin cambios)
        holder.tvIdDetalle.setText("Detalle ID: " + envio.getId_detalle());
        holder.tvIdCompra.setText("Compra ID: " + envio.getId_compras());
        holder.tvFecha.setText("Fecha: " + envio.getFecha());
        holder.tvProducto.setText("Producto: " + envio.getProducto());
        holder.tvCantidadPrecio.setText("Cantidad: " + envio.getCantidad() + " | Precio: $" + envio.getPrecio_unitario());
        holder.tvTotal.setText("Total: $" + envio.getTotal());
        holder.tvEstadoActual.setText("Estado actual: " + envio.getStatus());

        // Configurar Spinner con estados (sin cambios)
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(context, R.array.Status, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        holder.spinnerStatus.setAdapter(adapter);

        // Preseleccionar el estado actual en el Spinner
        int spinnerPosition = adapter.getPosition(envio.getStatus());
        holder.spinnerStatus.setSelection(spinnerPosition);

        // Botón actualizar: cambiado a pasar id_compras
        holder.btnActualizar.setOnClickListener(v -> {
            String nuevoStatus = holder.spinnerStatus.getSelectedItem().toString();
            if (onActualizarClickListener != null) {
                onActualizarClickListener.onActualizarClick(envio.getId_compras(), nuevoStatus);
            }
        });
    }

    @Override
    public int getItemCount() {
        return envios.size();
    }

    public void updateEnvios(List<Item_EnvioAdmin> newEnvios) {
        this.envios = newEnvios;
        notifyDataSetChanged();
    }

    static class EnvioAdminViewHolder extends RecyclerView.ViewHolder {
        TextView tvIdDetalle, tvIdCompra, tvFecha, tvProducto, tvCantidadPrecio, tvTotal, tvEstadoActual;
        Spinner spinnerStatus;
        Button btnActualizar;

        public EnvioAdminViewHolder(@NonNull View itemView) {
            super(itemView);
            tvIdDetalle = itemView.findViewById(R.id.tvIdDetalle);
            tvIdCompra = itemView.findViewById(R.id.tvIdCompra);
            tvFecha = itemView.findViewById(R.id.tvFecha);
            tvProducto = itemView.findViewById(R.id.tvProducto);
            tvCantidadPrecio = itemView.findViewById(R.id.tvCantidadPrecio);
            tvTotal = itemView.findViewById(R.id.tvTotal);
            tvEstadoActual = itemView.findViewById(R.id.tvEstadoActual);
            spinnerStatus = itemView.findViewById(R.id.spinnerStatus);
            btnActualizar = itemView.findViewById(R.id.btnActualizar);
        }
    }
}