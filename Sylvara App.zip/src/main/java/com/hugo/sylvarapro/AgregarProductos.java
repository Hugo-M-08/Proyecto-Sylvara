package com.hugo.sylvarapro;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;


public class AgregarProductos extends AppCompatActivity {
    private ImageButton BTN_SubirImagen;
    private Button BTN_SubirArticulo;
    private EditText ET_SubirNombre, ET_SubirDesc, ET_SubirPrecio, ET_SubirCantidad;
    private Executor executor;
    private Handler handler;
    private ConectaWebServiceTienda obj = new ConectaWebServiceTienda();
    private String imagenBase64 = "";
    private ActivityResultLauncher<String> requestPermissionLauncher;
    private ActivityResultLauncher<Intent> pickImageLauncher;
    private Item_Productos productoEditado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_agregar_productos);

        // Configuración de UI
        WindowInsetsControllerCompat windowInsetsController = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        windowInsetsController.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        windowInsetsController.hide(WindowInsetsCompat.Type.systemBars());

        ET_SubirNombre = findViewById(R.id.ET_SubirNombre);
        ET_SubirDesc = findViewById(R.id.ET_SubirDesc);
        ET_SubirPrecio = findViewById(R.id.ET_SubirPrecio);
        ET_SubirCantidad = findViewById(R.id.ET_SubirCantidad);
        BTN_SubirArticulo = findViewById(R.id.BTN_SubirArticulo);
        BTN_SubirImagen = findViewById(R.id.BTN_SubirImagen);

        handler = new Handler(Looper.getMainLooper());
        executor = Executors.newSingleThreadExecutor();

        productoEditado = getIntent().getParcelableExtra("producto");
        if (productoEditado != null) {
            ET_SubirNombre.setText(productoEditado.getNombre());
            ET_SubirDesc.setText(productoEditado.getDescripcion());
            ET_SubirPrecio.setText(productoEditado.getPrecio());
            ET_SubirCantidad.setText(productoEditado.getUnidades());
            BTN_SubirArticulo.setText("Modificar Artículo");
            // Nota: No precargamos la imagen en Base64 para no saturar la memoria
        }

        requestPermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
            if (isGranted) abrirGaleria();
            else Toast.makeText(this, "Permiso denegado", Toast.LENGTH_LONG).show();
        });

        pickImageLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                Uri imageUri = result.getData().getData();
                try {
                    InputStream inputStream = getContentResolver().openInputStream(imageUri);
                    Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                    imagenBase64 = bitmapToBase64(bitmap);
                    // Mostrar miniatura opcional
                    BTN_SubirImagen.setImageBitmap(bitmap);
                    Toast.makeText(this, "Imagen cargada", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Error al procesar imagen", Toast.LENGTH_LONG).show();
                }
            }
        });

        BTN_SubirArticulo.setOnClickListener(v -> insertarOModificarProducto());
        BTN_SubirImagen.setOnClickListener(v -> solicitarPermisoYSeleccionarImagen());
    }

    private void abrirGaleria() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pickImageLauncher.launch(intent);
    }

    private String bitmapToBase64(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        // Calidad 50 para balancear nitidez y tamaño en DB
        bitmap.compress(Bitmap.CompressFormat.JPEG, 50, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(byteArray, Base64.DEFAULT);
    }

    private void solicitarPermisoYSeleccionarImagen() {
        String permission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                ? android.Manifest.permission.READ_MEDIA_IMAGES
                : android.Manifest.permission.READ_EXTERNAL_STORAGE;

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            abrirGaleria();
        } else {
            requestPermissionLauncher.launch(permission);
        }
    }

    private void insertarOModificarProducto() {
        String nombre = ET_SubirNombre.getText().toString();
        String descripcion = ET_SubirDesc.getText().toString();
        String precio = ET_SubirPrecio.getText().toString();
        String unidades = ET_SubirCantidad.getText().toString();

        if (nombre.isEmpty() || descripcion.isEmpty() || precio.isEmpty() || unidades.isEmpty()) {
            Toast.makeText(this, "Datos faltantes", Toast.LENGTH_LONG).show();
            return;
        }

        if (productoEditado == null) {
            if (imagenBase64.isEmpty()) {
                Toast.makeText(this, "Seleccione una imagen", Toast.LENGTH_SHORT).show();
                return;
            }
            executor.execute(new ManejadorTarea("insertar", null, nombre, descripcion, precio, unidades, imagenBase64));
        } else {
            // Si imagenBase64 está vacía, el PHP mantendrá la anterior
            executor.execute(new ManejadorTarea("modificar", productoEditado.getId_producto(), nombre, descripcion, precio, unidades, imagenBase64));
        }
    }

    private class ManejadorTarea implements Runnable {
        private String accion, id, nombre, desc, precio, cant, img;

        public ManejadorTarea(String accion, String id, String nombre, String desc, String precio, String cant, String img) {
            this.accion = accion; this.id = id; this.nombre = nombre; this.desc = desc;
            this.precio = precio; this.cant = cant; this.img = img;
        }

        @Override
        public void run() {
            String resultado;
            if (accion.equals("insertar")) {
                resultado = obj.insertarProducto(nombre, desc, precio, cant, img);
            } else {
                // Modificar es asíncrono en tu ConectaWebServiceTienda, ajustamos lógica
                obj.modificarProducto(id, nombre, desc, precio, cant, img, new ConectaWebServiceTienda.Callback<String>() {
                    @Override
                    public void onSuccess(String result) {
                        actualizarUI(result);
                    }
                    @Override
                    public void onError(String error) {
                        actualizarUI(error);
                    }
                });
                return;
            }
            actualizarUI(resultado);
        }

        private void actualizarUI(String msj) {
            handler.post(() -> {
                Toast.makeText(AgregarProductos.this, msj, Toast.LENGTH_LONG).show();
                if (msj.contains("correctamente")) {
                    if (accion.equals("modificar")) finish();
                    else {
                        ET_SubirNombre.setText(""); ET_SubirDesc.setText("");
                        ET_SubirPrecio.setText(""); ET_SubirCantidad.setText("");
                        imagenBase64 = ""; BTN_SubirImagen.setImageResource(R.drawable.subir);
                    }
                }
            });
        }
    }
}