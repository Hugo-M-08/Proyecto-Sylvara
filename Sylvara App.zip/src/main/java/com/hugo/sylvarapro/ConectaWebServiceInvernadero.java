package com.hugo.sylvarapro;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;



public class ConectaWebServiceInvernadero {
    public interface Callback<T> {
        void onSuccess(T result);
        void onError(String error);
    }

    public void obtenerInvernaderos(String idUsuario, Callback<List<Item_Invernadero>> callback) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Invernadero/ver_invernadero.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);

                String data = "id_usuario=" + URLEncoder.encode(idUsuario, "UTF-8");
                OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
                wr.write(data);
                wr.flush();

                if (conn.getResponseCode() == 200) {
                    BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = rd.readLine()) != null) {
                        response.append(line);
                    }

                    JSONObject res = new JSONObject(response.toString());
                    if (res.getString("code").equals("002")) {
                        List<Item_Invernadero> list = new ArrayList<>();
                        JSONArray array = res.getJSONArray("data");
                        for (int i = 0; i < array.length(); i++) {
                            JSONObject j = array.getJSONObject(i);

                            // Mapeo corregido para usar el constructor de 7 parámetros
                            list.add(new Item_Invernadero(
                                    j.getInt("id_invernadero"),
                                    j.getString("nombre"),
                                    j.getInt("id_usuario"),
                                    true, // 'activa' booleano
                                    j.optDouble("latitud", 0.0),
                                    j.optDouble("longitud", 0.0),
                                    j.optInt("id_bolita_activa", 0) // Nuevo parámetro
                            ));
                        }
                        callback.onSuccess(list);
                    } else {
                        callback.onSuccess(new ArrayList<>());
                    }
                }
            } catch (Exception e) {
                callback.onError(e.getMessage());
            }
        });
    }

    public void insertarInvernaderoFull(String nombre, String idUser, double lat, double lon, Callback<String> callback) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Invernadero/insertar_invernadero.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                String data = "nombre=" + URLEncoder.encode(nombre, "UTF-8") + "&id_usuario=" + idUser + "&latitud=" + lat + "&longitud=" + lon;
                OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
                wr.write(data);
                wr.flush();
                if (conn.getResponseCode() == 200) {
                    JSONObject res = new JSONObject(new BufferedReader(new InputStreamReader(conn.getInputStream())).readLine());
                    callback.onSuccess(res.getString("message"));
                }
            } catch (Exception e) { callback.onError(e.getMessage()); }
        });
    }

    public void eliminarInvernadero(int id, Callback<String> callback) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Invernadero/eliminar_invernadero.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                String data = "id_invernadero=" + id;
                OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
                wr.write(data);
                wr.flush();
                if (conn.getResponseCode() == 200) {
                    JSONObject res = new JSONObject(new BufferedReader(new InputStreamReader(conn.getInputStream())).readLine());
                    callback.onSuccess(res.getString("message"));
                }
            } catch (Exception e) { callback.onError(e.getMessage()); }
        });
    }

    public void gestionarCosecha(int idInv, String metodo, String estadoFinal, String comentarios, Callback<JSONObject> callback) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Invernadero/gestionar_cosecha.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                String data = "id_invernadero=" + idInv + "&metodo=" + metodo + "&estado_final=" + URLEncoder.encode(estadoFinal, "UTF-8") + "&comentarios=" + URLEncoder.encode(comentarios, "UTF-8");
                OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
                wr.write(data);
                wr.flush();
                if (conn.getResponseCode() == 200) {
                    BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    JSONObject res = new JSONObject(rd.readLine());
                    callback.onSuccess(res);
                }
                conn.disconnect();
            } catch (Exception e) { callback.onError(e.getMessage()); }
        });
    }
}