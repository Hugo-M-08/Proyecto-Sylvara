package com.hugo.sylvarapro;

import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class ConectaWebServiceUsuario {

    private static final String TAG = "ConectaWebServiceUsuario";

    public interface Callback<T> {
        void onSuccess(T result);
        void onError(String error);
    }

    // ── Obtener lista de todos los usuarios (para admin) ───────────────────────────
    public void obtenerUsuarios(Callback<List<Item_Usuario>> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Login/ver_usuarios.php");
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        response.append(linea);
                    }
                    reader.close();

                    JSONObject jsonResponse = new JSONObject(response.toString());
                    String code = jsonResponse.getString("code");
                    Log.d(TAG, "obtenerUsuarios response: " + jsonResponse.toString());

                    if (code.equals("002")) {
                        List<Item_Usuario> usuarios = new ArrayList<>();
                        JSONArray jsonArray = jsonResponse.getJSONArray("data");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject json = jsonArray.getJSONObject(i);
                            usuarios.add(new Item_Usuario(
                                    json.getInt("id_usuario"),
                                    json.getString("nombre"),
                                    json.getString("gmail"),
                                    json.getInt("estado"),
                                    json.optString("foto_perfil", "")
                            ));
                        }
                        callback.onSuccess(usuarios);
                    } else if (code.equals("010")) {
                        callback.onSuccess(new ArrayList<>());
                    } else {
                        callback.onError(jsonResponse.getString("message"));
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception ex) {
                Log.e(TAG, "obtenerUsuarios error: " + ex.getMessage());
                callback.onError("Error de servidor: " + ex.getMessage());
            }
        });
    }

    // ── Banear / Desbanear usuario ─────────────────────────────────────────────────
    public void gestionarBaneo(String id_usuario, int nuevoEstado, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Login/gestionar_baneo.php");
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String data = "id_usuario=" + URLEncoder.encode(id_usuario, "UTF-8") +
                        "&estado=" + nuevoEstado;

                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(data);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        response.append(linea);
                    }
                    reader.close();

                    JSONObject jsonResponse = new JSONObject(response.toString());
                    if (jsonResponse.getString("code").equals("002")) {
                        callback.onSuccess(jsonResponse.getString("message"));
                    } else {
                        callback.onError(jsonResponse.getString("message"));
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception ex) {
                callback.onError("Error: " + ex.getMessage());
            }
        });
    }

    // ── Eliminar usuario ───────────────────────────────────────────────────────────
    public void eliminarUsuario(String id_usuario, Callback<String> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                Log.d(TAG, "eliminando usuario con id: " + id_usuario);
                URL url = new URL(Configuracion.getUrlBase() + "Login/eliminar_usuario.php");
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String data = "id_usuario=" + URLEncoder.encode(id_usuario, "UTF-8");
                Log.d(TAG, "Datos enviados: " + data);

                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(data);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        response.append(linea);
                    }
                    reader.close();

                    JSONObject jsonResponse = new JSONObject(response.toString());
                    Log.d(TAG, "eliminarUsuario response: " + jsonResponse.toString());

                    String code = jsonResponse.getString("code");
                    if (code.equals("002")) {
                        callback.onSuccess(jsonResponse.getString("message"));
                    } else {
                        callback.onError(jsonResponse.getString("message"));
                    }
                } else {
                    callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception ex) {
                Log.e(TAG, "eliminarUsuario error: " + ex.getMessage());
                callback.onError("Error de servidor: " + ex.getMessage());
            }
        });
    }

    // ── NUEVO MÉTODO: Verificar estado del usuario (para checar si está baneado) ──
    public void verificarEstadoUsuario(String id_usuario, Callback<Integer> callback) {
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(Configuracion.getUrlBase() + "Login/ver_estado_usuario.php");
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                conexion.setRequestMethod("POST");
                conexion.setDoOutput(true);
                conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String data = "id_usuario=" + URLEncoder.encode(id_usuario, "UTF-8");

                OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                datSal.write(data);
                datSal.flush();
                datSal.close();

                if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        response.append(linea);
                    }
                    reader.close();

                    JSONObject jsonResponse = new JSONObject(response.toString());

                    boolean success = jsonResponse.optBoolean("success", false);
                    if (success) {
                        int estado = jsonResponse.getInt("estado");
                        callback.onSuccess(estado);
                    } else {
                        callback.onError(jsonResponse.optString("message", "Error desconocido"));
                    }
                } else {
                    callback.onError("Error de conexión: " + conexion.getResponseCode());
                }
                conexion.disconnect();
            } catch (Exception ex) {
                Log.e(TAG, "verificarEstadoUsuario error: " + ex.getMessage());
                callback.onError("Error de servidor: " + ex.getMessage());
            }
        });
    }
}

