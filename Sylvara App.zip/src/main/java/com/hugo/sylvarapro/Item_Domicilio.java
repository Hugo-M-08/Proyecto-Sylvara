package com.hugo.sylvarapro;

public class Item_Domicilio {
    private int id_domicilio;
    private String calle;
    private String codigo_postal;
    private String estado;
    private String municipio;
    private String referencias;
    private String nombre;
    private String apellido;
    private String numero;
    private int id_usuario;
    private boolean es_predeterminado;

    public Item_Domicilio(int id_domicilio, String calle, String codigo_postal, String estado,
                          String municipio, String referencias, String nombre, String apellido,
                          String numero, int id_usuario, boolean es_predeterminado) {
        this.id_domicilio = id_domicilio;
        this.calle = calle;
        this.codigo_postal = codigo_postal;
        this.estado = estado;
        this.municipio = municipio;
        this.referencias = referencias;
        this.nombre = nombre;
        this.apellido = apellido;
        this.numero = numero;
        this.id_usuario = id_usuario;
        this.es_predeterminado = es_predeterminado;
    }

    // Getters
    public int getId_domicilio() { return id_domicilio; }
    public String getCalle() { return calle; }
    public String getCodigo_postal() { return codigo_postal; }
    public String getEstado() { return estado; }
    public String getMunicipio() { return municipio; }
    public String getReferencias() { return referencias; }
    public String getNombre() { return nombre; }
    public String getApellido() { return apellido; }
    public String getNumero() { return numero; }
    public int getId_usuario() { return id_usuario; }
    public boolean isEs_predeterminado() { return es_predeterminado; }
}