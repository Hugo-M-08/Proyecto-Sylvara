package com.hugo.sylvarapro;

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
    public class ConectaWebServiceLogin {
        public interface Callback<T> {
            void onSuccess(T result);
            void onError(String error);
        }

        public void login(String gmail, String contrasena, Callback<JSONObject> callback) {
            Executor executor = Executors.newSingleThreadExecutor();
            executor.execute(() -> {
                try {
                    URL url = new URL(Configuracion.getUrlBase() + "Login/login_usuario.php");
                    HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                    conexion.setRequestMethod("POST");
                    conexion.setDoOutput(true);
                    conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                    String data = "gmail=" + URLEncoder.encode(gmail, "UTF-8") +
                            "&contrasena=" + URLEncoder.encode(contrasena, "UTF-8");
                    OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                    datSal.write(data);
                    datSal.flush();
                    datSal.close();

                    if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                        StringBuilder response = new StringBuilder();
                        String linea;
                        while ((linea = reader.readLine()) != null) {
                            response.append(linea);
                        }
                        reader.close();
                        JSONObject jsonResponse = new JSONObject(response.toString());
                        String code = jsonResponse.getString("code");

                        switch (code) {
                            case "002":
                                callback.onSuccess(jsonResponse.getJSONObject("data"));
                                break;
                            case "001":
                                callback.onError("Datos faltantes");
                                break;
                            case "010":
                                callback.onError("Usuario o contraseña incorrectos");
                                break;
                            default:
                                callback.onError("Error desconocido: " + jsonResponse.getString("message"));
                                break;
                        }
                    } else {
                        callback.onError("Error al procesar servicio: " + conexion.getResponseCode());
                    }
                    conexion.disconnect();
                } catch (Exception ex) {
                    callback.onError("Error de servidor: " + ex.getMessage());
                }
            });
        }

        public void registrar(String nombre, String gmail, String contrasena, String foto, Callback<JSONObject> callback) {
            Executor executor = Executors.newSingleThreadExecutor();
            executor.execute(() -> {
                try {
                    URL url = new URL(Configuracion.getUrlBase() + "Login/registro_usuario.php");
                    HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                    conexion.setRequestMethod("POST");
                    conexion.setDoOutput(true);
                    conexion.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                    String data = "nombre=" + URLEncoder.encode(nombre, "UTF-8") +
                            "&gmail=" + URLEncoder.encode(gmail, "UTF-8") +
                            "&contrasena=" + URLEncoder.encode(contrasena, "UTF-8") +
                            "&foto=" + URLEncoder.encode(foto, "UTF-8");

                    OutputStreamWriter datSal = new OutputStreamWriter(conexion.getOutputStream());
                    datSal.write(data);
                    datSal.flush();
                    datSal.close();

                    if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                        StringBuilder response = new StringBuilder();
                        String linea;
                        while ((linea = reader.readLine()) != null) {
                            response.append(linea);
                        }
                        reader.close();

                        JSONObject jsonResponse = new JSONObject(response.toString());
                        if (jsonResponse.getString("code").equals("002")) {
                            callback.onSuccess(jsonResponse.getJSONObject("data"));
                        } else {
                            callback.onError(jsonResponse.getString("message"));
                        }
                    } else {
                        callback.onError("Error: " + conexion.getResponseCode());
                    }
                    conexion.disconnect();
                } catch (Exception ex) {
                    callback.onError("Error: " + ex.getMessage());
                }
            });
        }
    }