package com.hugo.sylvarapro;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import android.widget.Toast;


public class GuardadosActivity extends AppCompatActivity {
    private RecyclerView rvGuardados;
    private AdaptadorGuardados adaptador;
    private GuardadosManager manager;
    private ArrayList<Item_Productos> lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guardados);

        manager = new GuardadosManager(this);

        rvGuardados = findViewById(R.id.rvGuardados);
        rvGuardados.setLayoutManager(new LinearLayoutManager(this));

        cargarLista();
    }


    @Override
    protected void onResume() {
        super.onResume();
        cargarLista();
    }

    private void cargarLista() {
        lista = manager.obtenerGuardados();

        adaptador = new AdaptadorGuardados(lista, this, new AdaptadorGuardados.OnFavoritoClickListener() {
            @Override
            public void onItemClick(Item_Productos producto) {

                Intent intent = new Intent(GuardadosActivity.this, DetalleProducto.class);
                intent.putExtra("producto", producto);
                startActivity(intent);
            }

            @Override
            public void onQuitarClick(Item_Productos producto, int position) {
                manager.alternarGuardado(producto);

                lista.remove(position);
                adaptador.notifyItemRemoved(position);
                adaptador.notifyItemRangeChanged(position, lista.size());

                Toast.makeText(GuardadosActivity.this, "Eliminado de favoritos", Toast.LENGTH_SHORT).show();
            }
        });

        rvGuardados.setAdapter(adaptador);
    }
}
